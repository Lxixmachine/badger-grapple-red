# v17.3 restored gameplay shell

- Restored title screen and new game/continue flow.
- Restored starter select.
- Restored connected overworld, scout prompt, battle menu, pause menu, and save.
- Kept standalone no-CDN deploy path with matching root and dist index.html.
