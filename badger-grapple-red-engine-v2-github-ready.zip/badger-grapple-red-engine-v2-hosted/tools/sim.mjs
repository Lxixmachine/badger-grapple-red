// Headless balance sim: mirrors BattleScene.resolve() math
import {ROSTER,makeMon,scaledStats,addXp} from './src/data/roster.js';
import {MOVES,ADV} from './src/data/moves.js';
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function resolve(att,def,key){
  let mv=MOVES[key]||MOVES.stall;const as=scaledStats(att.id,att.lvl),ds=scaledStats(def.id,def.lvl);
  if(mv.gas>0&&att.gas<mv.gas)mv=MOVES.stall;
  att.gas=clamp(att.gas-Math.max(0,mv.gas),0,as.gas);
  if(mv.gas<0)att.gas=clamp(att.gas+Math.abs(mv.gas),0,as.gas);
  let acc=mv.acc;if(att.gas<12)acc-=0.12;
  if(Math.random()>acc)return;
  const mult=ADV[mv.style]===ROSTER[def.id].style?1.22:ADV[ROSTER[def.id].style]===mv.style?0.88:1;
  const dmg=Math.max(3,Math.round((mv.power+as.atk*.8-ds.def*.38)*mult*(.86+Math.random()*.28)));
  def.hp=clamp(def.hp-dmg,0,ds.hp);att.score=(att.score||0)+mv.points;
}
function bestMove(att,def){ // greedy AI for the player: prefer style edge, affordable, high power
  const moves=ROSTER[att.id].moves;
  let best=null,bestV=-1;
  for(const k of moves){const m=MOVES[k];if(m.gas>0&&att.gas<m.gas)continue;
    const mult=ADV[m.style]===ROSTER[def.id].style?1.22:ADV[ROSTER[def.id].style]===m.style?0.88:1;
    const v=m.power*m.acc*mult;if(v>bestV){bestV=v;best=k;}}
  return best||'stall';
}
function fight(a,b){ // returns true if a wins
  a.score=0;b.score=0;let t=0;
  while(t++<200){
    resolve(a,b,bestMove(a,b));
    if(b.hp<=0||a.score-b.score>=15)return true;
    const ek=ROSTER[b.id].moves[Math.floor(Math.random()*4)];
    resolve(b,a,ek);
    if(b.score-a.score>=15)a.hp=0;
    if(a.hp<=0)return false;
  }
  return a.hp>=b.hp;
}
function fightWithChew(a,b){
  a.score=0;b.score=0;let t=0,chews=2;
  while(t++<200){
    resolve(a,b,bestMove(a,b));
    if(b.hp<=0||a.score-b.score>=15)return true;
    const as=scaledStats(a.id,a.lvl);
    if(chews>0&&a.hp<as.hp*0.35){a.hp=Math.min(as.hp,a.hp+40);chews--;}
    else{const ek=ROSTER[b.id].moves[Math.floor(Math.random()*4)];resolve(b,a,ek);}
    if(b.score-a.score>=15)a.hp=0;
    if(a.hp<=0)return false;
  }
  return a.hp>=b.hp;
}
function heal(m){const s=scaledStats(m.id,m.lvl);m.hp=s.hp;m.gas=s.gas;}
function trial(){
  let me=makeMon('buckshot',6);
  const stages=[
    {boss:['captainneutral',8],grindTo:8,wildLvl:4},
    {boss:['pavilionboss',13],grindTo:13,wildLvl:8},
    {boss:['clubboss',16],grindTo:16,wildLvl:11},
  ];
  let wildFights=0,bossAttempts=0;
  for(const st of stages){
    while(me.lvl<st.grindTo){
      const w=makeMon('pacesetter',st.wildLvl);heal(me);
      if(fight(me,w))addXp(me,12+w.lvl*6);
      wildFights++;
      if(wildFights>400)return null;
    }
    let won=false;
    while(!won){
      for(let i=0;i<3&&!won;i++){heal(me);const b=makeMon(st.boss[0],st.boss[1]);heal(b);won=fightWithChew(me,b);bossAttempts++;}
      if(!won){const w=makeMon('pacesetter',st.wildLvl+2);heal(me);if(fight(me,w))addXp(me,12+w.lvl*6);wildFights++;}
      if(me.lvl>st.boss[1]+8)return {fail:st.boss[0],lvl:me.lvl,id:me.id};
    }
    st.wonAt=me.lvl;
  }
  // champion gauntlet with full heal per match approximation of items
  while(me.lvl<20){const w=makeMon('lockthrow',12);heal(me);if(fight(me,w))addXp(me,12+w.lvl*6);wildFights++;if(wildFights>800)break;}
  let champWins=0;
  for(let i=0;i<12;i++){
    heal(me);let ok=true;
    for(const [id,lvl] of [['blastcase',15],['tilttech',16],['champion',19]]){
      const b=makeMon(id,lvl);heal(b);
      if(!fight(me,b)){ok=false;break;}
      me.gas=Math.min(scaledStats(me.id,me.lvl).gas,me.gas+35); // chalk between matches
    }
    if(ok){champWins++;}
  }
  return {finalId:me.id,finalLvl:me.lvl,wildFights,bossAttempts,champWinRate:champWins/12,wonAt:stages.map(s=>s.wonAt)};
}
const results=[];
for(let i=0;i<20;i++)results.push(trial());
const fails=results.filter(r=>!r||r.fail);
console.log('fails:',fails.length,fails.slice(0,3));
const ok=results.filter(r=>r&&!r.fail);
if(ok.length){
  const avg=k=>Math.round(ok.reduce((a,r)=>a+r[k],0)/ok.length*100)/100;
  console.log('avg wild fights to finish:',avg('wildFights'),'| avg boss attempts:',avg('bossAttempts'),'| champ gauntlet win rate:',avg('champWinRate'));
  console.log('final form:',ok[0].finalId,'Lv',ok[0].finalLvl,'| boss won at levels (target 8/13/16):',ok.map(r=>r.wonAt.join('/')).slice(0,6).join('  '));
}
