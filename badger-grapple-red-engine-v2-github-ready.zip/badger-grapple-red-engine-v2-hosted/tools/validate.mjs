import {MAPS} from './src/data/maps.js';
import {ROSTER} from './src/data/roster.js';
import {MOVES} from './src/data/moves.js';
let errs=[];
for(const [mid,m] of Object.entries(MAPS)){
  const w=m.grid[0].length;
  m.grid.forEach((row,y)=>{if(row.length!==w)errs.push(`${mid} row ${y} len ${row.length}!=${w}`);});
  // warps: every digit char in grid must be defined; every warp target map+spawn must exist
  const digitsInGrid=new Set();
  m.grid.forEach(r=>[...r].forEach(ch=>{if(/\d/.test(ch))digitsInGrid.add(ch);}));
  for(const d of digitsInGrid)if(!m.warps[d])errs.push(`${mid}: grid warp '${d}' undefined`);
  for(const [d,wp] of Object.entries(m.warps)){
    if(!digitsInGrid.has(d))errs.push(`${mid}: warp '${d}' not in grid`);
    if(!MAPS[wp.map])errs.push(`${mid}: warp '${d}' -> missing map ${wp.map}`);
    else if(!MAPS[wp.map].spawns[wp.spawn])errs.push(`${mid}: warp '${d}' -> ${wp.map} missing spawn '${wp.spawn}'`);
    else{const s=MAPS[wp.map].spawns[wp.spawn];const t=MAPS[wp.map].grid[s.y]?.[s.x];if(!t||t==='#'||/\d/.test(t))errs.push(`${mid}: warp '${d}' spawn lands on '${t}' at ${s.x},${s.y} in ${wp.map}`);}
  }
  // spawns must be passable
  for(const [name,s] of Object.entries(m.spawns)){const t=m.grid[s.y]?.[s.x];if(!t||t==='#')errs.push(`${mid}: spawn ${name} lands on '${t}'`);}
  // encounters + trainers
  m.encounters.forEach(([id])=>{if(!ROSTER[id])errs.push(`${mid}: encounter ${id} missing`);});
  (m.trainers||[]).forEach(t=>{
    let found=false;m.grid.forEach(r=>{if(r.includes(t.key))found=true;});
    if(!found)errs.push(`${mid}: trainer key '${t.key}' not in grid`);
    (t.team||[]).forEach(([id])=>{if(!ROSTER[id])errs.push(`${mid}: trainer mon ${id} missing`);});
  });
  if(m.boss&&!ROSTER[m.boss.id])errs.push(`${mid}: boss ${m.boss.id} missing`);
  if(m.boss?.championTeam)m.boss.championTeam.forEach(([id])=>{if(!ROSTER[id])errs.push(`${mid}: champ team ${id} missing`);});
}
for(const [id,r] of Object.entries(ROSTER)){
  r.moves.forEach(mk=>{if(!MOVES[mk])errs.push(`roster ${id}: move ${mk} missing`);});
  if(r.evolvesTo&&!ROSTER[r.evolvesTo])errs.push(`roster ${id}: evolvesTo ${r.evolvesTo} missing`);
}
console.log(errs.length?errs.join('\n'):'ALL VALID');
