// Party-vs-champion-gauntlet sim
import {ROSTER,makeMon,scaledStats} from './src/data/roster.js';
import {MOVES,ADV} from './src/data/moves.js';
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function resolve(att,def,key){let mv=MOVES[key]||MOVES.stall;const as=scaledStats(att.id,att.lvl),ds=scaledStats(def.id,def.lvl);
 if(mv.gas>0&&att.gas<mv.gas)mv=MOVES.stall;att.gas=clamp(att.gas-Math.max(0,mv.gas),0,as.gas);
 if(mv.gas<0)att.gas=clamp(att.gas+Math.abs(mv.gas),0,as.gas);
 let acc=mv.acc;if(att.gas<12)acc-=0.12;if(Math.random()>acc)return;
 const mult=ADV[mv.style]===ROSTER[def.id].style?1.22:ADV[ROSTER[def.id].style]===mv.style?0.88:1;
 const dmg=Math.max(3,Math.round((mv.power+as.atk*.8-ds.def*.38)*mult*(.86+Math.random()*.28)));
 def.hp=clamp(def.hp-dmg,0,ds.hp);att.score=(att.score||0)+mv.points;}
function bestMove(att,def){let best='stall',bv=-1;for(const k of ROSTER[att.id].moves){const m=MOVES[k];if(m.gas>0&&att.gas<m.gas)continue;
 const mult=ADV[m.style]===ROSTER[def.id].style?1.22:ADV[ROSTER[def.id].style]===m.style?0.88:1;const v=m.power*m.acc*mult;if(v>bv){bv=v;best=k;}}return best;}
function heal(m){const s=scaledStats(m.id,m.lvl);m.hp=s.hp;m.gas=s.gas;}
function gauntlet(party,chews){
  const foes=[makeMon('blastcase',17),makeMon('tilttech',18),makeMon('champion',21)];
  let ai=0;
  for(const e of foes){heal(e);e.score=0;
    while(true){
      const me=party[ai];me.score=me.score||0;
      resolve(me,e,bestMove(me,e));
      if(e.hp<=0||me.score-e.score>=15)break;
      const ms=scaledStats(me.id,me.lvl);
      if(chews>0&&me.hp<ms.hp*0.3){me.hp=Math.min(ms.hp,me.hp+40);chews--;}
      else resolve(e,me,ROSTER[e.id].moves[Math.floor(Math.random()*4)]);
      if(e.score-me.score>=15)me.hp=0;
      if(me.hp<=0){ai++;if(ai>=party.length)return false;party[ai].score=0;}
    }
  }
  return true;
}
let wins=0,N=200;
for(let i=0;i<N;i++){
  const party=[makeMon('buckallam',21),makeMon('funklord',17),makeMon('whizzkid',17)];
  party.forEach(heal);
  if(gauntlet(party,4))wins++;
}
console.log('party-of-4 gauntlet win rate:',(wins/N*100).toFixed(0)+'%');
