# Badger Grapple Red Engine v3.0 — "FireRed Loop"

This is the structural jump from single-room demo to full campaign. Every pillar of the
FireRed loop is now in the engine.

## World
- 7 connected areas: Field House → Campus Quad → Lakeshore Path → Lakeshore Pavilion (Gym 2),
  Downtown Route → Downtown Club (Gym 3) → Conference Arena (Championship).
- Warp doors between maps, with badge gates (1 badge to reach Lakeshore, 2 for Downtown,
  3 for the Arena).
- Per-map wild encounter tables, level ranges, and encounter rates. Walking in grass now
  triggers wild recruit matches (pressing A on grass still opens the classic Scout Report).

## Progression
- 3 badges + the Conference Title: Captain Neutral (Lv8), Pavilion Anchor (Lv13, Top),
  Downtown Dervish (Lv16, Scramble), then a 3-match championship gauntlet ending with the
  Lv21 Conference Champ.
- Rival (Rex Rivalson) battles you on Campus Quad and again Downtown. He always runs the
  style that counters your starter.
- 7 one-time trainer battles across the routes with Grit/Rep rewards and persistent
  defeated flags (✓ over their heads).

## Team building
- Party of 6 with a practice box for overflow. New Team Manager menu: set your lead,
  swap slots, move wrestlers between party and box.
- Starters now develop through 3 stages (Lv11 and Lv20), e.g. Bucky Shotmaker → Varsity
  Bucky → All-American Bucky. Evolved forms get tinted battle sprites.
- Roster expanded 8 → 27 wrestlers (22 recruitable + rival/leaders/champion).
- Move pool expanded 15 → 26.

## Battle (full FireRed command loop)
- FIGHT / TEAM / ITEM / RUN root menu.
- Mid-match recruiting: weaken a wild recruit, then ITEM → Roster Invite. Sign odds scale
  with remaining HP and rarity. No more post-win invite screen.
- Swap wrestlers mid-match (uses your turn). When your wrestler goes down, the next steps in.
- Full team wipe = blackout: half your Grit, carried back to the Field House, team restored.
- Trainers and gym leaders field multi-wrestler teams; RUN works only in wild matches.
- Items in battle: Energy Chew (40 HP), Chalk (35 gas, new shop item).
- Tech fall preserved: +15 point lead ends the match either direction.

## Balance (simulated, tools/ folder)
- 20-trial campaign sim: all 3 badges winnable at the leader's level with 2 chews
  (avg 1.2 attempts per badge). Championship gauntlet: ~3% solo, ~99% with a leveled
  party of 4 playing style edges — bring the full room.

## Saves
- Save schema v3.0 with migration: old v2.x phone saves normalize cleanly (new items,
  map position, trainer flags default in).

## Verify
The note under the game should say:
`Engine v3.0 FireRed loop. 7 connected areas, 3 badges + Conference Title, ...`
