import {BootScene} from './scenes/BootScene.js';import {TitleScene} from './scenes/TitleScene.js';import {StarterScene} from './scenes/StarterScene.js';import {OverworldScene} from './scenes/OverworldScene.js';import {ScoutScene} from './scenes/ScoutScene.js';import {BattleScene} from './scenes/BattleScene.js';import {MenuScene} from './scenes/MenuScene.js';
const Phaser = window.Phaser;
const config={type:Phaser.AUTO,parent:'game',backgroundColor:'#09090b',pixelArt:true,roundPixels:true,width:480,height:432,scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH},scene:[BootScene,TitleScene,StarterScene,OverworldScene,ScoutScene,BattleScene,MenuScene]};
new Phaser.Game(config);
document.querySelectorAll('[data-key]').forEach(b=>b.addEventListener('click',()=>{if(typeof window.engineControl==='function')window.engineControl(b.dataset.key);}));
