import {BootScene} from './scenes/BootScene.js';import {TitleScene} from './scenes/TitleScene.js';import {StarterScene} from './scenes/StarterScene.js';import {OverworldScene} from './scenes/OverworldScene.js';import {ScoutScene} from './scenes/ScoutScene.js';import {BattleScene} from './scenes/BattleScene.js';import {MenuScene} from './scenes/MenuScene.js';
const Phaser = window.Phaser;
const config={type:Phaser.AUTO,parent:'game',backgroundColor:'#09090b',pixelArt:true,roundPixels:true,width:480,height:432,scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH},scene:[BootScene,TitleScene,StarterScene,OverworldScene,ScoutScene,BattleScene,MenuScene]};
const game=new Phaser.Game(config);
window.badgerGame=game;
window.BADGER_VERSION='2.2-input-router';
function routeVirtualButton(key){
  const manager=game.scene;
  const active=manager.getScenes(true).filter(s=>s&&s.handleVirtualButton&&s.scene&&s.scene.isActive());
  const top=active[active.length-1]||window.__fallbackControlScene;
  if(top&&top.handleVirtualButton)top.handleVirtualButton(key);
}
window.engineControl=routeVirtualButton;
document.querySelectorAll('[data-key]').forEach(b=>{
  b.addEventListener('click',e=>{
    e.preventDefault();
    routeVirtualButton(b.dataset.key);
  },{passive:false});
});
