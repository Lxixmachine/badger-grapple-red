import {makeMon} from '../data/roster.js';
const KEY='badger_grapple_red_engine_v2';
const SAVE_VERSION='2.7';
export function defaultState(){return {version:SAVE_VERSION,party:[],box:[],active:0,dex:{seen:{},caught:{}},grit:12,rep:8,items:{invite:3,energy:2,tape:1,film:1},badges:[],stats:{scouts:0,battles:0,wins:0,recruits:0,streak:0},pos:null,message:'Welcome to Badger Grapple Red.'};}
export function normalizeState(state){
  const d=defaultState();
  if(!state||typeof state!=='object')return d;
  state.version=SAVE_VERSION;
  state.party=Array.isArray(state.party)?state.party:[];
  state.box=Array.isArray(state.box)?state.box:[];
  state.active=Number.isInteger(state.active)?state.active:0;
  state.dex={seen:{...(state.dex?.seen||{})},caught:{...(state.dex?.caught||{})}};
  state.items={...d.items,...(state.items||{})};
  state.badges=Array.isArray(state.badges)?state.badges:[];
  state.stats={...d.stats,...(state.stats||{})};
  state.grit=Number.isFinite(state.grit)?state.grit:d.grit;
  state.rep=Number.isFinite(state.rep)?state.rep:d.rep;
  state.pos=state.pos||null;
  state.message=typeof state.message==='string'?state.message:'';
  return state;
}
export function loadState(){try{return normalizeState(JSON.parse(localStorage.getItem(KEY))||defaultState());}catch{return defaultState();}}
export function saveState(state){try{localStorage.setItem(KEY,JSON.stringify(normalizeState(state)));}catch{}}
export function resetState(){try{localStorage.removeItem(KEY);}catch{}}
export function chooseStarter(id){const s=defaultState();s.party=[makeMon(id,6)];s.dex.seen[id]=true;s.dex.caught[id]=true;s.message='Coach: Good choice. Head to the green scout zones.';saveState(s);return s;}
export function lead(state){if(!state.party.length)return null;if(!state.party[state.active])state.active=0;return state.party[state.active];}
export function caughtRecruitCount(state){return Object.keys(state.dex?.caught||{}).filter(id=>state.dex.caught[id]).length;}
