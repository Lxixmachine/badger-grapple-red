import {makeMon} from '../data/roster.js';
const KEY='badger_grapple_red_engine_v2';
export function defaultState(){return {party:[],box:[],active:0,dex:{seen:{},caught:{}},grit:12,rep:8,items:{invite:3,energy:2,tape:1,film:1},badges:[],pos:null,message:'Welcome to Badger Grapple Red.'};}
export function loadState(){try{return JSON.parse(localStorage.getItem(KEY))||defaultState();}catch{return defaultState();}}
export function saveState(state){try{localStorage.setItem(KEY,JSON.stringify(state));}catch{}}
export function resetState(){try{localStorage.removeItem(KEY);}catch{}}
export function chooseStarter(id){const s=defaultState();s.party=[makeMon(id,6)];s.dex.seen[id]=true;s.dex.caught[id]=true;s.message='Coach: Good choice. Head to the green scout zones.';saveState(s);return s;}
export function lead(state){if(!state.party.length)return null;if(!state.party[state.active])state.active=0;return state.party[state.active];}
