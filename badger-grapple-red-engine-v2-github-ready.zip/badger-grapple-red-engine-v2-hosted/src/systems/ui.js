const Phaser = window.Phaser;
export function uiBox(scene,x,y,w,h){const g=scene.add.graphics();g.fillStyle(0xf2e6c6,1);g.fillRoundedRect(x,y,w,h,8);g.lineStyle(3,0x111111,1);g.strokeRoundedRect(x,y,w,h,8);g.lineStyle(2,0x8e826d,1);g.strokeRoundedRect(x+4,y+4,w-8,h-8,5);return g;}
export function hpBar(scene,x,y,w,h,p,color=0x55b867){const g=scene.add.graphics();g.fillStyle(0x222222,1);g.fillRect(x,y,w,h);g.fillStyle(color,1);g.fillRect(x,y,Math.max(2,w*Phaser.Math.Clamp(p,0,1)),h);g.lineStyle(1,0x111111,1);g.strokeRect(x,y,w,h);return g;}
export function setVirtualHandler(scene){window.engineControl=(key)=>{if(scene.handleVirtualButton)scene.handleVirtualButton(key);};}
