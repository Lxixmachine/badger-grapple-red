import {ROSTER,makeMon,scaledStats,addXp} from '../data/roster.js';import {MOVES,ADV} from '../data/moves.js';import {loadState,saveState,lead} from '../systems/save.js';import {uiBox,hpBar,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
export class BattleScene extends Phaser.Scene{
  constructor(){super('BattleScene');}
  create(data){
    this.state=loadState();
    this.enemy=makeMon(data.enemyId,data.enemyLevel);
    this.type=data.battleType||'wild';
    this.turn=1;this.sel=0;this.log=[`${ROSTER[this.enemy.id].name} steps onto the mat!`];
    this.over=false;this.recruit=false;this.pendingForfeit=false;this.lastInputAt=0;
    const l=lead(this.state);
    if(l&&l.hp<=0){const s=scaledStats(l.id,l.lvl);l.hp=s.hp;l.gas=s.gas;saveState(this.state);}
    this.cameras.main.setBackgroundColor('#16181e');
    this.drawStatic();this.drawBattle();
    this.input.keyboard.on('keydown-LEFT',()=>this.move(-1));
    this.input.keyboard.on('keydown-RIGHT',()=>this.move(1));
    this.input.keyboard.on('keydown-UP',()=>this.move(2));
    this.input.keyboard.on('keydown-DOWN',()=>this.move(2));
    this.input.keyboard.on('keydown-ENTER',()=>this.choose());
    this.input.keyboard.on('keydown-SPACE',()=>this.choose());
    this.input.keyboard.on('keydown-ESC',()=>this.forfeit());
    setVirtualHandler(this);
  }
  okInput(){
    const now=this.time.now||performance.now();
    if(now-this.lastInputAt<120)return false;
    this.lastInputAt=now;
    return true;
  }
  handleVirtualButton(k){
    if(!this.okInput())return;
    if(k==='left')this.move(-1);
    if(k==='right')this.move(1);
    if(k==='up'||k==='down')this.move(2);
    if(k==='a')this.choose();
    if(k==='b')this.forfeit();
  }
  drawStatic(){
    this.add.rectangle(240,220,480,440,0x16181e);
    this.add.image(240,210,'tiles',3).setScale(15,5.0);
    this.add.text(240,22,'FIELD HOUSE MATCH',{fontFamily:'monospace',fontSize:18,color:'#f4e6c7',fontStyle:'bold'}).setOrigin(.5);
  }
  drawBattle(){
    if(this.ui)this.ui.destroy(true);
    this.ui=this.add.container(0,0);
    const l=lead(this.state);
    if(!l){this.log=['No starter found. Return to Field House.'];this.over=true;}
    const lr=l?ROSTER[l.id]:ROSTER.buckshot,er=ROSTER[this.enemy.id];
    this.ui.add(this.add.image(140,205,'battle_'+lr.asset+'_back').setScale(2.45));
    this.ui.add(this.add.image(340,178,'battle_'+er.asset).setScale(2.55).setFlipX(true));
    if(l)this.drawHud(18,52,l,lr);
    this.drawHud(276,52,this.enemy,er);

    uiBox(this,18,274,444,54);
    this.ui.add(this.add.text(36,288,this.log[0]||'Ready.',{fontFamily:'monospace',fontSize:13,color:'#111',wordWrap:{width:408}}));

    if(this.over){
      uiBox(this,18,338,444,72);
      this.ui.add(this.add.text(240,358,this.recruit?'Recruit opportunity!':'Match complete.',{fontFamily:'monospace',fontSize:14,color:'#111',fontStyle:'bold'}).setOrigin(.5));
      this.ui.add(this.add.text(240,382,this.recruit?'A: Use Invite   B: Return':'A: Return to Field House',{fontFamily:'monospace',fontSize:13,color:'#111'}).setOrigin(.5));
    }else{
      uiBox(this,18,338,444,78);
      this.drawMoves(36,354);
      this.ui.add(this.add.text(440,397,'B: forfeit prompt',{fontFamily:'monospace',fontSize:10,color:'#555'}).setOrigin(1,.5));
    }
  }
  drawHud(x,y,m,r){
    const s=scaledStats(m.id,m.lvl);
    uiBox(this,x,y,184,70);
    this.ui.add(this.add.text(x+12,y+10,`${r.name} Lv ${m.lvl}`,{fontFamily:'monospace',fontSize:12,color:'#111',fontStyle:'bold'}));
    this.ui.add(hpBar(this,x+12,y+32,150,8,m.hp/s.hp,0x55b867));
    this.ui.add(hpBar(this,x+12,y+46,150,6,m.gas/s.gas,0x5aa4e6));
    this.ui.add(this.add.text(x+12,y+56,`Score ${m.score||0} • ${r.style}`,{fontFamily:'monospace',fontSize:10,color:'#333'}));
  }
  drawMoves(x,y){
    const l=lead(this.state);
    if(!l)return;
    ROSTER[l.id].moves.forEach((key,i)=>{
      const m=MOVES[key],tx=x+(i%2)*212,ty=y+Math.floor(i/2)*25;
      this.ui.add(this.add.text(tx,ty,`${i===this.sel?'▶ ':'  '}${m.name}`,{fontFamily:'monospace',fontSize:13,color:i===this.sel?'#b41820':'#111',fontStyle:'bold'}));
    });
  }
  move(d){
    if(this.over)return;
    if(this.pendingForfeit){this.pendingForfeit=false;this.log.unshift('Forfeit cancelled.');this.drawBattle();return;}
    this.sel=Phaser.Math.Wrap(this.sel+d,0,4);
    this.drawBattle();
  }
  choose(){
    if(this.over){if(this.recruit)this.tryRecruit();else this.returnMap();return;}
    if(this.pendingForfeit){this.pendingForfeit=false;this.log.unshift('Forfeit cancelled.');this.drawBattle();return;}
    const l=lead(this.state);
    if(!l){this.returnMap();return;}
    const key=ROSTER[l.id].moves[this.sel];
    this.resolveTurn(key);
  }
  resolveTurn(key){
    const l=lead(this.state),e=this.enemy;
    if(!l){this.returnMap();return;}
    let lines=[this.resolve(l,e,key,'You')];
    if(e.hp<=0){this.log=lines.concat(this.log);this.win();return;}
    const ek=Phaser.Utils.Array.GetRandom(ROSTER[e.id].moves);
    lines.push(this.resolve(e,l,ek,ROSTER[e.id].name));
    this.log=lines.concat(this.log).slice(0,8);
    this.turn++;
    if(l.hp<=0){this.lose();return;}
    saveState(this.state);
    this.drawBattle();
  }
  resolve(att,def,key,label){
    let mv=MOVES[key],as=scaledStats(att.id,att.lvl),ds=scaledStats(def.id,def.lvl);
    if(mv.gas>0&&att.gas<mv.gas)mv=MOVES.stall;
    att.gas=Phaser.Math.Clamp(att.gas-Math.max(0,mv.gas),0,as.gas);
    if(mv.gas<0)att.gas=Phaser.Math.Clamp(att.gas+Math.abs(mv.gas),0,as.gas);
    let acc=mv.acc+(att.boost?.1:0);
    if(att.gas<12)acc-=.12;
    att.boost=false;
    if(Math.random()>acc)return `${label} missed ${mv.name}.`;
    const mult=ADV[mv.style]===ROSTER[def.id].style?1.22:ADV[ROSTER[def.id].style]===mv.style?.88:1;
    const dmg=Math.max(3,Math.round((mv.power+as.atk*.8-ds.def*.38)*mult*(.86+Math.random()*.28)));
    def.hp=Phaser.Math.Clamp(def.hp-dmg,0,ds.hp);
    att.score=(att.score||0)+mv.points;
    return `${label} used ${mv.name} for ${dmg} condition.`;
  }
  win(){
    const l=lead(this.state);
    this.over=true;this.pendingForfeit=false;
    this.state.grit+=this.type==='captain'?22:Phaser.Math.Between(6,10);
    this.state.rep+=this.type==='captain'?14:Phaser.Math.Between(2,5);
    if(l)addXp(l,10+this.enemy.lvl*5).forEach(x=>this.log.unshift(x));
    if(this.type==='captain'&&!this.state.badges.includes('Neutral Badge')){this.state.badges.push('Neutral Badge');this.log.unshift('Badge earned: Neutral Badge!');}
    if(this.type==='wild'){this.recruit=true;this.log.unshift('Recruit window open. Use a Roster Invite.');}
    this.state.message=`Victory over ${ROSTER[this.enemy.id].name}.`;
    saveState(this.state);
    this.drawBattle();
  }
  lose(){
    this.over=true;this.pendingForfeit=false;
    this.state.grit+=4;this.state.rep+=2;
    this.state.party.forEach(m=>{const s=scaledStats(m.id,m.lvl);m.hp=s.hp;m.gas=s.gas;});
    this.state.message='Loss: +4 Grit, +2 Rep. Team recovered.';
    saveState(this.state);
    this.scene.start('OverworldScene');
  }
  tryRecruit(){
    if(this.state.items.invite<=0){this.log.unshift('No Roster Invites.');this.recruit=false;this.drawBattle();return;}
    this.state.items.invite--;this.recruit=false;
    const r=ROSTER[this.enemy.id],odds={Common:.72,Uncommon:.55,Rare:.38,Elite:.16}[r.rarity]||.4;
    if(Math.random()<odds){const m=makeMon(this.enemy.id,this.enemy.lvl);this.state.dex.caught[m.id]=true;if(this.state.party.length<6)this.state.party.push(m);else this.state.box.push(m);this.log.unshift(`${r.name} joined the room!`);}
    else this.log.unshift(`${r.name} passed for now.`);
    saveState(this.state);this.drawBattle();
  }
  forfeit(){
    if(this.over){this.returnMap();return;}
    if(this.pendingForfeit){this.lose();return;}
    this.pendingForfeit=true;
    this.log.unshift('Forfeit match? Press B again to confirm. A cancels.');
    this.drawBattle();
  }
  returnMap(){this.scene.start('OverworldScene');}
}
