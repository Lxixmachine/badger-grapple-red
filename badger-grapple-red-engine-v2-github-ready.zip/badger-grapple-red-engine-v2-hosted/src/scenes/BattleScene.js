import {ROSTER,makeMon,scaledStats,addXp,isRecruitable} from '../data/roster.js';
import {MOVES,ADV} from '../data/moves.js';
import {loadState,saveState,lead,firstHealthy,partyWiped} from '../systems/save.js';
import {uiBox,hpBar,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
const CATCH_ODDS={Common:.62,Uncommon:.46,Rare:.32,Starter:.40,Elite:0,Champion:0};
export class BattleScene extends Phaser.Scene{
  constructor(){super('BattleScene');}
  create(data={}){
    this.state=loadState();
    this.type=data.battleType||'wild';           // wild | trainer | gym
    this.enemyTeam=(data.enemyTeam||[['pacesetter',4]]).map(([id,lvl])=>makeMon(id,lvl));
    this.enemyIdx=0;
    this.trainerId=data.trainerId||null;
    this.trainerName=data.trainerName||data.bossName||null;
    this.reward=data.reward||null;
    this.badge=data.badge||null;
    this.isRival=!!data.rival;
    this.turn=1;this.menu='root';this.sel=0;this.forcedSwap=false;
    this.over=false;this.caught=false;this.lastInputAt=0;this.impact='';this.resultTitle='';
    this.bg=[];this.ui=null;
    const en=ROSTER[this.enemy().id];
    const opener=this.type==='wild'?`A wild ${en.name} steps onto the mat!`:`${this.trainerName||'Opponent'} sends out ${en.name}!`;
    this.log=[opener,'FIGHT to attack. TEAM to swap. ITEM for chews, chalk, invites.'];
    const l=lead(this.state);
    if(l&&l.hp<=0){const i=firstHealthy(this.state);if(i>=0)this.state.active=i;}
    const l2=lead(this.state);
    if(l2){
      const s=scaledStats(l2.id,l2.lvl);
      if(!Number.isFinite(l2.hp))l2.hp=s.hp;
      if(!Number.isFinite(l2.gas)||l2.gas<=0)l2.gas=Math.max(l2.gas||0,Math.round(s.gas*.4));
      l2.score=0;
    }
    this.enemyTeam.forEach(e=>e.score=0);
    this.state.stats={scouts:0,battles:0,wins:0,recruits:0,streak:0,...(this.state.stats||{})};
    this.state.stats.battles++;
    this.state.dex.seen[this.enemy().id]=true;
    saveState(this.state);
    this.input.keyboard.on('keydown-LEFT',()=>this.move(-1));
    this.input.keyboard.on('keydown-RIGHT',()=>this.move(1));
    this.input.keyboard.on('keydown-UP',()=>this.move(-2));
    this.input.keyboard.on('keydown-DOWN',()=>this.move(2));
    this.input.keyboard.on('keydown-ENTER',()=>this.choose());
    this.input.keyboard.on('keydown-SPACE',()=>this.choose());
    this.input.keyboard.on('keydown-ESC',()=>this.backBtn());
    setVirtualHandler(this);
    this.drawBattle();
  }
  enemy(){return this.enemyTeam[this.enemyIdx];}
  okInput(){const now=this.time.now||performance.now();if(now-this.lastInputAt<160)return false;this.lastInputAt=now;return true;}
  handleVirtualButton(k){if(!this.okInput())return;if(k==='left')this.move(-1);if(k==='right')this.move(1);if(k==='up')this.move(-2);if(k==='down')this.move(2);if(k==='a')this.choose();if(k==='b')this.backBtn();}
  addLog(lines){this.log=[...lines,...this.log].slice(0,6);}
  addBg(obj){this.bg.push(obj);return obj;}
  clearBg(){this.bg.forEach(o=>{try{o.destroy();}catch{}});this.bg=[];}
  menuCount(){
    if(this.menu==='root')return 4;
    if(this.menu==='fight'){const l=lead(this.state);return (ROSTER[l?.id]?.moves||[]).length||1;}
    if(this.menu==='team')return this.state.party.length;
    if(this.menu==='item')return 3;
    return 1;
  }
  move(d){
    if(this.over)return;
    this.sel=Phaser.Math.Wrap(this.sel+d,0,this.menuCount());
    this.impact='';
    this.drawBattle();
  }
  backBtn(){
    if(this.over){this.finish();return;}
    if(this.forcedSwap){this.addLog(['Pick a healthy wrestler to send out.']);this.drawBattle();return;}
    if(this.menu!=='root'){this.menu='root';this.sel=0;this.drawBattle();return;}
    this.addLog(['Use RUN to leave a wild match. Scheduled matches must be finished.']);
    this.drawBattle();
  }
  choose(){
    if(this.over){this.finish();return;}
    const l=lead(this.state);
    if(!l){this.finish();return;}
    if(this.forcedSwap&&this.menu!=='team'){this.menu='team';this.sel=Math.max(0,this.state.party.findIndex(m=>m.hp>0));return this.drawBattle();}
    if(this.menu==='root'){
      const opt=['fight','team','item','run'][this.sel];
      if(opt==='fight'){this.menu='fight';this.sel=0;return this.drawBattle();}
      if(opt==='team'){this.menu='team';this.sel=this.state.active;return this.drawBattle();}
      if(opt==='item'){this.menu='item';this.sel=0;return this.drawBattle();}
      if(opt==='run')return this.tryRun();
    }
    if(this.menu==='fight'){
      const key=ROSTER[l.id]?.moves?.[this.sel];
      if(!key){this.addLog(['No move selected.']);return this.drawBattle();}
      return this.resolveTurn(key);
    }
    if(this.menu==='team')return this.trySwap(this.sel);
    if(this.menu==='item')return this.useItem(this.sel);
  }
  // ---------- ACTIONS ----------
  tryRun(){
    if(this.type!=='wild'){this.addLog(['You cannot run from a scheduled match.']);return this.drawBattle();}
    const l=lead(this.state);
    const ls=scaledStats(l.id,l.lvl),es=scaledStats(this.enemy().id,this.enemy().lvl);
    const odds=Phaser.Math.Clamp(.55+(ls.spd-es.spd)*.02,.25,.95);
    if(Math.random()<odds){
      this.over=true;this.resultTitle='GOT AWAY';
      this.state.message='You circled out of the match.';
      this.addLog(['You circled out safely. A/B: return.']);
      saveState(this.state);return this.drawBattle();
    }
    this.addLog(['Could not get away!']);
    this.enemyStrike([]);
  }
  trySwap(i){
    const m=this.state.party[i];
    if(!m)return;
    if(m.hp<=0){this.addLog([`${ROSTER[m.id].name} is out of condition.`]);return this.drawBattle();}
    if(i===this.state.active&&!this.forcedSwap){this.addLog([`${ROSTER[m.id].name} is already on the mat.`]);return this.drawBattle();}
    this.state.active=i;m.score=0;
    const wasForced=this.forcedSwap;this.forcedSwap=false;this.menu='root';this.sel=0;
    this.addLog([`${ROSTER[m.id].name} steps onto the mat!`]);
    saveState(this.state);
    if(wasForced){this.cameras.main.flash(70,255,255,255);return this.drawBattle();}
    this.enemyStrike([]);
  }
  useItem(i){
    const l=lead(this.state);
    if(i===0){ // Energy Chew
      if(this.state.items.energy<=0){this.addLog(['No Energy Chews left.']);return this.drawBattle();}
      this.state.items.energy--;const s=scaledStats(l.id,l.lvl);const old=l.hp;l.hp=Math.min(s.hp,l.hp+40);
      this.addLog([`Energy Chew: HP ${old}→${l.hp}.`]);this.menu='root';this.sel=0;
      return this.enemyStrike([]);
    }
    if(i===1){ // Chalk
      if(this.state.items.chalk<=0){this.addLog(['No Chalk left.']);return this.drawBattle();}
      this.state.items.chalk--;const s=scaledStats(l.id,l.lvl);const old=l.gas;l.gas=Math.min(s.gas,l.gas+35);
      this.addLog([`Chalk up: Gas ${old}→${l.gas}.`]);this.menu='root';this.sel=0;
      return this.enemyStrike([]);
    }
    if(i===2)return this.throwInvite();
  }
  throwInvite(){
    const e=this.enemy(),r=ROSTER[e.id];
    if(this.type!=='wild'){this.addLog(['You cannot recruit mid-dual. Wild matches only.']);return this.drawBattle();}
    if(!isRecruitable(e.id)){this.addLog([`${r.name} cannot be recruited.`]);return this.drawBattle();}
    if(this.state.items.invite<=0){this.addLog(['No Roster Invites. Buy more at the Team Shop.']);return this.drawBattle();}
    this.state.items.invite--;
    const es=scaledStats(e.id,e.lvl);
    const hpFrac=Phaser.Math.Clamp(e.hp/es.hp,0,1);
    const odds=Phaser.Math.Clamp((CATCH_ODDS[r.rarity]??.4)*(1.55-hpFrac),0.03,0.92);
    this.menu='root';this.sel=0;
    if(Math.random()<odds){
      this.caught=true;this.over=true;this.resultTitle='RECRUIT JOINED';
      const m=makeMon(e.id,e.lvl);m.hp=e.hp;
      this.state.dex.caught[e.id]=true;this.state.stats.recruits=(this.state.stats.recruits||0)+1;
      let where='joined your team';
      if(this.state.party.length<6)this.state.party.push(m);else{this.state.box.push(m);where='was sent to the practice box (team full)';}
      this.impact='SIGNED!';
      this.state.message=`${r.name} ${where}.`;
      this.addLog([`${r.name} accepted the invite and ${where}!`,'A/B: return.']);
      const l=lead(this.state);
      if(l)addXp(l,8+e.lvl*3).forEach(x=>this.log.unshift(x));
      saveState(this.state);return this.drawBattle();
    }
    this.addLog([`${r.name} shrugged off the invite. (Weaken them first — low HP raises odds.)`]);
    this.enemyStrike([]);
  }
  // ---------- COMBAT ----------
  resolveTurn(key){
    const l=lead(this.state),e=this.enemy();
    const beforeEnemy=e.hp,beforeYou=l.hp;
    const first=this.resolve(l,e,key,'You');
    const lines=[`Turn ${this.turn}: ${first.line}`];
    this.impact=first.hit?`-${first.dmg}`:'MISS';
    if(e.hp<=0||((l.score||0)-(e.score||0)>=15)){
      if(e.hp>0){lines.push('TECH FALL! Match stopped on points.');this.impact='TECH FALL';e.hp=0;}
      lines.push(`${ROSTER[e.id].name} is out of the match.`);
      this.addLog(lines);
      return this.enemyDown();
    }
    this.enemyStrike(lines,beforeYou,beforeEnemy);
  }
  enemyStrike(lines,beforeYou=null,beforeEnemy=null){
    const l=lead(this.state),e=this.enemy();
    const enemyMoves=ROSTER[e.id]?.moves||['stall'];
    const ek=Phaser.Utils.Array.GetRandom(enemyMoves);
    const second=this.resolve(e,l,ek,ROSTER[e.id].name);
    lines.push(second.line);
    if(beforeYou!==null)lines.push(`HP: You ${beforeYou}→${l.hp} | Opp ${beforeEnemy}→${e.hp}`);
    if((e.score||0)-(l.score||0)>=15&&l.hp>0){l.hp=0;lines.push('TECH FALL against you!');}
    this.addLog(lines);
    this.turn++;
    if(l.hp<=0)return this.playerDown();
    saveState(this.state);
    this.cameras.main.flash(70,255,255,255);
    this.drawBattle();
  }
  resolve(att,def,key,label){
    let mv=MOVES[key]||MOVES.stall,as=scaledStats(att.id,att.lvl),ds=scaledStats(def.id,def.lvl);
    if(mv.gas>0&&att.gas<mv.gas)mv=MOVES.stall;
    att.gas=Phaser.Math.Clamp(att.gas-Math.max(0,mv.gas),0,as.gas);
    if(mv.gas<0)att.gas=Phaser.Math.Clamp(att.gas+Math.abs(mv.gas),0,as.gas);
    let acc=mv.acc+(att.boost?0.1:0);
    if(att.gas<12)acc-=0.12;
    att.boost=false;
    if(Math.random()>acc)return {line:`${label}: ${mv.name} missed.`,hit:false,dmg:0};
    const defStyle=ROSTER[def.id]?.style;
    const mult=ADV[mv.style]===defStyle?1.22:ADV[defStyle]===mv.style?0.88:1;
    const dmg=Math.max(3,Math.round((mv.power+as.atk*.8-ds.def*.38)*mult*(.86+Math.random()*.28)));
    def.hp=Phaser.Math.Clamp(def.hp-dmg,0,ds.hp);
    att.score=(att.score||0)+mv.points;
    const bonus=mult>1?' Style edge.':mult<1?' Bad matchup.':'';
    return {line:`${label}: ${mv.name} hits for ${dmg}.${bonus}`,hit:true,dmg};
  }
  enemyDown(){
    const l=lead(this.state),e=this.enemy();
    if(l){
      const msgs=addXp(l,12+e.lvl*6);
      msgs.forEach(x=>this.log.unshift(x));
    }
    if(this.enemyIdx<this.enemyTeam.length-1){
      this.enemyIdx++;
      const next=this.enemy();
      this.state.dex.seen[next.id]=true;
      this.addLog([`${this.trainerName||'Opponent'} sends out ${ROSTER[next.id].name} (Lv ${next.lvl})!`]);
      this.menu='root';this.sel=0;
      saveState(this.state);
      this.cameras.main.flash(120,255,255,255);
      return this.drawBattle();
    }
    return this.win();
  }
  playerDown(){
    const healthy=this.state.party.some(m=>m.hp>0);
    this.impact='DOWN';
    if(healthy){
      this.addLog([`${ROSTER[lead(this.state).id].name} is out. Send out your next wrestler.`]);
      this.menu='team';this.forcedSwap=true;this.sel=Math.max(0,this.state.party.findIndex(m=>m.hp>0));
      saveState(this.state);
      return this.drawBattle();
    }
    return this.blackout();
  }
  // ---------- OUTCOMES ----------
  win(){
    this.over=true;this.resultTitle='VICTORY';
    this.state.stats.wins=(this.state.stats.wins||0)+1;
    this.state.stats.streak=(this.state.stats.streak||0)+1;
    let gritGain,repGain;
    if(this.type==='gym'){gritGain=24;repGain=16;}
    else if(this.type==='trainer'){gritGain=(this.reward?.grit||8);repGain=(this.reward?.rep||6);}
    else{gritGain=Phaser.Math.Between(6,10);repGain=Phaser.Math.Between(2,5);}
    this.state.grit+=gritGain;this.state.rep+=repGain;
    this.addLog([`Victory reward: +${gritGain} Grit, +${repGain} Rep.`]);
    if(this.type==='trainer'&&this.trainerId){
      this.state.defeated[this.trainerId]=true;
      if(this.isRival){this.state.rivalBeaten=(this.state.rivalBeaten||0)+1;this.log.unshift('Rex: ...good match. This time.');}
    }
    if(this.type==='gym'&&this.badge){
      if(!this.state.badges.includes(this.badge)){
        this.state.badges.push(this.badge);
        this.log.unshift(`Badge earned: ${this.badge}!`);
        if(this.badge==='Conference Title'){this.state.champion=true;this.log.unshift('YOU ARE THE CONFERENCE CHAMPION!');this.resultTitle='CONFERENCE CHAMPION';}
      }else this.log.unshift('Rematch won. Badge already on the wall.');
    }
    this.state.message=`Victory over ${this.trainerName||ROSTER[this.enemy().id].name}.`;
    saveState(this.state);
    this.drawBattle();
  }
  blackout(){
    this.over=true;this.blackedOut=true;this.resultTitle='TEAM WIPED';
    this.state.stats.streak=0;
    const penalty=Math.floor(this.state.grit/2);
    this.state.grit-=penalty;
    this.state.party.forEach(m=>{const s=scaledStats(m.id,m.lvl);m.hp=s.hp;m.gas=s.gas;m.score=0;});
    this.state.mapId='fieldhouse';this.state.pos=null;
    this.state.message=`Team wiped. You paid ${penalty} Grit and recovered at the Field House.`;
    this.addLog([`Whole team is out. -${penalty} Grit.`,'Carried back to the Field House Recovery Center.','A/B: return.']);
    saveState(this.state);
    this.drawBattle();
  }
  finish(){this.scene.start('OverworldScene');}
  // ---------- DRAW ----------
  selectedMove(){const l=lead(this.state);if(!l)return null;const key=ROSTER[l.id]?.moves?.[this.sel];return MOVES[key]||null;}
  styleNote(move){if(!move)return 'NO MOVE';const er=ROSTER[this.enemy().id];if(!er)return 'UNKNOWN';if(ADV[move.style]===er.style)return 'STYLE EDGE';if(ADV[er.style]===move.style)return 'BAD MATCHUP';return 'NEUTRAL';}
  drawBattle(){
    this.clearBg();
    if(this.ui)this.ui.destroy(true);
    this.cameras.main.setBackgroundColor('#16181e');
    this.addBg(this.add.rectangle(240,216,480,432,0x16181e).setDepth(0));
    this.addBg(this.add.rectangle(240,169,480,112,0xbe1e2d).setDepth(1));
    this.addBg(this.add.ellipse(240,172,300,72,0xbe1e2d).setStrokeStyle(8,0xf3e7c2).setDepth(2));
    this.addBg(this.add.ellipse(240,172,96,30,0xbe1e2d).setStrokeStyle(4,0xf3e7c2).setDepth(2));
    this.addBg(uiBox(this,18,38,204,76).setDepth(3));
    this.addBg(uiBox(this,258,38,204,76).setDepth(3));
    this.addBg(uiBox(this,18,230,444,86).setDepth(3));
    this.addBg(uiBox(this,18,322,444,98).setDepth(3));
    this.ui=this.add.container(0,0).setDepth(20);
    const l=lead(this.state);
    if(!l){this.over=true;this.addLog(['No wrestler found. Press A/B to return.']);}
    const lr=l?ROSTER[l.id]:ROSTER.buckshot;
    const e=this.enemy(),er=ROSTER[e.id]||ROSTER.pacesetter;
    const header=this.type==='gym'?`BADGE MATCH • ${this.trainerName||''}`:this.type==='trainer'?`VS ${this.trainerName||'TRAINER'} • MATCH ${this.enemyIdx+1}/${this.enemyTeam.length}`:'WILD RECRUIT MATCH';
    this.ui.add(this.add.text(240,13,header,{fontFamily:'monospace',fontSize:12,color:'#f4e6c7',fontStyle:'bold'}).setOrigin(.5));
    this.drawWrestler(138,166,lr,true,'YOU');
    this.drawWrestler(342,152,er,false,'OPP');
    if(l)this.drawHudBox(18,38,l,lr,'YOU');
    this.drawHudBox(258,38,e,er,'OPP');
    if(this.impact){
      this.ui.add(this.add.text(240,213,this.impact,{fontFamily:'monospace',fontSize:20,color:'#ffe290',fontStyle:'bold',stroke:'#111',strokeThickness:5}).setOrigin(.5));
    }
    this.ui.add(this.add.text(34,238,'MATCH LOG',{fontFamily:'monospace',fontSize:10,color:'#555',fontStyle:'bold'}));
    this.log.slice(0,4).forEach((line,i)=>{
      this.ui.add(this.add.text(34,253+i*14,line,{fontFamily:'monospace',fontSize:11,color:i===0?'#b41820':'#111',wordWrap:{width:410}}));
    });
    if(this.over)this.drawResultCard();
    else if(this.menu==='fight')this.drawFight();
    else if(this.menu==='team')this.drawTeam();
    else if(this.menu==='item')this.drawItems();
    else this.drawRoot();
  }
  drawWrestler(x,y,r,isBack,label){
    const key='battle_'+(r?.asset||'neutral')+(isBack?'_back':'');
    const scale=isBack?1.28:1.34;
    if(this.textures.exists(key)){
      const img=this.add.image(x,y,key).setScale(scale).setFlipX(!isBack);
      if(r?.tint)img.setTint(r.tint);
      this.ui.add(img);
    }else{
      this.ui.add(this.add.ellipse(x,y,56,74,isBack?0xb41820:0x2c3442).setStrokeStyle(4,0xf2e6c6));
    }
    this.ui.add(this.add.text(x,y+54,label,{fontFamily:'monospace',fontSize:10,color:'#f4e6c7',fontStyle:'bold',stroke:'#111',strokeThickness:3}).setOrigin(.5));
  }
  drawHudBox(x,y,m,r,label){
    const s=scaledStats(m.id,m.lvl);
    const name=(r.name||'Wrestler').replace(' Shotmaker','').replace(' Partner','');
    this.ui.add(this.add.text(x+10,y+8,`${label}: ${name} Lv ${m.lvl}`,{fontFamily:'monospace',fontSize:10,color:'#111',fontStyle:'bold'}));
    this.ui.add(hpBar(this,x+12,y+30,170,8,m.hp/s.hp,0x55b867));
    this.ui.add(hpBar(this,x+12,y+45,170,6,m.gas/s.gas,0x5aa4e6));
    this.ui.add(this.add.text(x+12,y+58,`HP ${m.hp}/${s.hp} • Score ${m.score||0}`,{fontFamily:'monospace',fontSize:9,color:'#333'}));
  }
  drawRoot(){
    const opts=['FIGHT','TEAM','ITEM','RUN'];
    this.ui.add(this.add.text(34,331,'COMMAND',{fontFamily:'monospace',fontSize:10,color:'#555',fontStyle:'bold'}));
    opts.forEach((o,i)=>{
      const tx=44+(i%2)*214,ty=350+Math.floor(i/2)*26;
      const dim=(o==='RUN'&&this.type!=='wild');
      this.ui.add(this.add.text(tx,ty,`${i===this.sel?'▶ ':'  '}${o}`,{fontFamily:'monospace',fontSize:14,color:i===this.sel?'#b41820':dim?'#999':'#111',fontStyle:'bold'}));
    });
    const hint=this.type==='wild'?'Weaken the recruit, then ITEM → Roster Invite to sign them.':'Scheduled match: win it or swap through your team.';
    this.ui.add(this.add.text(240,410,hint,{fontFamily:'monospace',fontSize:9,color:'#555',fontStyle:'bold'}).setOrigin(.5));
  }
  drawFight(){
    const mv=this.selectedMove();
    this.ui.add(this.add.text(34,331,'MOVES  (B: back)',{fontFamily:'monospace',fontSize:10,color:'#555',fontStyle:'bold'}));
    const l=lead(this.state);
    const moves=ROSTER[l?.id]?.moves||[];
    moves.forEach((key,i)=>{
      const m=MOVES[key];if(!m)return;
      const tx=44+(i%2)*214,ty=348+Math.floor(i/2)*22;
      this.ui.add(this.add.text(tx,ty,`${i===this.sel?'▶ ':'  '}${m.name}`,{fontFamily:'monospace',fontSize:12,color:i===this.sel?'#b41820':'#111',fontStyle:'bold'}));
    });
    if(mv){
      const note=this.styleNote(mv);
      const acc=Math.round(mv.acc*100);
      const noteColor=note==='STYLE EDGE'?'#b41820':note==='BAD MATCHUP'?'#7b3f00':'#555';
      this.ui.add(this.add.text(240,398,`${mv.name}: Pow ${mv.power} • Acc ${acc}% • Gas ${mv.gas} • Pts ${mv.points} • ${note}`,{fontFamily:'monospace',fontSize:9,color:noteColor,fontStyle:'bold'}).setOrigin(.5));
    }
    this.ui.add(this.add.text(240,411,'A: ATTACK • D-PAD: PICK • Tech fall at +15 points',{fontFamily:'monospace',fontSize:9,color:'#555',fontStyle:'bold'}).setOrigin(.5));
  }
  drawTeam(){
    this.ui.add(this.add.text(34,329,this.forcedSwap?'SEND OUT NEXT WRESTLER':'TEAM  (B: back)',{fontFamily:'monospace',fontSize:10,color:this.forcedSwap?'#b41820':'#555',fontStyle:'bold'}));
    this.state.party.forEach((m,i)=>{
      const r=ROSTER[m.id],s=scaledStats(m.id,m.lvl);
      const tx=40+(i%2)*216,ty=344+Math.floor(i/2)*24;
      const tag=i===this.state.active?'●':m.hp<=0?'✗':' ';
      this.ui.add(this.add.text(tx,ty,`${i===this.sel?'▶':' '}${tag} ${r.name.slice(0,14)} L${m.lvl} ${m.hp}/${s.hp}`,{fontFamily:'monospace',fontSize:10,color:i===this.sel?'#b41820':m.hp<=0?'#999':'#111',fontStyle:'bold'}));
    });
  }
  drawItems(){
    this.ui.add(this.add.text(34,331,'ITEMS  (B: back)',{fontFamily:'monospace',fontSize:10,color:'#555',fontStyle:'bold'}));
    const items=[
      [`Energy Chew x${this.state.items.energy}`,'Restore 40 HP.'],
      [`Chalk x${this.state.items.chalk}`,'Restore 35 Gas.'],
      [`Roster Invite x${this.state.items.invite}`,this.type==='wild'?'Try to sign this recruit. Low HP = better odds.':'Wild matches only.']];
    items.forEach((it,i)=>{
      this.ui.add(this.add.text(44,350+i*20,`${i===this.sel?'▶ ':'  '}${it[0]}`,{fontFamily:'monospace',fontSize:12,color:i===this.sel?'#b41820':'#111',fontStyle:'bold'}));
    });
    this.ui.add(this.add.text(240,412,items[this.sel][1],{fontFamily:'monospace',fontSize:9,color:'#555',fontStyle:'bold'}).setOrigin(.5));
  }
  drawResultCard(){
    const l=lead(this.state);
    this.ui.add(this.add.text(240,337,this.resultTitle||'RESULT CARD',{fontFamily:'monospace',fontSize:14,color:'#111',fontStyle:'bold'}).setOrigin(.5));
    this.ui.add(this.add.text(240,358,`Score ${l?.score||0}-${this.enemy().score||0} • Turns ${this.turn} • Streak ${this.state.stats.streak||0} • Badges ${this.state.badges.length}`,{fontFamily:'monospace',fontSize:10,color:'#333'}).setOrigin(.5));
    this.ui.add(this.add.text(240,378,'A/B: Return to the map',{fontFamily:'monospace',fontSize:12,color:'#111',fontStyle:'bold'}).setOrigin(.5));
    this.ui.add(this.add.text(240,397,`Grit ${this.state.grit} • Rep ${this.state.rep} • Invites ${this.state.items.invite} • Wins ${this.state.stats.wins||0}`,{fontFamily:'monospace',fontSize:9,color:'#555'}).setOrigin(.5));
  }
}
