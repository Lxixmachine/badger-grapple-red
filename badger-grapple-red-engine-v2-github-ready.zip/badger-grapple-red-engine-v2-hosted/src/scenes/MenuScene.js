import {loadState,saveState,lead,resetState,caughtRecruitCount} from '../systems/save.js';
import {ROSTER,scaledStats,addXp,isRecruitable} from '../data/roster.js';
import {uiBox,hpBar,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
export class MenuScene extends Phaser.Scene{
  constructor(){super('MenuScene');}
  create(data){
    this.parent=data.parent;this.state=loadState();this.tab=data.tab||'main';this.sel=0;this.dexPage=0;this.note='';this.confirmReset=false;this.swapFrom=-1;
    this.cameras.main.setBackgroundColor('rgba(0,0,0,.65)');this.draw();
    this.input.keyboard.on('keydown-UP',()=>this.move(-1));this.input.keyboard.on('keydown-DOWN',()=>this.move(1));
    this.input.keyboard.on('keydown-ENTER',()=>this.choose());this.input.keyboard.on('keydown-SPACE',()=>this.choose());
    this.input.keyboard.on('keydown-ESC',()=>this.back());
    setVirtualHandler(this);
  }
  handleVirtualButton(k){if(k==='up')this.move(-1);if(k==='down')this.move(1);if(k==='a')this.choose();if(k==='b')this.back();}
  optionCount(){
    if(this.tab==='shop')return 6;
    if(this.tab==='dex')return 1;
    if(this.tab==='team')return this.state.party.length+this.state.box.length;
    return 6;
  }
  draw(){
    this.children.removeAll();
    uiBox(this,34,20,412,382);
    const title={shop:'TEAM SHOP',dex:'ROSTERDEX',team:'TEAM MANAGER'}[this.tab]||'MENU';
    this.add.text(240,42,title,{fontFamily:'monospace',fontSize:20,color:'#111',fontStyle:'bold'}).setOrigin(.5);
    this.add.text(240,66,`Grit ${this.state.grit} • Rep ${this.state.rep} • Invites ${this.state.items.invite} • Energy ${this.state.items.energy} • Chalk ${this.state.items.chalk} • Badges ${this.state.badges.length}`,{fontFamily:'monospace',fontSize:9,color:'#333'}).setOrigin(.5);
    if(this.tab==='shop')this.drawShop();
    else if(this.tab==='dex')this.drawDex();
    else if(this.tab==='team')this.drawTeam();
    else this.drawMain();
    this.add.text(240,382,this.note||'A: Select   B: Back',{fontFamily:'monospace',fontSize:10,color:'#333',wordWrap:{width:380},align:'center'}).setOrigin(.5);
  }
  drawMain(){
    const opts=['TEAM MANAGER','TRAIN LEAD (+XP)','USE ENERGY CHEW','ROSTERDEX','SAVE','CLOSE'];
    opts.forEach((o,i)=>this.add.text(58,96+i*31,`${i===this.sel?'▶ ':'  '}${o}`,{fontFamily:'monospace',fontSize:13,color:i===this.sel?'#b41820':'#111',fontStyle:'bold'}));
    this.add.text(232,94,'PARTY',{fontFamily:'monospace',fontSize:13,color:'#333',fontStyle:'bold'});
    this.state.party.slice(0,6).forEach((m,i)=>{
      const r=ROSTER[m.id],s=scaledStats(m.id,m.lvl);
      this.add.text(232,115+i*27,`${i===this.state.active?'▶':' '} ${r.name.slice(0,16)} Lv ${m.lvl}`,{fontFamily:'monospace',fontSize:9,color:'#111'});
      hpBar(this,236,128+i*27,130,5,m.hp/s.hp,0x55b867);
      hpBar(this,236,136+i*27,130,4,m.gas/s.gas,0x5aa4e6);
    });
    this.add.text(232,290,`Box: ${this.state.box.length} • Wins ${this.state.stats.wins||0} • Streak ${this.state.stats.streak||0}`,{fontFamily:'monospace',fontSize:9,color:'#555'});
    this.add.text(232,306,`Badges: ${this.state.badges.join(', ')||'none yet'}`,{fontFamily:'monospace',fontSize:8,color:'#7b3f00',wordWrap:{width:196}});
  }
  drawShop(){
    const stock=this.stock();
    stock.forEach((it,i)=>{
      this.add.text(64,98+i*36,`${i===this.sel?'▶ ':'  '}${it[0]} ${it[2]?it[2]+' REP':''}`,{fontFamily:'monospace',fontSize:14,color:i===this.sel?'#b41820':'#111',fontStyle:'bold'});
      this.add.text(88,116+i*36,it[3],{fontFamily:'monospace',fontSize:9,color:'#555'});
    });
  }
  stock(){return [
    ['Energy Chew','energy',6,'Restore 40 HP. Usable in battle.'],
    ['Chalk','chalk',7,'Restore 35 Gas. Usable in battle.'],
    ['Roster Invite','invite',18,'Sign weakened wild recruits mid-match.'],
    ['Mat Tape','tape',9,'Later: injury protection.'],
    ['Film Notes','film',12,'Later: scout odds boost.'],
    ['Close','close',0,'Return to the map.']];}
  drawDex(){
    const ids=Object.keys(ROSTER).filter(id=>isRecruitable(id));
    const caught=ids.filter(id=>this.state.dex.caught[id]).length;
    this.add.text(240,92,`Recruited ${caught}/${ids.length} • Seen ${ids.filter(id=>this.state.dex.seen[id]).length}/${ids.length}`,{fontFamily:'monospace',fontSize:10,color:'#7b3f00',fontStyle:'bold'}).setOrigin(.5);
    ids.forEach((id,i)=>{
      const r=ROSTER[id],known=this.state.dex.seen[id];
      const col=i<11?70:250,row=i%11;
      this.add.text(col,108+row*23,known?`${this.state.dex.caught[id]?'●':'○'} ${r.name.slice(0,17)} ${r.style.slice(0,4)}`:'○ ????',{fontFamily:'monospace',fontSize:10,color:known?(this.state.dex.caught[id]?'#111':'#555'):'#999'});
    });
  }
  drawTeam(){
    this.add.text(240,90,this.swapFrom>=0?'Pick a slot to swap with (A) — B cancels':'A: set active / swap • Pick two to trade slots',{fontFamily:'monospace',fontSize:9,color:'#7b3f00',fontStyle:'bold'}).setOrigin(.5);
    const all=[...this.state.party.map((m,i)=>({m,where:'party',i})),...this.state.box.map((m,i)=>({m,where:'box',i}))];
    all.forEach((slot,i)=>{
      const m=slot.m,r=ROSTER[m.id],s=scaledStats(m.id,m.lvl);
      const y=108+i*24;
      const tag=slot.where==='party'?(slot.i===this.state.active?'ACT':'P'+(slot.i+1)):'BOX';
      const mark=this.swapFrom===i?'⇄':(i===this.sel?'▶':' ');
      this.add.text(58,y,`${mark} [${tag}] ${r.name.slice(0,18)} Lv ${m.lvl}  HP ${m.hp}/${s.hp}`,{fontFamily:'monospace',fontSize:10,color:i===this.sel?'#b41820':this.swapFrom===i?'#7b3f00':'#111',fontStyle:'bold'});
    });
    if(!all.length)this.add.text(240,140,'No wrestlers yet.',{fontFamily:'monospace',fontSize:11,color:'#555'}).setOrigin(.5);
  }
  move(d){this.confirmReset=false;this.note='';this.sel=Phaser.Math.Wrap(this.sel+d,0,Math.max(1,this.optionCount()));this.draw();}
  choose(){
    if(this.tab==='shop')return this.chooseShop();
    if(this.tab==='dex')return this.back();
    if(this.tab==='team')return this.chooseTeam();
    if(this.sel===0){this.tab='team';this.sel=0;this.swapFrom=-1;return this.draw();}
    if(this.sel===1)return this.train();
    if(this.sel===2)return this.energy();
    if(this.sel===3){this.tab='dex';this.sel=0;this.note='B returns to menu.';return this.draw();}
    if(this.sel===4){saveState(this.state);this.note='Saved. Progress is stored on this phone.';return this.draw();}
    if(this.sel===5)return this.close();
  }
  chooseTeam(){
    const all=[...this.state.party.map((m,i)=>({m,where:'party',i})),...this.state.box.map((m,i)=>({m,where:'box',i}))];
    if(!all.length)return;
    const cur=all[this.sel];if(!cur)return;
    if(this.swapFrom<0){
      if(cur.where==='party'&&cur.i!==this.state.active&&cur.m.hp>0){
        // first press on a healthy party member: quick option — set active OR begin swap
        this.state.active=cur.i;saveState(this.state);this.note=`${ROSTER[cur.m.id].name} is now your lead. Press A again on a slot to swap positions.`;
      }
      this.swapFrom=this.sel;
      return this.draw();
    }
    if(this.swapFrom===this.sel){this.swapFrom=-1;this.note='Swap cancelled.';return this.draw();}
    const a=all[this.swapFrom],b=all[this.sel];
    // enforce: party can't exceed 6, party can't be emptied
    const getRef=s=>s.where==='party'?this.state.party:this.state.box;
    const tmp=getRef(a)[a.i];getRef(a)[a.i]=getRef(b)[b.i];getRef(b)[b.i]=tmp;
    if(this.state.party.length&&this.state.party.every(m=>!m))this.state.party=this.state.party.filter(Boolean);
    if(!lead(this.state)||lead(this.state).hp<0)this.state.active=0;
    this.state.active=Math.min(this.state.active,Math.max(0,this.state.party.length-1));
    saveState(this.state);
    this.swapFrom=-1;this.note='Slots traded.';
    this.draw();
  }
  chooseShop(){
    const it=this.stock()[this.sel];
    if(it[1]==='close')return this.close();
    if(this.state.rep>=it[2]){this.state.rep-=it[2];this.state.items[it[1]]++;saveState(this.state);this.note=`Bought ${it[0]}.`;}
    else this.note=`Need ${it[2]} Rep.`;
    this.draw();
  }
  train(){
    const l=lead(this.state);
    if(!l){this.note='No starter.';return this.draw();}
    const cost=8+l.lvl;
    if(this.state.grit>=cost){this.state.grit-=cost;const msgs=addXp(l,14+l.lvl*3);saveState(this.state);this.note=msgs[0]||`${ROSTER[l.id].name} gained practice XP. (-${cost} Grit)`;}
    else this.note=`Need ${cost} Grit to train.`;
    this.draw();
  }
  energy(){
    const l=lead(this.state);
    if(!l){this.note='No starter.';return this.draw();}
    if(this.state.items.energy<=0){this.note='No Energy Chews.';return this.draw();}
    this.state.items.energy--;
    const s=scaledStats(l.id,l.lvl);const old=l.hp;l.hp=Math.min(s.hp,l.hp+40);
    saveState(this.state);this.note=`Energy used. HP ${old}→${l.hp}.`;this.draw();
  }
  back(){
    if(this.tab==='team'&&this.swapFrom>=0){this.swapFrom=-1;this.note='Swap cancelled.';return this.draw();}
    if(this.tab!=='main'){this.tab='main';this.sel=0;this.note='';return this.draw();}
    this.close();
  }
  close(){this.scene.stop();if(this.parent?.drawHud)this.parent.drawHud();if(this.parent?.handleVirtualButton)setVirtualHandler(this.parent);}
}
