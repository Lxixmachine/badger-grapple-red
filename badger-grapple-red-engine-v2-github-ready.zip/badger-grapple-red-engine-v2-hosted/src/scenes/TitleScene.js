import {loadState,resetState,caughtRecruitCount} from '../systems/save.js';import {uiBox,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
export class TitleScene extends Phaser.Scene{
  constructor(){super('TitleScene');}
  create(){
    this.state=loadState();this.sel=0;this.opts=['NEW GAME','CONTINUE','RESET SAVE'];
    this.cameras.main.setBackgroundColor('#15171d');
    this.add.rectangle(240,58,480,116,0x651018);this.add.rectangle(240,236,480,280,0x1e2028);
    this.add.image(240,102,'logo').setScale(1.18);
    this.add.image(158,224,'battle_badger').setScale(1.75);this.add.image(322,210,'battle_top').setScale(1.85).setFlipX(true);
    uiBox(this,28,154,424,54);this.add.text(240,173,'RECRUITING RPG PHONE TEST',{fontFamily:'monospace',fontSize:16,color:'#111',fontStyle:'bold'}).setOrigin(.5);this.add.text(240,191,'Scout • Challenge • Win • Invite • Build the room',{fontFamily:'monospace',fontSize:10,color:'#444'}).setOrigin(.5);
    uiBox(this,50,282,182,92);this.texts=this.opts.map((o,i)=>this.add.text(76,303+i*21,o,{fontFamily:'monospace',fontSize:14,color:'#111',fontStyle:'bold'}));
    uiBox(this,248,282,182,92);this.statText=this.add.text(264,300,'',{fontFamily:'monospace',fontSize:10,color:'#111',wordWrap:{width:150}});
    this.add.text(240,405,'v2.7 • A selects • mobile buttons supported',{fontFamily:'monospace',fontSize:11,color:'#f4e6c7'}).setOrigin(.5);
    this.input.keyboard.on('keydown-UP',()=>this.move(-1));this.input.keyboard.on('keydown-DOWN',()=>this.move(1));this.input.keyboard.on('keydown-ENTER',()=>this.choose());this.input.keyboard.on('keydown-SPACE',()=>this.choose());setVirtualHandler(this);this.render();
  }
  handleVirtualButton(k){if(k==='up')this.move(-1);if(k==='down')this.move(1);if(k==='a')this.choose();if(k==='b'){resetState();this.state=loadState();this.render();}}
  move(d){this.sel=Phaser.Math.Wrap(this.sel+d,0,this.opts.length);this.render();}
  render(){const can=this.state.party?.length;this.texts.forEach((t,i)=>{t.setText(`${i===this.sel?'▶ ':'  '}${this.opts[i]}`);t.setColor(i===this.sel?'#b41820':(i===1&&!can?'#777':'#111'));});const s=this.state.stats||{};this.statText.setText(`Save stats\nRecruits: ${caughtRecruitCount(this.state)}\nBattles: ${s.battles||0}\nWins: ${s.wins||0}\nStreak: ${s.streak||0}`);}
  choose(){if(this.sel===0)this.scene.start('StarterScene');if(this.sel===1&&this.state.party?.length)this.scene.start('OverworldScene');if(this.sel===2){resetState();this.state=loadState();this.render();}}
}
