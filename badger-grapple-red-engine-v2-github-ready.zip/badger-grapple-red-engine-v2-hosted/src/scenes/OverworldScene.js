import {MAPS,getMap,TILE,tileFrames} from '../data/maps.js';
import {ROSTER,scaledStats} from '../data/roster.js';
import {loadState,saveState,lead,caughtRecruitCount,partyWiped} from '../systems/save.js';
import {uiBox,hpBar,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
const TRAINER_KEYS=['t','u','y','r'];
export class OverworldScene extends Phaser.Scene{
  constructor(){super('OverworldScene');}
  create(data={}){
    this.state=loadState();
    if(data.mapId){this.state.mapId=data.mapId;}
    this.map=getMap(this.state.mapId);
    let start=data.spawn?this.map.spawns[data.spawn]:(this.state.pos||this.map.spawns.default);
    if(!start||this.rawTile(start.x,start.y)==='#')start=this.map.spawns.default;
    this.tilePos={...start};
    this.message=this.state.message||'';this.messageOpen=!!this.message;this.moving=false;this.lastInputAt=0;this.steps=0;
    this.cameras.main.setBackgroundColor('#000');
    this.drawMap();
    this.player=this.add.sprite(this.tilePos.x*TILE+16,this.tilePos.y*TILE+6,'player',0).setDepth(20);this.player.setOrigin(.5,.8);
    this.marker=this.add.text(this.player.x,this.player.y-28,'A',{fontFamily:'monospace',fontSize:13,color:'#ffe290',fontStyle:'bold',stroke:'#111',strokeThickness:3}).setOrigin(.5).setDepth(21);
    this.cameras.main.startFollow(this.player,true,.15,.15);
    this.cameras.main.setBounds(0,0,this.map.grid[0].length*TILE,this.map.grid.length*TILE);
    this.cursors=this.input.keyboard.createCursorKeys();this.keys=this.input.keyboard.addKeys('W,A,S,D,ENTER,SPACE,M');
    this.input.keyboard.on('keydown-ENTER',()=>this.interact());this.input.keyboard.on('keydown-SPACE',()=>this.interact());this.input.keyboard.on('keydown-M',()=>this.openMenu());
    setVirtualHandler(this);this.hud=this.add.container(0,0).setScrollFactor(0).setDepth(100);this.drawHud();
    this.state.pos={...this.tilePos};saveState(this.state);
  }
  rawTile(x,y){const g=this.map.grid;if(y<0||y>=g.length||x<0||x>=g[0].length)return '#';return g[y][x];}
  tile(x,y){const ch=this.rawTile(x,y);return TRAINER_KEYS.includes(ch)?ch:ch;}
  okInput(){const now=this.time.now||performance.now();if(now-this.lastInputAt<105)return false;this.lastInputAt=now;return true;}
  handleVirtualButton(k){if(!this.okInput())return;if(k==='up')this.tryMove(0,-1,'up');if(k==='down')this.tryMove(0,1,'down');if(k==='left')this.tryMove(-1,0,'left');if(k==='right')this.tryMove(1,0,'right');if(k==='a')this.interact();if(k==='menu')this.openMenu();if(k==='save')this.savePos('Saved. Progress stored on this phone.');}
  update(){if(this.moving)return;if(Phaser.Input.Keyboard.JustDown(this.cursors.left)||Phaser.Input.Keyboard.JustDown(this.keys.A))this.tryMove(-1,0,'left');if(Phaser.Input.Keyboard.JustDown(this.cursors.right)||Phaser.Input.Keyboard.JustDown(this.keys.D))this.tryMove(1,0,'right');if(Phaser.Input.Keyboard.JustDown(this.cursors.up)||Phaser.Input.Keyboard.JustDown(this.keys.W))this.tryMove(0,-1,'up');if(Phaser.Input.Keyboard.JustDown(this.cursors.down)||Phaser.Input.Keyboard.JustDown(this.keys.S))this.tryMove(0,1,'down');}
  openMenu(){if(this.messageOpen){this.clearMessage();return;}this.scene.launch('MenuScene',{parent:this});}
  trainerAt(x,y){const ch=this.rawTile(x,y);if(!TRAINER_KEYS.includes(ch))return null;return (this.map.trainers||[]).find(t=>t.key===ch)||null;}
  drawMap(){
    const g=this.map.grid;
    for(let y=0;y<g.length;y++)for(let x=0;x<g[0].length;x++){
      const ch=g[y][x];
      let frame=tileFrames[ch];
      if(frame===undefined)frame=/\d/.test(ch)?8:0;
      this.add.image(x*TILE+16,y*TILE+16,'tiles',frame);
      if(TRAINER_KEYS.includes(ch)){
        this.add.image(x*TILE+16,y*TILE+16,'tiles',0);
        const tr=this.trainerAt(x,y);
        const beaten=tr&&this.state.defeated[tr.id];
        const spr=this.add.sprite(x*TILE+16,y*TILE+6,'npc',0).setDepth(15);spr.setOrigin(.5,.8);
        if(beaten)spr.setAlpha(.55);
        if(tr?.rival)spr.setTint(0x9db8ff);
        this.add.text(x*TILE+16,y*TILE-30,beaten?'✓':'!',{fontFamily:'monospace',fontSize:13,color:beaten?'#8fdca0':'#ff5b5b',fontStyle:'bold',stroke:'#111',strokeThickness:3}).setOrigin(.5).setDepth(16);
      }
      const label={R:'+',S:'$',C:'★',T:'!',N:'?'}[ch]||(/\d/.test(ch)?'⇄':null);
      if(label)this.add.text(x*TILE+16,y*TILE+9,label,{fontFamily:'monospace',fontSize:15,color:'#fff',fontStyle:'bold'}).setOrigin(.5).setDepth(4);
      if(ch==='g'&&((x+y)%3===0))this.add.text(x*TILE+16,y*TILE+19,'•',{fontFamily:'monospace',fontSize:11,color:'#fff7bc'}).setOrigin(.5).setDepth(5);
    }
  }
  pass(x,y){return this.rawTile(x,y)!=='#';}
  badgeCount(){return this.state.badges.length;}
  objective(){
    const b=this.badgeCount();
    if(!this.state.party.length)return 'Choose a starter.';
    if(this.state.champion)return 'Conference Champion! Free play: fill the RosterDex (14 recruitables).';
    if(b===0)return 'Objective: beat the ★ Captain in the Field House for badge 1.';
    if(b===1)return 'Objective: head north through Campus Quad to Lakeshore. Gym 2 is the Pavilion (east).';
    if(b===2)return 'Objective: Downtown Route is open (north of Lakeshore). Gym 3 is the Club.';
    if(b===3)return 'Objective: the Conference Arena is open below the Club. Win the title.';
    return 'Objective: build the full room and fill the RosterDex.';
  }
  promptFor(ch){
    if(ch==='R')return 'A: Recovery Center — restore HP and gas';
    if(ch==='S')return 'A: Team Shop — buy energy, chalk, invites';
    if(ch==='C'){const boss=this.map.boss;if(boss&&this.state.badges.includes(boss.badge))return `A: rematch ${ROSTER[boss.id].name} (badge earned)`;return `A: ★ ${this.map.boss?ROSTER[this.map.boss.id].name:'Gym'} — badge match`;}
    if(ch==='g')return 'Grass: recruits hide here. Walk to encounter, or press A to scout.';
    if(ch==='T'||ch==='N')return 'A: talk';
    if(/\d/.test(ch)){const wp=this.map.warps[ch];if(wp){const need=wp.gate||0;return need>this.badgeCount()?`Locked door — needs ${need} badge${need>1?'s':''}`:`A: enter ${getMap(wp.map).name}`;}}
    return `${this.map.name} • ${this.map.region}`;
  }
  tryMove(dx,dy,dir){
    if(this.messageOpen){this.clearMessage();return;}
    const nx=this.tilePos.x+dx,ny=this.tilePos.y+dy;
    const ch=this.rawTile(nx,ny);
    if(TRAINER_KEYS.includes(ch)){const tr=this.trainerAt(nx,ny);if(tr&&!this.state.defeated[tr.id]){this.startTrainer(tr);return;}this.showMessage(tr?tr.beaten:'...');return;}
    if(!this.pass(nx,ny)){this.showMessage('Blocked. Try another direction.');return;}
    this.tilePos={x:nx,y:ny};this.moving=true;this.player.play('walk-'+dir,true);
    this.tweens.add({targets:this.player,x:nx*TILE+16,y:ny*TILE+6,duration:118,ease:'Linear',
      onUpdate:()=>this.marker.setPosition(this.player.x,this.player.y-28),
      onComplete:()=>{
        this.moving=false;this.player.stop();this.player.setFrame(dir==='down'?0:dir==='left'?3:dir==='right'?6:9);
        this.marker.setPosition(this.player.x,this.player.y-28);this.drawHud();
        this.onStep(ch);
      }});
  }
  onStep(ch){
    if(/\d/.test(ch)){this.tryWarp(ch);return;}
    if(ch==='g'&&this.map.encounters.length&&this.state.party.length&&!partyWiped(this.state)){
      this.steps++;
      if(Math.random()<this.map.encounterRate){this.wildEncounter();}
    }
  }
  tryWarp(ch){
    const wp=this.map.warps[ch];if(!wp)return;
    const need=wp.gate||0;
    if(this.badgeCount()<need){this.showMessage(`This door needs ${need} badge${need>1?'s':''}. You have ${this.badgeCount()}.`);return;}
    this.state.mapId=wp.map;this.state.pos=null;this.state.message=`Entered ${getMap(wp.map).name}.`;saveState(this.state);
    this.cameras.main.fadeOut(180,0,0,0);
    this.time.delayedCall(190,()=>this.scene.restart({mapId:wp.map,spawn:wp.spawn}));
  }
  pickEncounter(){
    const total=this.map.encounters.reduce((a,[,w])=>a+w,0);
    let roll=Math.random()*total;
    for(const [id,w] of this.map.encounters){roll-=w;if(roll<=0)return id;}
    return this.map.encounters[0][0];
  }
  wildEncounter(){
    const id=this.pickEncounter();
    const [lo,hi]=this.map.lvlRange;
    const lvl=Phaser.Math.Between(lo,hi);
    this.state.dex.seen[id]=true;this.state.stats.scouts=(this.state.stats.scouts||0)+1;this.savePos();
    this.cameras.main.flash(140,255,255,255);
    this.time.delayedCall(150,()=>this.scene.start('BattleScene',{enemyTeam:[[id,lvl]],battleType:'wild'}));
  }
  startScout(){
    const id=this.pickEncounter();
    const [lo,hi]=this.map.lvlRange;
    const lvl=Phaser.Math.Between(lo,hi);
    this.state.dex.seen[id]=true;this.state.stats.scouts=(this.state.stats.scouts||0)+1;this.savePos();
    this.cameras.main.fadeOut(160,0,0,0);
    this.time.delayedCall(170,()=>this.scene.start('ScoutScene',{id,lvl}));
  }
  rivalTeam(tr){
    const counter=this.state.rivalStarter||'lakechain';
    const lvl=tr.rivalLvl||6;
    const team=[[counter,lvl]];
    if(lvl>=10)team.unshift(['snapartist',lvl-2]);
    return team;
  }
  startTrainer(tr){
    if(partyWiped(this.state)||!this.state.party.length){this.showMessage('Your team needs the Recovery Center first.');return;}
    const team=tr.rival?this.rivalTeam(tr):tr.team;
    this.savePos(null);this.state.message='';saveState(this.state);
    this.showMessage(tr.line);
    this.time.delayedCall(900,()=>{
      this.cameras.main.flash(160,255,255,255);
      this.time.delayedCall(160,()=>this.scene.start('BattleScene',{enemyTeam:team,battleType:'trainer',trainerId:tr.id,trainerName:tr.name,reward:tr.reward,rival:!!tr.rival}));
    });
  }
  startBoss(){
    const boss=this.map.boss;if(!boss)return;
    if(partyWiped(this.state)||!this.state.party.length){this.showMessage('Your team needs the Recovery Center first.');return;}
    const team=boss.championTeam||[[boss.id,boss.lvl]];
    this.state.message='';saveState(this.state);
    this.showMessage(boss.intro);
    this.time.delayedCall(1000,()=>{
      this.cameras.main.flash(160,255,255,255);
      this.time.delayedCall(160,()=>this.scene.start('BattleScene',{enemyTeam:team,battleType:'gym',badge:boss.badge,bossName:ROSTER[boss.id].name}));
    });
  }
  interact(){
    if(this.messageOpen){this.clearMessage();return;}
    // face-adjacent trainer check
    for(const [dx,dy] of [[0,-1],[0,1],[-1,0],[1,0]]){
      const tr=this.trainerAt(this.tilePos.x+dx,this.tilePos.y+dy);
      if(tr){if(this.state.defeated[tr.id])this.showMessage(tr.beaten);else this.startTrainer(tr);return;}
    }
    const ch=this.rawTile(this.tilePos.x,this.tilePos.y);
    if(ch==='R'){this.state.party.forEach(m=>{const s=scaledStats(m.id,m.lvl);m.hp=s.hp;m.gas=s.gas;m.score=0;});this.savePos('Recovery Center: full team restored. HP, gas, and match scores reset.');}
    else if(ch==='S'){this.scene.launch('MenuScene',{parent:this,tab:'shop'});}
    else if(ch==='C'){this.startBoss();}
    else if(ch==='g'){this.startScout();}
    else if(ch==='T'||ch==='N'){this.showMessage(this.map.npcs?.[ch]||'...');}
    else if(/\d/.test(ch)){this.tryWarp(ch);}
    else{this.showMessage(this.promptFor(ch));}
  }
  savePos(msg=null){this.state.pos={...this.tilePos};if(msg)this.state.message=msg;saveState(this.state);if(msg)this.showMessage(msg);}
  showMessage(msg){this.message=msg;this.messageOpen=true;this.drawHud();}
  clearMessage(){this.message='';this.messageOpen=false;this.state.message='';saveState(this.state);this.drawHud();}
  drawHud(){
    this.hud.removeAll(true);
    const top=this.add.graphics().setScrollFactor(0);top.fillStyle(0x000000,.80);top.fillRoundedRect(8,8,464,58,8);this.hud.add(top);
    const l=lead(this.state);
    const leadName=l?`${ROSTER[l.id].name} Lv ${l.lvl}`:'No starter';
    this.hud.add(this.add.text(18,13,`${this.map.name} • ${'●'.repeat(this.badgeCount())||'no badges'} • v3.0`,{fontFamily:'monospace',fontSize:11,color:'#f4e6c7',fontStyle:'bold'}).setScrollFactor(0));
    this.hud.add(this.add.text(18,29,`${leadName}  |  Grit ${this.state.grit}  Rep ${this.state.rep}  Invites ${this.state.items.invite}  Team ${this.state.party.length}/6`,{fontFamily:'monospace',fontSize:10,color:'#f4e6c7'}).setScrollFactor(0));
    this.hud.add(this.add.text(18,46,this.objective(),{fontFamily:'monospace',fontSize:9,color:'#ffe290',wordWrap:{width:300}}).setScrollFactor(0));
    if(l){const s=scaledStats(l.id,l.lvl);this.hud.add(hpBar(this,344,20,110,7,l.hp/s.hp,0x55b867).setScrollFactor(0));this.hud.add(hpBar(this,344,34,110,6,l.gas/s.gas,0x5aa4e6).setScrollFactor(0));}
    const ch=this.rawTile(this.tilePos.x,this.tilePos.y);
    const prompt=this.promptFor(ch);
    const bottom=this.add.graphics().setScrollFactor(0);bottom.fillStyle(0x000000,.78);bottom.fillRoundedRect(10,384,460,38,8);this.hud.add(bottom);
    this.hud.add(this.add.text(22,395,prompt,{fontFamily:'monospace',fontSize:11,color:'#f4e6c7',wordWrap:{width:436}}).setScrollFactor(0));
    this.marker.setVisible((['R','S','C','g','T','N'].includes(ch)||/\d/.test(ch))&&!this.messageOpen);
    if(this.messageOpen&&this.message){
      const box=uiBox(this,20,292,440,88).setScrollFactor(0);this.hud.add(box);
      this.hud.add(this.add.text(38,309,this.message,{fontFamily:'monospace',fontSize:13,color:'#111',wordWrap:{width:400}}).setScrollFactor(0));
      this.hud.add(this.add.text(394,354,'A: OK',{fontFamily:'monospace',fontSize:12,color:'#555',fontStyle:'bold'}).setScrollFactor(0));
    }
  }
}
