export const ROSTER={
 // ---- STARTER LINES (3-stage development, FireRed style) ----
 buckshot:{id:'buckshot',name:'Bucky Shotmaker',weight:'125',style:'Neutral',rarity:'Starter',asset:'badger',color:0xc81f2b,stats:{hp:62,atk:18,def:14,spd:19,gas:74},moves:['single','ankle','sprawl','pace'],bio:'Fast first attack. Great starter.',evolvesTo:'buckvarsity',evolveLvl:11},
 buckvarsity:{id:'buckvarsity',name:'Varsity Bucky',weight:'133',style:'Neutral',rarity:'Starter',asset:'badger',tint:0xffd27d,stats:{hp:76,atk:23,def:18,spd:22,gas:82},moves:['single','highc','reattack','double'],bio:'Earned the varsity singlet.',evolvesTo:'buckallam',evolveLvl:20},
 buckallam:{id:'buckallam',name:'All-American Bucky',weight:'141',style:'Neutral',rarity:'Starter',asset:'badger',tint:0xffe9b0,stats:{hp:92,atk:29,def:22,spd:25,gas:92},moves:['blast','highc','reattack','flurry'],bio:'Podium-level shot selection.'},
 matreturner:{id:'matreturner',name:'Mat Returner',weight:'165',style:'Top',rarity:'Starter',asset:'top',color:0x5f4cc8,stats:{hp:72,atk:17,def:18,spd:12,gas:70},moves:['ride','claw','snap','sprawl'],bio:'Pressure and mat control.',evolvesTo:'matgeneral',evolveLvl:11},
 matgeneral:{id:'matgeneral',name:'Mat General',weight:'174',style:'Top',rarity:'Starter',asset:'top',tint:0xb9a8ff,stats:{hp:88,atk:22,def:23,spd:14,gas:78},moves:['ride','tilt','gut','sprawl'],bio:'Runs the top game like an offense.',evolvesTo:'rideking',evolveLvl:20},
 rideking:{id:'rideking',name:'Ride King',weight:'184',style:'Top',rarity:'Starter',asset:'top',tint:0xd9ccff,stats:{hp:106,atk:28,def:28,spd:16,gas:88},moves:['ride','tilt','cradle','pin'],bio:'Nobody escapes the full ride.'},
 fieldflyer:{id:'fieldflyer',name:'Field House Flyer',weight:'141',style:'Scramble',rarity:'Starter',asset:'scramble',color:0xe47c27,stats:{hp:64,atk:18,def:13,spd:21,gas:69},moves:['scramble','roll','single','snap'],bio:'Chaotic and slippery.',evolvesTo:'funkflyer',evolveLvl:11},
 funkflyer:{id:'funkflyer',name:'Funk Flyer',weight:'149',style:'Scramble',rarity:'Starter',asset:'scramble',tint:0xffc48a,stats:{hp:78,atk:23,def:16,spd:25,gas:77},moves:['scramble','funk','switch','snap'],bio:'Turns bad positions into points.',evolvesTo:'scramblesaint',evolveLvl:20},
 scramblesaint:{id:'scramblesaint',name:'Scramble Saint',weight:'157',style:'Scramble',rarity:'Starter',asset:'scramble',tint:0xffe0bd,stats:{hp:94,atk:29,def:20,spd:29,gas:86},moves:['funk','scramble','cradle','reattack'],bio:'Never in danger. Only in transition.'},
 // ---- COMMONS / ROUTE RECRUITS ----
 pacesetter:{id:'pacesetter',name:'Pace Setter',weight:'149',style:'Pace',rarity:'Common',asset:'pace',color:0x2e9c57,stats:{hp:66,atk:16,def:15,spd:18,gas:86},moves:['pace','double','flurry','stall'],bio:'Wins on volume.'},
 drillpartner:{id:'drillpartner',name:'Drill Partner',weight:'133',style:'Neutral',rarity:'Common',asset:'neutral',color:0xc81f2b,stats:{hp:68,atk:20,def:18,spd:20,gas:80},moves:['single','pace','roll','sprawl'],bio:'Clean technique.'},
 walkonwill:{id:'walkonwill',name:'Walk-On Will',weight:'157',style:'Pace',rarity:'Common',asset:'pace',tint:0x9be3b4,stats:{hp:64,atk:15,def:16,spd:16,gas:90},moves:['pace','grind','snap','stall'],bio:'Outworks everyone in the room.'},
 snapartist:{id:'snapartist',name:'Snap Artist',weight:'165',style:'Upperbody',rarity:'Common',asset:'neutral',tint:0xf0b657,stats:{hp:70,atk:19,def:17,spd:15,gas:76},moves:['snap','throwby','sprawl','pace'],bio:'Heavy hands, heavier snaps.'},
 granbykid:{id:'granbykid',name:'Granby Kid',weight:'125',style:'Scramble',rarity:'Common',asset:'scramble',tint:0xffab6b,stats:{hp:60,atk:17,def:13,spd:23,gas:72},moves:['roll','switch','single','sprawl'],bio:'Rolls out of everything.'},
 // ---- UNCOMMONS ----
 lakechain:{id:'lakechain',name:'Lake Chain',weight:'133',style:'Neutral',rarity:'Uncommon',asset:'neutral',color:0xb82027,stats:{hp:70,atk:21,def:16,spd:22,gas:80},moves:['single','highc','double','reattack'],bio:'One attack becomes three.'},
 lockthrow:{id:'lockthrow',name:'Locke Thrower',weight:'197',style:'Upperbody',rarity:'Uncommon',asset:'top',tint:0x8fd0ff,stats:{hp:80,atk:24,def:19,spd:11,gas:70},moves:['bodylock','headlock','snap','sprawl'],bio:'One lock and the lights go out.'},
 gasman:{id:'gasman',name:'Gas Tank Gundy',weight:'174',style:'Pace',rarity:'Uncommon',asset:'pace',tint:0x6fdb96,stats:{hp:78,atk:19,def:18,spd:17,gas:100},moves:['flurry','grind','pace','double'],bio:'Third period is his period.'},
 whizzkid:{id:'whizzkid',name:'Whizzer Wizard',weight:'149',style:'Defense',rarity:'Uncommon',asset:'neutral',tint:0xbdb6ff,stats:{hp:74,atk:18,def:24,spd:18,gas:82},moves:['whizzer','sprawl','reattack','single'],bio:'You cannot score on him.'},
 // ---- RARES ----
 tilttech:{id:'tilttech',name:'Tilt Technician',weight:'174',style:'Top',rarity:'Rare',asset:'top',color:0x594bc0,stats:{hp:76,atk:24,def:19,spd:15,gas:80},moves:['ride','tilt','pin','claw'],bio:'Nearfall machine.'},
 blastcase:{id:'blastcase',name:'Blast Case',weight:'184',style:'Neutral',rarity:'Rare',asset:'badger',tint:0xff9d9d,stats:{hp:80,atk:27,def:18,spd:20,gas:78},moves:['blast','double','sprawl','flurry'],bio:'Hits doubles through brick walls.'},
 funklord:{id:'funklord',name:'Funk Lord Feld',weight:'157',style:'Scramble',rarity:'Rare',asset:'scramble',tint:0xffd9a8,stats:{hp:78,atk:25,def:17,spd:26,gas:82},moves:['funk','scramble','cradle','switch'],bio:'Inverted is his neutral.'},
 // ---- GYM LEADERS / BOSSES (not recruitable) ----
 captainneutral:{id:'captainneutral',name:'Captain Neutral',weight:'174',style:'Neutral',rarity:'Elite',asset:'neutral',color:0xb71b25,stats:{hp:92,atk:28,def:23,spd:22,gas:92},moves:['single','highc','reattack','flurry'],bio:'First badge test.'},
 pavilionboss:{id:'pavilionboss',name:'Pavilion Anchor',weight:'197',style:'Top',rarity:'Elite',asset:'top',tint:0x7fb5ff,stats:{hp:94,atk:26,def:24,spd:15,gas:90},moves:['ride','tilt','cradle','pin'],bio:'Lakeshore Pavilion badge test.'},
 clubboss:{id:'clubboss',name:'Downtown Dervish',weight:'149',style:'Scramble',rarity:'Elite',asset:'scramble',tint:0xffb36b,stats:{hp:98,atk:28,def:23,spd:27,gas:92},moves:['funk','scramble','cradle','reattack'],bio:'Downtown Club badge test.'},
 rival:{id:'rival',name:'Rex Rivalson',weight:'flex',style:'Neutral',rarity:'Elite',asset:'badger',tint:0x9db8ff,stats:{hp:70,atk:21,def:17,spd:21,gas:80},moves:['single','highc','snap','sprawl'],bio:'Your recruiting-class rival.'},
 champion:{id:'champion',name:'The Conference Champ',weight:'184',style:'Neutral',rarity:'Champion',asset:'badger',tint:0xffe27d,stats:{hp:106,atk:30,def:25,spd:26,gas:98},moves:['blast','highc','reattack','pin'],bio:'The final match. The whole season.'}
};
export const STARTERS=['buckshot','matreturner','fieldflyer'];
export const BOSS_IDS=['captainneutral','pavilionboss','clubboss','rival','champion'];
export function isRecruitable(id){return !BOSS_IDS.includes(id);}
export function scaledStats(id,lvl){const r=ROSTER[id];return {hp:r.stats.hp+lvl*5,atk:r.stats.atk+Math.floor(lvl*1.6),def:r.stats.def+Math.floor(lvl*1.3),spd:r.stats.spd+Math.floor(lvl*1.1),gas:r.stats.gas+lvl*2};}
export function makeMon(id,lvl){const s=scaledStats(id,lvl);return {id,lvl,xp:0,hp:s.hp,gas:s.gas,score:0,boost:false};}
export function xpNeed(m){return 18+m.lvl*9;}
export function addXp(m,amt){
  const out=[];m.xp+=amt;
  while(m.xp>=xpNeed(m)){
    m.xp-=xpNeed(m);m.lvl++;
    const r=ROSTER[m.id];
    if(r.evolvesTo&&m.lvl>=r.evolveLvl){
      const oldName=r.name;m.id=r.evolvesTo;
      out.push(`${oldName} developed into ${ROSTER[m.id].name}!`);
    }else{
      out.push(`${ROSTER[m.id].name} grew to Lv ${m.lvl}!`);
    }
    const s=scaledStats(m.id,m.lvl);m.hp=s.hp;m.gas=s.gas;
  }
  return out;
}
