import {initAudioUnlock,kickAudio} from './systems/audio.js';import {BootScene} from './scenes/BootScene.js';import {TitleScene} from './scenes/TitleScene.js';import {StarterScene} from './scenes/StarterScene.js';import {OverworldScene} from './scenes/OverworldScene.js';import {ScoutScene} from './scenes/ScoutScene.js';import {BattleScene} from './scenes/BattleScene.js';import {MenuScene} from './scenes/MenuScene.js';
const Phaser = window.Phaser;
const config={type:Phaser.AUTO,parent:'game',backgroundColor:'#09090b',pixelArt:true,roundPixels:true,width:480,height:432,scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH},scene:[BootScene,TitleScene,StarterScene,OverworldScene,ScoutScene,BattleScene,MenuScene]};
const game=new Phaser.Game(config);
window.badgerGame=game;
window.BADGER_VERSION='14.0-juice-audio';
initAudioUnlock();
function routeVirtualButton(key){
  kickAudio();
  const priority=['MenuScene','BattleScene','ScoutScene','StarterScene','TitleScene','OverworldScene'];
  for(const sceneKey of priority){
    const scene=game.scene.getScene(sceneKey);
    if(scene&&scene.scene&&scene.scene.isActive()&&scene.handleVirtualButton){
      scene.handleVirtualButton(key);
      return;
    }
  }
  const fallback=window.__fallbackControlScene;
  if(fallback&&fallback.handleVirtualButton)fallback.handleVirtualButton(key);
}
window.engineControl=routeVirtualButton;
document.querySelectorAll('[data-key]').forEach(b=>{
  b.addEventListener('click',e=>{
    e.preventDefault();
    routeVirtualButton(b.dataset.key);
  },{passive:false});
});
