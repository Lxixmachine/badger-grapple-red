import {makeMon,scaledStats,ROSTER} from '../data/roster.js';
const KEY='badger_grapple_red_engine_v2';
const SAVE_VERSION='14.0';
export function defaultState(){return {version:SAVE_VERSION,currentMap:'fieldhouse',party:[],box:[],active:0,dex:{seen:{},caught:{}},grit:12,rep:8,items:{invite:3,energy:2,chalk:1,tape:1,film:1},badges:[],trainersDefeated:{},flags:{},rivalStarter:null,stats:{scouts:0,battles:0,wins:0,recruits:0,streak:0,blackouts:0},pos:null,message:'Welcome to Badger Grapple Red.'};}
function normalizeMon(m){if(!m||!ROSTER[m.id])return null;const lvl=Number.isFinite(m.lvl)?m.lvl:2;const s=scaledStats(m.id,lvl);return {id:m.id,lvl,xp:Number.isFinite(m.xp)?m.xp:0,hp:Math.max(0,Math.min(s.hp,Number.isFinite(m.hp)?m.hp:s.hp)),gas:Math.max(0,Math.min(s.gas,Number.isFinite(m.gas)?m.gas:s.gas)),score:Number.isFinite(m.score)?m.score:0,boost:!!m.boost};}
export function normalizeState(state){
  const d=defaultState();
  if(!state||typeof state!=='object')return d;
  const out={...d,...state};
  out.version=SAVE_VERSION;
  out.currentMap=typeof state.currentMap==='string'?state.currentMap:(state.pos?.map||d.currentMap);
  out.party=(Array.isArray(state.party)?state.party:[]).map(normalizeMon).filter(Boolean).slice(0,6);
  out.box=(Array.isArray(state.box)?state.box:[]).map(normalizeMon).filter(Boolean);
  out.active=Number.isInteger(state.active)?Math.max(0,Math.min(state.active,out.party.length-1)):0;
  out.dex={seen:{...(state.dex?.seen||{})},caught:{...(state.dex?.caught||{})}};
  out.items={...d.items,...(state.items||{})};
  out.badges=Array.isArray(state.badges)?state.badges:[];
  out.trainersDefeated={...(state.trainersDefeated||{})};
  out.flags={...(state.flags||{})};
  out.rivalStarter=state.rivalStarter||state.party?.[0]?.id||null;
  out.stats={...d.stats,...(state.stats||{})};
  out.grit=Number.isFinite(state.grit)?state.grit:d.grit;
  out.rep=Number.isFinite(state.rep)?state.rep:d.rep;
  out.pos=state.pos&&Number.isFinite(state.pos.x)&&Number.isFinite(state.pos.y)?{x:state.pos.x,y:state.pos.y}:null;
  out.message=typeof state.message==='string'?state.message:'';
  return out;
}
export function loadState(){try{return normalizeState(JSON.parse(localStorage.getItem(KEY))||defaultState());}catch{return defaultState();}}
export function saveState(state){try{localStorage.setItem(KEY,JSON.stringify(normalizeState(state)));}catch{}}
export function resetState(){try{localStorage.removeItem(KEY);}catch{}}
export function chooseStarter(id){const s=defaultState();s.party=[makeMon(id,6)];s.rivalStarter=id;s.dex.seen[id]=true;s.dex.caught[id]=true;s.currentMap='fieldhouse';s.pos={x:13,y:12};s.message='Coach: Good choice. Walk the green scout zones, build a party, and chase badges.';saveState(s);return s;}
export function lead(state){if(!state.party.length)return null;if(!state.party[state.active])state.active=0;return state.party[state.active];}
export function firstHealthyIndex(state){return state.party.findIndex(m=>m&&m.hp>0);}
export function healthyParty(state){return state.party.filter(m=>m&&m.hp>0);}
export function healTeam(state){state.party.forEach(m=>{const s=scaledStats(m.id,m.lvl);m.hp=s.hp;m.gas=s.gas;m.score=0;m.boost=false;});if(state.party.length)state.active=Math.max(0,firstHealthyIndex(state));return state;}
export function caughtRecruitCount(state){return Object.keys(state.dex?.caught||{}).filter(id=>state.dex.caught[id]).length;}
