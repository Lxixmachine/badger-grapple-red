const Phaser = window.Phaser;
export function uiBox(scene,x,y,w,h){const g=scene.add.graphics();g.fillStyle(0xf8f0d8,1);g.fillRect(x,y,w,h);g.lineStyle(2,0x101010,1);g.strokeRect(x,y,w,h);g.lineStyle(1,0x847868,1);g.strokeRect(x+3,y+3,w-6,h-6);return g;}
export function hpBar(scene,x,y,w,h,p,color=0x55b867){const g=scene.add.graphics();g.fillStyle(0x222222,1);g.fillRect(x,y,w,h);g.fillStyle(color,1);g.fillRect(x,y,Math.max(1,w*Phaser.Math.Clamp(p,0,1)),h);g.lineStyle(1,0x111111,1);g.strokeRect(x,y,w,h);return g;}
export function setVirtualHandler(scene){window.__fallbackControlScene=scene;}
export const FONT='monospace';
