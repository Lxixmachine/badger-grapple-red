const KEY='badger_grapple_audio_muted_v1';
const AudioContextClass=()=>window.AudioContext||window.webkitAudioContext;
let ctx=null,master=null,currentMode='title',timer=null,step=0,unlocked=false,initialized=false;
let muted=false;
try{muted=localStorage.getItem(KEY)==='1';}catch{}
const FREQ={C2:65.41,D2:73.42,E2:82.41,F2:87.31,G2:98.0,A2:110.0,B2:123.47,C3:130.81,D3:146.83,E3:164.81,F3:174.61,G3:196.0,A3:220.0,B3:246.94,C4:261.63,D4:293.66,E4:329.63,F4:349.23,G4:392.0,A4:440.0,B4:493.88,C5:523.25,D5:587.33,E5:659.25,G5:783.99};
const PATTERNS={
 title:{bpm:122,lead:['C4',null,'E4',null,'G4',null,'E4',null,'D4',null,'F4',null,'A4',null,'G4',null],bass:['C2',null,null,null,'G2',null,null,null,'A2',null,null,null,'G2',null,null,null],hat:[0,4,8,12]},
 overworld:{bpm:138,lead:['E4',null,'G4','A4',null,'G4','E4',null,'D4',null,'E4','G4',null,'E4','D4',null],bass:['C2',null,'G2',null,'C3',null,'G2',null,'D2',null,'A2',null,'D3',null,'A2',null],hat:[2,6,10,14]},
 gym:{bpm:132,lead:['C4','D4',null,'E4','G4',null,'E4',null,'F4','E4',null,'D4','C4',null,'G3',null],bass:['C2',null,null,'C2','G2',null,null,'G2','F2',null,null,'F2','G2',null,null,'G2'],hat:[0,4,8,12]},
 battle:{bpm:168,lead:['C4','E4','G4',null,'A4','G4','E4',null,'D4','F4','A4',null,'B4','A4','G4',null],bass:['C2',null,'C2',null,'G2',null,'G2',null,'A2',null,'A2',null,'G2',null,'G2',null],hat:[0,2,4,6,8,10,12,14]},
 champion:{bpm:176,lead:['G4','A4','C5',null,'B4','A4','G4',null,'E4','G4','B4',null,'D5','C5','B4',null],bass:['C2',null,'C3',null,'B2',null,'B2',null,'A2',null,'A2',null,'G2',null,'G2',null],hat:[0,2,4,6,8,10,12,14]},
 victory:{bpm:150,lead:['C4','E4','G4','C5',null,'G4','C5',null,'E5',null,'D5',null,'C5',null,null,null],bass:['C2',null,'G2',null,'C3',null,'G2',null,'C2',null,null,null,null,null,null,null],hat:[0,4,8,12]}
};
function ensure(){if(ctx||typeof window==='undefined')return !!ctx;const Ctx=AudioContextClass();if(!Ctx)return false;ctx=new Ctx();master=ctx.createGain();master.gain.value=muted?0:0.055;master.connect(ctx.destination);return true;}
function envOsc(freq,type,when,dur,gain){if(!ctx||!master||!freq)return;const osc=ctx.createOscillator(),g=ctx.createGain();osc.type=type;osc.frequency.setValueAtTime(freq,when);g.gain.setValueAtTime(0.0001,when);g.gain.exponentialRampToValueAtTime(Math.max(0.0002,gain),when+0.012);g.gain.exponentialRampToValueAtTime(0.0001,when+dur);osc.connect(g);g.connect(master);osc.start(when);osc.stop(when+dur+0.03);}
function noise(when,dur,gain){if(!ctx||!master)return;const buffer=ctx.createBuffer(1,ctx.sampleRate*dur,ctx.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*(1-i/data.length);const src=ctx.createBufferSource(),g=ctx.createGain(),hp=ctx.createBiquadFilter();hp.type='highpass';hp.frequency.value=4200;g.gain.value=gain;src.buffer=buffer;src.connect(hp);hp.connect(g);g.connect(master);src.start(when);src.stop(when+dur);}
function stopLoop(){if(timer){clearInterval(timer);timer=null;}}
function tick(){if(!ctx||muted)return;const p=PATTERNS[currentMode]||PATTERNS.overworld,now=ctx.currentTime+0.03,idx=step%16;const lead=p.lead[idx],bass=p.bass[idx];if(bass)envOsc(FREQ[bass],'triangle',now,0.18,0.42);if(lead)envOsc(FREQ[lead],'square',now,0.105,currentMode==='battle'||currentMode==='champion'?0.32:0.22);if(p.hat.includes(idx))noise(now,0.035,0.035);step++;}
function startLoop(){stopLoop();if(!ctx||muted)return;const p=PATTERNS[currentMode]||PATTERNS.overworld;step=0;tick();timer=setInterval(tick,(60000/p.bpm)/4);}
export function initAudioUnlock(){if(initialized||typeof window==='undefined')return;initialized=true;const unlock=()=>kickAudio();window.addEventListener('pointerdown',unlock,{passive:true});window.addEventListener('keydown',unlock,{passive:true});}
export async function kickAudio(){if(muted)return;ensure();if(!ctx)return;try{await ctx.resume();}catch{}if(!unlocked){unlocked=true;startLoop();}}
export function setAudioMode(mode){currentMode=PATTERNS[mode]?mode:'overworld';if(unlocked&&!muted)startLoop();}
export function playSfx(name){if(muted||!ensure()||!unlocked)return;const now=ctx.currentTime+0.01;if(name==='select')envOsc(FREQ.C5,'square',now,0.045,0.18);else if(name==='back')envOsc(FREQ.G3,'square',now,0.07,0.14);else if(name==='step')envOsc(FREQ.C2,'triangle',now,0.035,0.08);else if(name==='warp'){envOsc(FREQ.C4,'square',now,0.08,0.16);envOsc(FREQ.G4,'square',now+0.08,0.08,0.14);}else if(name==='hit'){envOsc(FREQ.C3,'sawtooth',now,0.08,0.18);noise(now,0.055,0.07);}else if(name==='miss')envOsc(FREQ.D3,'triangle',now,0.09,0.1);else if(name==='win'){envOsc(FREQ.C4,'square',now,0.11,0.18);envOsc(FREQ.E4,'square',now+0.1,0.11,0.16);envOsc(FREQ.G4,'square',now+0.2,0.16,0.16);}else if(name==='recruit'){envOsc(FREQ.G4,'square',now,0.08,0.15);envOsc(FREQ.C5,'square',now+0.08,0.14,0.16);}else if(name==='blackout'){envOsc(FREQ.G3,'sawtooth',now,0.16,0.16);envOsc(FREQ.C3,'sawtooth',now+0.14,0.24,0.14);}else if(name==='menu')envOsc(FREQ.E4,'square',now,0.05,0.11);}
export function isAudioMuted(){return muted;}
export function setAudioMuted(value){muted=!!value;try{localStorage.setItem(KEY,muted?'1':'0');}catch{}if(master)master.gain.value=muted?0:0.055;if(muted)stopLoop();else if(unlocked)startLoop();return muted;}
export function toggleAudioMute(){return setAudioMuted(!muted);}
export function audioStatus(){return muted?'OFF':'ON';}
