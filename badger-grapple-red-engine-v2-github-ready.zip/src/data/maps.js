export const TILE=32;

export const MAPS={
 fieldhouse:{
  name:'FIELD HOUSE',
  region:'Home gym • Gym 1',
  proof:'Gym 1',
  baseTile:'floor',
  grid:[
   '############################',
   '#............1.............#',
   '#..bbbbbbbbbbbbbbbbbbbbbb..#',
   '#..N....wwww....wwww..R....#',
   '#.......wwww.C..wwww.......#',
   '#....pppppppppppppppppp....#',
   '#....p..mmmmmmmmmm..p......#',
   '#..S.p..mmmmmmmmmm..p.T....#',
   '#....p..mmmmmmmmmm..p......#',
   '#....ppppppppppppppppp.....#',
   '#.......wwww....wwww.......#',
   '#.......wwww....wwww.......#',
   '#..........................#',
   '############################'
  ],
  spawns:{default:{x:13,y:12},fromQuad:{x:13,y:3},recovery:{x:21,y:3}},
  warps:{'1':{map:'quad',spawn:'fromFieldhouse',gate:0,label:'Campus Quad'}},
  encounters:[['buckshot',18],['pacesetter',18],['drillpartner',12],['freshlegs',12],['tilttech',4]],
  encounterRate:.13,
  lvlRange:[2,5],
  boss:{key:'C',id:'captainneutral',lvl:8,badge:'Neutral Badge',team:[['captainneutral',8]],intro:'Captain: Show me you can win one real varsity dual.',beaten:'Captain: Neutral Badge earned. Lakeshore Path is open.'},
  npcs:{T:'Trainer: Green training zones are scout zones. Walking them can trigger wild matches; A still previews first.',N:'Manager: Use Roster Invite during a wild match. Lower HP improves the sign chance.'},
  signs:{R:'Recovery Center — A restores the whole team.',S:'Team Shop — buy Energy, Chalk, and Invites.'},
  trainers:[]
 },
 quad:{
  name:'CAMPUS QUAD',
  region:'Route 1 • First road trip',
  proof:'Route 1',
  baseTile:'grass',
  grid:[
   'KKKKKKKKKKKKKKKKKKKKKKKKKKKK',
   'KKKKKKKKKKKKK2KKKKKKKKKKKKKK',
   'kkkkkkkkkkkkkpkkkkkkkkkkkkkk',
   '.wwwww..f...p...f..wwwww..YY',
   '.wwwww......p......wwwww..YY',
   '.wwwww..N...p...S..wwwww..YY',
   '....Y...hhh.p.hhh......Y..YY',
   '.Y.f....pppppppp.....f......',
   '....a...p..V..p..........YYY',
   '.wwwww..p..f..p...wwwww.....',
   '.wwwww..p.....p.R.wwwww..YYY',
   '.wwwww..pppoppp...wwwww..YYY',
   'kkkkkkkkkkkkkpkkkkkkkkkkkkkk',
   'KKKKKKKKKKKKK1KKKKKKKKKKKKKK'
  ],
  spawns:{fromFieldhouse:{x:13,y:12},fromLakeshore:{x:13,y:2},default:{x:13,y:12},recovery:{x:15,y:10}},
  warps:{'1':{map:'fieldhouse',spawn:'fromQuad',gate:0,label:'Field House'},'2':{map:'lakeshore',spawn:'fromQuad',gate:1,label:'Lakeshore Path'}},
  encounters:[['pacesetter',18],['freshlegs',18],['chainwrestler',14],['handfighter',10],['lakechain',6]],
  encounterRate:.14,
  lvlRange:[4,8],
  npcs:{N:'Student: Rex waits on the path. He picks a style that counters your starter.'},
  signs:{R:'Recovery tent — A restores the team.',S:'Route stand — opens the shop.'},
  fingerprint:'outdoor green route, path-connected doors, no tan base ground',
  trainers:[{key:'a',id:'quad_t1',name:'Freshman Felix',team:[['drillpartner',5]],reward:{rep:6,grit:6},line:'Felix: First trip outside the room? Prove it.',beaten:'Felix: Your stance held up.'},{key:'o',id:'quad_t2',name:'Club Owen',team:[['handfighter',6],['freshlegs',6]],reward:{rep:7,grit:7},line:'Owen: Two-match mini dual. Keep your gas.',beaten:'Owen: You handled the pace.'}],
  rival:{key:'V',id:'rival_route1',lvl:7,reward:{rep:8,grit:8},line:'Rex: I studied your starter. This style counters it.',beaten:'Rex: Fine. I will see you downtown.'}
 },
 lakeshore:{
  name:'LAKESHORE PATH',
  region:'Route 2 • Badge gate 1',
  proof:'Route 2',
  baseTile:'grass',
  grid:[
   'KKKKKKKKKKKKKKKKKKKKKKKKKKKK',
   'KKKKKKKKKKKKK3KKKKKKKKKKKKKK',
   'kkkkkkkkkkkkkpppppppp~~~~~~~',
   '.wwww..f....p....N..p~~~~~~~',
   '.wwww.......p.......p~~~~~~~',
   '.wwww..l....ppppppppp~~~~~~~',
   '....Y....hhh.p.hhh...p~~~~~~',
   '.Y.f...ppppppppp...R.p~~~~~~',
   '......p....f...p......~~~~~~',
   '.wwww.p......e.p..wwww~~~~~~',
   '.wwww.pppppppppp..wwww~~~~~~',
   '.wwww.....S......wwwww~~~~~~',
   'kkkkkkkkkkkkkpkkkkkkkkkkkkkk',
   'KKKKKKKKKKKKK1KKKKKKKKKKKKKK'
  ],
  spawns:{fromQuad:{x:13,y:12},fromPavilion:{x:13,y:2},default:{x:13,y:12},recovery:{x:21,y:7}},
  warps:{'1':{map:'quad',spawn:'fromLakeshore',gate:0,label:'Campus Quad'},'3':{map:'pavilion',spawn:'fromPath',gate:1,label:'Lakeshore Pavilion'}},
  encounters:[['lakechain',18],['granbykid',14],['basebuilder',12],['underhooker',10],['tilttech',6],['cradlehunter',3]],
  encounterRate:.16,
  lvlRange:[7,12],
  npcs:{N:'Jogger: Lakeshore gets tougher after the first badge. Build a party, not one hero.'},
  signs:{R:'Trainer table — A restores the team.',S:'Supply stand — buy Energy, Chalk, and Invites.'},
  trainers:[{key:'l',id:'lake_t1',name:'Lakeshore Levi',team:[['lakechain',9],['granbykid',9]],reward:{rep:10,grit:9},line:'Levi: The path teaches chain wrestling.',beaten:'Levi: You kept position.'},{key:'e',id:'lake_t2',name:'Dockside Drew',team:[['basebuilder',10],['underhooker',10]],reward:{rep:11,grit:10},line:'Drew: Water on both sides. No backing out.',beaten:'Drew: Good edge wrestling.'}]
 },
 pavilion:{
  name:'LAKESHORE PAVILION',
  region:'Gym 2 • Top style',
  proof:'Gym 2',
  baseTile:'floor',
  grid:[
   '############################',
   '#............1.............#',
   '#..bbbbbbbbbbbbbbbbbbbbbb..#',
   '#..N...............R.......#',
   '#......mmmmmmmmmmmm........#',
   '#......mmmmmmmmmmmm........#',
   '#......mmmmAmmmmmmm........#',
   '#......mmmmmmmmmmmm........#',
   '#......mmmmmmmmmmmm........#',
   '#..hhhh..........hhhh......#',
   '#..wwww..........wwww......#',
   '#..wwww..........wwww......#',
   '#............2.............#',
   '############################'
  ],
  spawns:{fromPath:{x:13,y:3},fromDowntown:{x:13,y:11},default:{x:13,y:3},recovery:{x:21,y:3}},
  warps:{'1':{map:'lakeshore',spawn:'fromPavilion',gate:0,label:'Lakeshore Path'},'2':{map:'downtown_route',spawn:'fromPavilion',gate:2,label:'Downtown Route'}},
  encounters:[['wallride',16],['tilttech',12],['cradlehunter',6],['badgerpace',10]],
  encounterRate:.1,
  lvlRange:[10,13],
  boss:{key:'A',id:'pavilionanchor',lvl:13,badge:'Top Badge',team:[['wallride',12],['pavilionanchor',13]],intro:'Anchor: Around here, escape is earned.',beaten:'Anchor: Top Badge earned. Downtown is open.'},
  npcs:{N:'Coach: Scramble attacks punish Top specialists. Bring a real matchup.'},
  signs:{R:'Pavilion recovery bench — A restores the team.'},
  trainers:[]
 },
 downtown_route:{
  name:'DOWNTOWN ROUTE',
  region:'Route 3 • Badge gate 2',
  proof:'Route 3',
  baseTile:'pavement',
  grid:[
   'BBBBBBBBBBBBBBBBBBBBBBBBBBBB',
   'BBBBBBBBBBBBB3BBBBBBBBBBBBBB',
   'bbbbbbbbbbbbbppbbbbbbbbbbbbb',
   '....hh....x..p..hh......R...',
   '....hh.......p..hh..........',
   'pppppppppppppppppppppppppppp',
   '..S..p..wwww.V.wwww..p......',
   '.....p..wwww.y.wwww..p......',
   '.....ppppppppppppppppp......',
   '....hh.......p..hh..........',
   '....hh..N....p..hh..........',
   'bbbbbbbbbbbbbppbbbbbbbbbbbbb',
   'BBBBBBBBBBBBB1BBBBBBBBBBBBBB',
   'BBBBBBBBBBBBBBBBBBBBBBBBBBBB'
  ],
  spawns:{fromPavilion:{x:13,y:11},fromClub:{x:13,y:2},default:{x:13,y:11},recovery:{x:25,y:3}},
  warps:{'1':{map:'pavilion',spawn:'fromDowntown',gate:0,label:'Lakeshore Pavilion'},'3':{map:'downtown_club',spawn:'fromRoute',gate:2,label:'Downtown Club'}},
  encounters:[['badgerpace',16],['overtimekid',8],['throwartist',8],['funkdefender',8],['granbykid',10]],
  encounterRate:.16,
  lvlRange:[11,15],
  signs:{S:'Downtown shop stand — A opens the shop.',R:'Athletic trainer — A restores the team.'},
  npcs:{N:'Resident: The club tests whether your whole room can handle bad positions.'},
  trainers:[{key:'x',id:'down_t1',name:'Capitol Cam',team:[['badgerpace',12],['throwartist',13]],reward:{rep:13,grit:11},line:'Cam: Downtown pace is different.',beaten:'Cam: You adjusted.'},{key:'y',id:'down_t2',name:'State Street Sam',team:[['funkdefender',13],['overtimekid',14]],reward:{rep:14,grit:12},line:'Sam: I win late. Try to finish early.',beaten:'Sam: You did not fade.'}],
  rival:{key:'V',id:'rival_route3',lvl:15,reward:{rep:15,grit:14},line:'Rex: This time I brought a full room.',beaten:'Rex: Fine. The club is yours to try.'}
 },
 downtown_club:{
  name:'DOWNTOWN CLUB',
  region:'Gym 3 • Scramble style',
  proof:'Gym 3',
  baseTile:'floor',
  grid:[
   '############################',
   '#............1.............#',
   '#..bbbbbbbbbbbbbbbbbbbbbb..#',
   '#..N...............R.......#',
   '#......mmmmmmmmmmmm........#',
   '#......mmmmmmmmmmmm........#',
   '#......mmmmDmmmmmmm........#',
   '#......mmmmmmmmmmmm........#',
   '#......mmmmmmmmmmmm........#',
   '#..hhhh..........hhhh......#',
   '#..wwww..........wwww......#',
   '#..wwww..........wwww......#',
   '#............4.............#',
   '############################'
  ],
  spawns:{fromRoute:{x:13,y:3},fromArena:{x:13,y:11},default:{x:13,y:3},recovery:{x:21,y:3}},
  warps:{'1':{map:'downtown_route',spawn:'fromClub',gate:0,label:'Downtown Route'},'4':{map:'conference',spawn:'fromClub',gate:3,label:'Conference Arena'}},
  encounters:[['granbykid',14],['funkdefender',10],['overtimekid',8],['cradlehunter',8]],
  encounterRate:.1,
  lvlRange:[13,16],
  boss:{key:'D',id:'downtowndervish',lvl:16,badge:'Scramble Badge',team:[['granbykid',15],['funkdefender',15],['downtowndervish',16]],intro:'Dervish: Clean positions do not last downtown.',beaten:'Dervish: Scramble Badge earned. Conference Arena is unlocked.'},
  npcs:{N:'Old coach: Neutral attacks beat Scramble. Bring your best shot finisher.'},
  signs:{R:'Club recovery bench — A restores the team.'},
  trainers:[]
 },
 conference:{
  name:'CONFERENCE ARENA',
  region:'Championship gauntlet',
  proof:'Champion',
  baseTile:'floor',
  grid:[
   '############################',
   '#............1.............#',
   '#..bbbbbbbbbbbbbbbbbbbbbb..#',
   '#..N...............R.......#',
   '#......mmmmmmmmmmmm........#',
   '#......mmmmzmmmmmmm........#',
   '#......mmmmmmmmmmmm........#',
   '#......mmmmqmmmmmmm........#',
   '#......mmmmmmmmmmmm........#',
   '#......mmmmHmmmmmmm........#',
   '#..hhhh..........hhhh......#',
   '#..........................#',
   '#............S.............#',
   '############################'
  ],
  spawns:{fromClub:{x:13,y:3},default:{x:13,y:3},recovery:{x:21,y:3}},
  warps:{'1':{map:'downtown_club',spawn:'fromArena',gate:0,label:'Downtown Club'}},
  encounters:[],
  encounterRate:0,
  lvlRange:[16,18],
  npcs:{N:'Official: The arena gauntlet is built to punish solo runs. Heal, rotate, and use style edges.'},
  signs:{R:'Arena recovery — A restores the team.',S:'Arena shop — A opens the shop.'},
  trainers:[{key:'z',id:'arena_t1',name:'Semifinal Iron',team:[['gauntletiron',17]],reward:{rep:18,grit:16},line:'Iron: First semifinal. Break through me.',beaten:'Iron: You earned the final table.'},{key:'q',id:'arena_t2',name:'Finals Pace',team:[['gauntletpace',18]],reward:{rep:20,grit:18},line:'Pace: Second semifinal. Gas tank check.',beaten:'Pace: You survived the pace.'}],
  champion:{key:'H',id:'championbadger',lvl:21,badge:'Champion Plaque',team:[['gauntletiron',18],['gauntletpace',18],['championbadger',21]],intro:'Champion: A single star does not win a tournament. Show me the room.',beaten:'Champion: Champion Plaque earned. Badger Grapple Red cleared.'}
 }
};

export const tileFrames={'#':1,'.':16,'p':18,'w':17,'m':3,'R':4,'S':5,'C':6,'A':6,'D':6,'H':6,'T':7,'N':7,'V':7,'~':23,'b':12,'B':12,'f':21,'h':22,'K':19,'k':20,'Y':19,'1':8,'2':8,'3':8,'4':8,'a':7,'o':7,'l':7,'e':7,'x':7,'y':7,'z':7,'q':7};

export const impassableChars=new Set(['#','~','b','B','K','k','Y','h','R','S','T','N','V','C','A','D','H','a','o','l','e','x','y','z','q']);

export function getMap(id){return MAPS[id]||MAPS.fieldhouse;}
export function passableTile(ch){return !impassableChars.has(ch);}
export function findSpawn(mapId='fieldhouse',spawn='default'){const m=getMap(mapId);return {...(m.spawns?.[spawn]||m.spawns?.default||{x:2,y:2})};}
export function tileAt(map,x,y){if(y<0||y>=map.grid.length||x<0||x>=map.grid[0].length)return '#';return map.grid[y][x];}
export function findTrainer(map,ch){return (map.trainers||[]).find(t=>t.key===ch)||null;}
export function weightedPick(entries){const total=entries.reduce((s,e)=>s+e[1],0);let roll=Math.random()*total;for(const [id,w] of entries){roll-=w;if(roll<=0)return id;}return entries[0]?.[0];}
export function randomLevel(range=[2,5]){const [a,b]=range;return a+Math.floor(Math.random()*(b-a+1));}
export function pickEncounter(map){if(!map.encounters?.length)return null;return {id:weightedPick(map.encounters),lvl:randomLevel(map.lvlRange)};}
