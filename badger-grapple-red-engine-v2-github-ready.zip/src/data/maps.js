export const TILE=16;
export const AREAS={
 fieldhouse:{name:'FIELD HOUSE',bg:'area_fieldhouse',start:{x:14,y:11},exits:[{x:14,y:1,to:'campus',tx:14,ty:12,msg:'You step out onto campus.'}],encounters:false},
 campus:{name:'CAMPUS QUAD',bg:'area_campus',start:{x:14,y:12},exits:[{x:14,y:13,to:'fieldhouse',tx:14,ty:2,msg:'Back inside the Field House.'},{x:27,y:7,to:'lakeshore',tx:1,ty:7,msg:'Lakeshore path.'},{x:1,y:7,to:'downtown',tx:26,ty:7,msg:'Downtown Madison.'},{x:14,y:1,to:'conference',tx:14,ty:12,msg:'Conference Arena.'}],encounters:false},
 lakeshore:{name:'LAKESHORE',bg:'area_lakeshore',start:{x:1,y:7},exits:[{x:0,y:7,to:'campus',tx:26,ty:7,msg:'Campus Quad.'},{x:27,y:9,to:'river',tx:1,ty:9,msg:'River Trail.'}],encounters:true},
 downtown:{name:'DOWNTOWN',bg:'area_downtown',start:{x:26,y:7},exits:[{x:27,y:7,to:'campus',tx:1,ty:7,msg:'Campus Quad.'}],encounters:false},
 river:{name:'RIVER TRAIL',bg:'area_river',start:{x:1,y:9},exits:[{x:0,y:9,to:'lakeshore',tx:26,ty:9,msg:'Lakeshore.'},{x:27,y:6,to:'championship',tx:1,ty:6,msg:'Championship Hall.'}],encounters:true},
 conference:{name:'CONFERENCE ARENA',bg:'area_conference',start:{x:14,y:12},exits:[{x:14,y:13,to:'campus',tx:14,ty:2,msg:'Campus Quad.'}],captain:{x:14,y:5,id:'captainneutral',lvl:8,type:'captain'}},
 championship:{name:'CHAMPIONSHIP HALL',bg:'area_championship',start:{x:1,y:6},exits:[{x:0,y:6,to:'river',tx:26,ty:6,msg:'River Trail.'}],captain:{x:19,y:6,id:'captainneutral',lvl:10,type:'captain'}}
};
export function startArea(){return 'fieldhouse';}
export function defaultPos(area='fieldhouse'){return {...(AREAS[area]?.start||AREAS.fieldhouse.start)};}
export function areaFor(id){return AREAS[id]||AREAS.fieldhouse;}
export function isBlocked(area,x,y){if(x<0||x>27||y<0||y>13)return true;const a=areaFor(area);if(a.name==='FIELD HOUSE')return y===0||x===0||x===27||y===13||((x<12||x>16)&&y===1);if(a.name==='CAMPUS QUAD')return false;if(a.name==='LAKESHORE')return (y>=2&&y<=6&&x>=17)||y===0||y===13;if(a.name==='DOWNTOWN')return y===0||y===13||((y<5||y>9)&&(x>3&&x<24));if(a.name==='RIVER TRAIL')return y===0||y===13||((x>7&&x<21)&&(y<7));if(a.name==='CONFERENCE ARENA'||a.name==='CHAMPIONSHIP HALL')return y===0||y===13||x===0||x===27;return false;}
export function isGrass(area,x,y){const n=areaFor(area).name;return (n==='LAKESHORE'&&x>=3&&x<=13&&y>=3&&y<=10)||(n==='RIVER TRAIL'&&x>=4&&x<=11&&y>=5&&y<=11)||(n==='CAMPUS QUAD'&&((x>=3&&x<=7&&y>=2&&y<=5)||(x>=20&&x<=24&&y>=8&&y<=11)));}
export function spotKind(area,x,y){const n=areaFor(area).name;if(n==='FIELD HOUSE'){if(x===5&&y===7)return 'R';if(x===18&&y===4)return 'N';if(x===21&&y===4)return 'S';if(x===14&&y===1)return 'EXIT';}if(n==='CAMPUS QUAD'){if(x===14&&y===7)return 'STATUE';}const cap=areaFor(area).captain;if(cap&&cap.x===x&&cap.y===y)return 'C';if(isGrass(area,x,y))return 'g';return '.';}
