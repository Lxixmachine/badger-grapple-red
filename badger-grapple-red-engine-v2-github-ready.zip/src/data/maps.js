export const TILE=16;
export const FIELD_MAP=[
'############################',
'#............S.....R.......#',
'#..gggggg.........gggggg...#',
'#..gggggg....C....gggggg...#',
'#..........................#',
'#......mmmmmmmmmm..........#',
'#..T...mmmmmmmmmm.....N....#',
'#......mmmmmmmmmm..........#',
'#..........................#',
'#..gggggg.........gggggg...#',
'#..gggggg.........gggggg...#',
'#..........................#',
'#.............P............#',
'############################'
];
export const tileFrames={'#':1,'.':0,'g':2,'m':3,'R':4,'S':5,'C':6,'T':7,'N':7,'P':0};
export function findStart(){for(let y=0;y<FIELD_MAP.length;y++){const x=FIELD_MAP[y].indexOf('P');if(x>=0)return {x,y};}return {x:2,y:2};}
