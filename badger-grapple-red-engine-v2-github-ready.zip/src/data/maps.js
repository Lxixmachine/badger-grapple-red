export const TILE=16;
export const AREAS={
 fieldhouse:{name:'FIELD HOUSE',bg:'area_fieldhouse',start:{x:14,y:11},exits:[{x:14,y:1,to:'campus',tx:14,ty:12,msg:'You step out onto campus.'}],encounters:false},
 campus:{name:'CAMPUS QUAD',bg:'area_campus',start:{x:14,y:12},exits:[{x:14,y:13,to:'fieldhouse',tx:14,ty:2,msg:'Back inside the Field House.'},{x:23,y:2,to:'studyhall',tx:5,ty:10,msg:'Study Hall.'},{x:27,y:7,to:'lakeshore',tx:1,ty:7,msg:'Lakeshore path.'},{x:1,y:7,to:'downtown',tx:26,ty:7,msg:'Downtown Madison.'},{x:14,y:1,to:'conference',tx:14,ty:12,msg:'Conference Arena.'}],encounters:true},
 studyhall:{name:'STUDY HALL',bg:'area_fieldhouse',start:{x:5,y:10},exits:[{x:5,y:11,to:'campus',tx:23,ty:3,msg:'Campus Quad.'}],encounters:false},
 lakeshore:{name:'LAKESHORE',bg:'area_lakeshore',start:{x:1,y:7},exits:[{x:0,y:7,to:'campus',tx:26,ty:7,msg:'Campus Quad.'},{x:27,y:9,to:'river',tx:1,ty:9,msg:'River Trail.'}],encounters:true},
 downtown:{name:'DOWNTOWN',bg:'area_downtown',start:{x:26,y:7},exits:[{x:27,y:7,to:'campus',tx:1,ty:7,msg:'Campus Quad.'}],encounters:false},
 river:{name:'RIVER TRAIL',bg:'area_river',start:{x:1,y:9},exits:[{x:0,y:9,to:'lakeshore',tx:26,ty:9,msg:'Lakeshore.'},{x:27,y:6,to:'championship',tx:1,ty:6,msg:'Championship Hall.'}],encounters:true},
 conference:{name:'CONFERENCE ARENA',bg:'area_conference',start:{x:14,y:12},exits:[{x:14,y:13,to:'campus',tx:14,ty:2,msg:'Campus Quad.'}],captain:{x:14,y:5,id:'captainneutral',lvl:8,type:'captain'}},
 championship:{name:'CHAMPIONSHIP HALL',bg:'area_championship',start:{x:1,y:6},exits:[{x:0,y:6,to:'river',tx:26,ty:6,msg:'River Trail.'}],captain:{x:19,y:6,id:'captainneutral',lvl:10,type:'captain'}}
};
export function startArea(){return 'fieldhouse';}
export function defaultPos(area='fieldhouse'){return {...(AREAS[area]?.start||AREAS.fieldhouse.start)};}
export function areaFor(id){return AREAS[id]||AREAS.fieldhouse;}
export function isBlocked(area,x,y){
 if(x<0||x>27||y<0||y>13)return true;
 const n=areaFor(area).name;
 // Collision intentionally matches the visible art. Keep walk lanes obvious; no hidden clutter walls.
 if(n==='FIELD HOUSE'){
   // Visible walls only. The central mat and main lanes are intentionally open.
   if(x===0||x===27||y===0||y===13)return true;
   if(y===1 && x!==14)return true; // top wall; center door is the exit
   // Clearly drawn edge rooms / furniture. Keep all main paths 3+ tiles wide.
   if(x>=2&&x<=6&&y>=3&&y<=5)return true;   // coach office furniture
   if(x>=2&&x<=6&&y>=9&&y<=10)return true;  // recovery table
   if(x>=22&&x<=26&&y>=4&&y<=6)return true; // gear lockers
   if(x>=22&&x<=26&&y>=8&&y<=10)return true;// weights rack
   return false;
 }
 if(n==='CAMPUS QUAD'){
   if((x===0||x===27||y===0||y===13)&&!((x===14&&y===13)||(x===27&&y===7)||(x===1&&y===7)||(x===14&&y===1)))return true;
   // study hall building: only the door tile is open
   if(x>=21&&x<=27&&y>=1&&y<=4 && !(x===23&&y===2))return true;
   // statue base
   if(x>=4&&x<=6&&y>=7&&y<=8)return true;
   return false;
 }
 if(n==='STUDY HALL')return y===0||x===0||x===27||y===13||((x<4||x>7)&&y===11);
 if(n==='LAKESHORE')return (y>=2&&y<=6&&x>=17)||y===0||y===13;
 if(n==='DOWNTOWN')return y===0||y===13||((y<5||y>9)&&(x>3&&x<24));
 if(n==='RIVER TRAIL')return y===0||y===13||((x>7&&x<21)&&(y<7));
 if(n==='CONFERENCE ARENA'||n==='CHAMPIONSHIP HALL')return y===0||y===13||x===0||x===27;
 return false;
}
export function isGrass(area,x,y){const n=areaFor(area).name;return (n==='LAKESHORE'&&x>=3&&x<=13&&y>=3&&y<=10)||(n==='RIVER TRAIL'&&x>=4&&x<=11&&y>=5&&y<=11)||(n==='CAMPUS QUAD'&&((x>=3&&x<=7&&y>=2&&y<=5)||(x>=20&&x<=24&&y>=8&&y<=11)));}
export function spotKind(area,x,y){const n=areaFor(area).name;if(n==='FIELD HOUSE'){if(x>=2&&x<=6&&y>=9&&y<=11)return 'R';if(x===7&&y===5)return 'N';if(x===21&&y===6)return 'S';if(x===14&&y===1)return 'EXIT';if(x>=8&&x<=19&&y>=5&&y<=10)return 'M';if(x>=2&&x<=6&&y>=3&&y<=5)return 'COACH_OFFICE';if(x>=22&&x<=26&&y>=4&&y<=6)return 'LOCKER_ROOM';if(x>=22&&x<=26&&y>=8&&y<=10)return 'WEIGHT_ROOM';if(x>=2&&x<=6&&y>=9&&y<=11)return 'RECEPTION';if(x>=7&&x<=10&&y>=11&&y<=12)return 'MEETING_ROOM';}if(n==='CAMPUS QUAD'){if(x===14&&y===7)return 'STATUE';if(x===5&&y===5)return 'SCOUT_NPC';if(x===22&&y===9)return 'RECRUIT_NPC';if(x===11&&y===8)return 'SAVE_NPC';if(x===17&&y===5)return 'RIVAL_NPC';if(x===8&&y===10)return 'HIDDEN_TAPE';if(x===23&&y===2)return 'DOOR';if(x===18&&y===10)return 'HIDDEN_DRINK';}
 if(n==='STUDY HALL'){if(x===9&&y===8)return 'STUDY_NPC';if(x===12&&y===6)return 'HIDDEN_FILM';}const cap=areaFor(area).captain;if(cap&&cap.x===x&&cap.y===y)return 'C';if(isGrass(area,x,y))return 'g';return '.';}
