export const TILE=32;
// v14: collision map now matches the high-art field-house hub background.
// # = blocked scenery / wall.  g = scout zone.  Stations are single-tile interact anchors.
export const FIELD_MAP=[
'############################',
'############################',
'#..S..................R.N..#',
'#..........................#',
'#............C.............#',
'#..mmmmmmmm....mmmmmmmm....#',
'#..mmmmmmmm....mmmmmmmm....#',
'#..mmmmmmmm.P..mmmmmmmm....#',
'#..mmmmmmmm....mmmmmmmm....#',
'#..........gggggg..........#',
'#....T.....gggggg.....N....#',
'#..........................#',
'############################',
'############################'
];
export const tileFrames={'#':1,'.':0,'g':2,'m':3,'R':4,'S':5,'C':6,'T':7,'N':7,'P':8};
export function findStart(){for(let y=0;y<FIELD_MAP.length;y++){const x=FIELD_MAP[y].indexOf('P');if(x>=0)return {x,y};}return {x:14,y:7};}
