export const TILE=32;

export const MAPS={
 fieldhouse:{
  name:'FIELD HOUSE',region:'Home gym • Gym 1',proof:'Gym 1',
  grid:[
   '############################',
   '#............T.....R.......#',
   '#..gggggg.........gggggg...#',
   '#..gggggg....C....gggggg...#',
   '#..........................#',
   '#......mmmmmmmmmm..........#',
   '#..S...mmmmmmmmmm.....N....#',
   '#......mmmmmmmmmm..........#',
   '#..........................#',
   '#..gggggg.........gggggg...#',
   '#..gggggg.........gggggg...#',
   '#..........................#',
   '#.............1............#',
   '############################'
  ],
  spawns:{default:{x:13,y:12},fromQuad:{x:13,y:11},recovery:{x:20,y:2}},
  warps:{'1':{map:'quad',spawn:'fromFieldhouse',gate:0,label:'Campus Quad'}},
  encounters:[['buckshot',18],['pacesetter',18],['drillpartner',12],['freshlegs',12],['tilttech',4]],encounterRate:.13,lvlRange:[2,5],
  boss:{key:'C',id:'captainneutral',lvl:8,badge:'Neutral Badge',team:[['captainneutral',8]],intro:'Captain: Show me you can win one real varsity dual.',beaten:'Captain: Neutral Badge earned. Lakeshore Path is open.'},
  npcs:{T:'Trainer: Green tiles are scout zones. Walking them can now trigger wild matches; A still previews first.',N:'Manager: Use Roster Invite during a wild match. Lower HP improves the sign chance.'},
  signs:{R:'Recovery Center — A restores the whole team.',S:'Team Shop — buy Energy, Chalk, and Invites.'},
  trainers:[]
 },
 quad:{
  name:'CAMPUS QUAD',region:'Route 1 • First road trip',proof:'Route 1',
  grid:[
   '############################',
   '#............2.............#',
   '#..ggggg..........ggggg....#',
   '#..ggggg....t.....ggggg....#',
   '#..........pppppp..........#',
   '#....N....ppVppp.....S.....#',
   '#..........pppppp..........#',
   '#..ggggg..........ggggg....#',
   '#..ggggg....u.....ggggg....#',
   '#..........................#',
   '#..........pppppp..........#',
   '#............1.............#',
   '#............R.............#',
   '############################'
  ],
  spawns:{fromFieldhouse:{x:13,y:10},fromLakeshore:{x:13,y:2},default:{x:13,y:10},recovery:{x:13,y:12}},
  warps:{'1':{map:'fieldhouse',spawn:'fromQuad',gate:0,label:'Field House'},'2':{map:'lakeshore',spawn:'fromQuad',gate:1,label:'Lakeshore Path'}},
  encounters:[['pacesetter',18],['freshlegs',18],['chainwrestler',14],['handfighter',10],['lakechain',6]],encounterRate:.14,lvlRange:[4,8],
  npcs:{N:'Student: Rex waits on the path. He picks a style that counters your starter.'},signs:{R:'Recovery tent — A restores the team.',S:'Route stand — opens the shop.'},
  trainers:[
   {key:'t',id:'quad_t1',name:'Freshman Felix',team:[['drillpartner',5]],reward:{rep:6,grit:6},line:'Felix: First trip outside the room? Prove it.',beaten:'Felix: Your stance held up.'},
   {key:'u',id:'quad_t2',name:'Club Owen',team:[['handfighter',6],['freshlegs',6]],reward:{rep:7,grit:7},line:'Owen: Two-match mini dual. Keep your gas.',beaten:'Owen: You handled the pace.'}
  ],
  rival:{key:'V',id:'rival_route1',lvl:7,reward:{rep:8,grit:8},line:'Rex: I studied your starter. This style counters it.',beaten:'Rex: Fine. I will see you downtown.'}
 },
 lakeshore:{
  name:'LAKESHORE PATH',region:'Route 2 • Badge gate 1',proof:'Route 2',
  grid:[
   '############################',
   '#............3.............#',
   '#~~~~~..gggggggggg..~~~~~..#',
   '#~~~~~..ggggvggggg..~~~~~..#',
   '#......pppppppppppp........#',
   '#..N...pppppppppppp...R....#',
   '#......pppppppppppp........#',
   '#~~~~~..gggggggggg..~~~~~..#',
   '#~~~~~..ggggwggggg..~~~~~..#',
   '#..........................#',
   '#..gggggg........gggggg....#',
   '#............2.............#',
   '#............1.............#',
   '############################'
  ],
  spawns:{fromQuad:{x:12,y:11},fromPavilion:{x:12,y:1},default:{x:12,y:11},recovery:{x:22,y:5}},
  warps:{'1':{map:'quad',spawn:'fromLakeshore',gate:0,label:'Campus Quad'},'2':{map:'quad',spawn:'fromLakeshore',gate:0,label:'Campus Quad'},'3':{map:'pavilion',spawn:'fromPath',gate:1,label:'Lakeshore Pavilion'}},
  encounters:[['lakechain',18],['granbykid',14],['basebuilder',12],['underhooker',10],['tilttech',6],['cradlehunter',3]],encounterRate:.16,lvlRange:[7,12],
  npcs:{N:'Jogger: Lakeshore gets tougher after the first badge. Build a party, not one hero.'},signs:{R:'Trainer table — A restores the team.'},
  trainers:[
   {key:'v',id:'lake_t1',name:'Lakeshore Levi',team:[['lakechain',9],['granbykid',9]],reward:{rep:10,grit:9},line:'Levi: The path teaches chain wrestling.',beaten:'Levi: You kept position.'},
   {key:'w',id:'lake_t2',name:'Dockside Drew',team:[['basebuilder',10],['underhooker',10]],reward:{rep:11,grit:10},line:'Drew: Water on both sides. No backing out.',beaten:'Drew: Good edge wrestling.'}
  ]
 },
 pavilion:{
  name:'LAKESHORE PAVILION',region:'Gym 2 • Top style',proof:'Gym 2',
  grid:[
   '############################',
   '#............1.............#',
   '#......bbbbb..bbbbb........#',
   '#..N...b..........b...R....#',
   '#......b..mmmmmm..b........#',
   '#......b..mmmmmm..b........#',
   '#......b....A.....b........#',
   '#......b..mmmmmm..b........#',
   '#......b..mmmmmm..b........#',
   '#......bbbbb..bbbbb........#',
   '#..gggggg........gggggg....#',
   '#..gggggg........gggggg....#',
   '#............2.............#',
   '############################'
  ],
  spawns:{fromPath:{x:12,y:1},fromDowntown:{x:12,y:12},default:{x:12,y:1},recovery:{x:22,y:3}},
  warps:{'1':{map:'lakeshore',spawn:'fromPavilion',gate:0,label:'Lakeshore Path'},'2':{map:'downtown_route',spawn:'fromPavilion',gate:2,label:'Downtown Route'}},
  encounters:[['wallride',16],['tilttech',12],['cradlehunter',6],['badgerpace',10]],encounterRate:.10,lvlRange:[10,13],
  boss:{key:'A',id:'pavilionanchor',lvl:13,badge:'Top Badge',team:[['wallride',12],['pavilionanchor',13]],intro:'Anchor: Around here, escape is earned.',beaten:'Anchor: Top Badge earned. Downtown is open.'},
  npcs:{N:'Coach: Scramble attacks punish Top specialists. Bring a real matchup.'},signs:{R:'Pavilion recovery bench — A restores the team.'},trainers:[]
 },
 downtown_route:{
  name:'DOWNTOWN ROUTE',region:'Route 3 • Badge gate 2',proof:'Route 3',
  grid:[
   '############################',
   '#............3.............#',
   '#..fffff..........fffff....#',
   '#..fgggf....x.....fgggf....#',
   '#..fgggf..........fgggf....#',
   '#......pppppppppppp........#',
   '#..S...pppVpppppppp...R....#',
   '#......pppppppppppp........#',
   '#..fgggf....y.....fgggf....#',
   '#..fgggf..........fgggf....#',
   '#..fffff..........fffff....#',
   '#..........................#',
   '#............1.............#',
   '############################'
  ],
  spawns:{fromPavilion:{x:13,y:11},fromClub:{x:13,y:2},default:{x:13,y:11},recovery:{x:22,y:6}},
  warps:{'1':{map:'pavilion',spawn:'fromDowntown',gate:0,label:'Lakeshore Pavilion'},'3':{map:'downtown_club',spawn:'fromRoute',gate:2,label:'Downtown Club'}},
  encounters:[['badgerpace',16],['overtimekid',8],['throwartist',8],['funkdefender',8],['granbykid',10]],encounterRate:.16,lvlRange:[11,15],
  signs:{S:'Downtown shop stand — A opens the shop.',R:'Athletic trainer — A restores the team.'},npcs:{},
  trainers:[
   {key:'x',id:'down_t1',name:'Capitol Cam',team:[['badgerpace',12],['throwartist',13]],reward:{rep:13,grit:11},line:'Cam: Downtown pace is different.',beaten:'Cam: You adjusted.'},
   {key:'y',id:'down_t2',name:'State Street Sam',team:[['funkdefender',13],['overtimekid',14]],reward:{rep:14,grit:12},line:'Sam: I win late. Try to finish early.',beaten:'Sam: You did not fade.'}
  ],
  rival:{key:'V',id:'rival_route3',lvl:15,reward:{rep:15,grit:14},line:'Rex: This time I brought a full room.',beaten:'Rex: Fine. The club is yours to try.'}
 },
 downtown_club:{
  name:'DOWNTOWN CLUB',region:'Gym 3 • Scramble style',proof:'Gym 3',
  grid:[
   '############################',
   '#............1.............#',
   '#......fffff..fffff........#',
   '#..N...f..........f...R....#',
   '#......f..mmmmmm..f........#',
   '#......f..mmmmmm..f........#',
   '#......f....D.....f........#',
   '#......f..mmmmmm..f........#',
   '#......f..mmmmmm..f........#',
   '#......fffff..fffff........#',
   '#..gggggg........gggggg....#',
   '#..gggggg........gggggg....#',
   '#............4.............#',
   '############################'
  ],
  spawns:{fromRoute:{x:12,y:1},fromArena:{x:12,y:12},default:{x:12,y:1},recovery:{x:22,y:3}},
  warps:{'1':{map:'downtown_route',spawn:'fromClub',gate:0,label:'Downtown Route'},'4':{map:'conference',spawn:'fromClub',gate:3,label:'Conference Arena'}},
  encounters:[['granbykid',14],['funkdefender',10],['overtimekid',8],['cradlehunter',8]],encounterRate:.10,lvlRange:[13,16],
  boss:{key:'D',id:'downtowndervish',lvl:16,badge:'Scramble Badge',team:[['granbykid',15],['funkdefender',15],['downtowndervish',16]],intro:'Dervish: Clean positions do not last downtown.',beaten:'Dervish: Scramble Badge earned. Conference Arena is unlocked.'},
  npcs:{N:'Old coach: Neutral attacks beat Scramble. Bring your best shot finisher.'},signs:{R:'Club recovery bench — A restores the team.'},trainers:[]
 },
 conference:{
  name:'CONFERENCE ARENA',region:'Championship gauntlet',proof:'Champion',
  grid:[
   '############################',
   '#............1.............#',
   '#......bbbbb..bbbbb........#',
   '#..N...b..........b...R....#',
   '#......b..mmmmmm..b........#',
   '#......b....z.....b........#',
   '#......b..mmmmmm..b........#',
   '#......b....q.....b........#',
   '#......b..mmmmmm..b........#',
   '#......b....H.....b........#',
   '#......bbbbb..bbbbb........#',
   '#..........................#',
   '#............S.............#',
   '############################'
  ],
  spawns:{fromClub:{x:12,y:1},default:{x:12,y:1},recovery:{x:22,y:3}},
  warps:{'1':{map:'downtown_club',spawn:'fromArena',gate:0,label:'Downtown Club'}},
  encounters:[],encounterRate:0,lvlRange:[16,18],
  npcs:{N:'Official: The arena gauntlet is built to punish solo runs. Heal, rotate, and use style edges.'},signs:{R:'Arena recovery — A restores the team.',S:'Arena shop — A opens the shop.'},
  trainers:[
   {key:'z',id:'arena_t1',name:'Semifinal Iron',team:[['gauntletiron',17]],reward:{rep:18,grit:16},line:'Iron: First semifinal. Break through me.',beaten:'Iron: You earned the final table.'},
   {key:'q',id:'arena_t2',name:'Finals Pace',team:[['gauntletpace',18]],reward:{rep:20,grit:18},line:'Pace: Second semifinal. Gas tank check.',beaten:'Pace: You survived the pace.'}
  ],
  champion:{key:'H',id:'championbadger',lvl:21,badge:'Champion Plaque',team:[['gauntletiron',18],['gauntletpace',18],['championbadger',21]],intro:'Champion: A single star does not win a tournament. Show me the room.',beaten:'Champion: Champion Plaque earned. Badger Grapple Red cleared.'}
 }
};

export const tileFrames={'#':1,'.':0,'p':9,'g':2,'m':3,'R':4,'S':5,'C':6,'A':6,'D':6,'H':6,'T':7,'N':7,'V':7,'~':10,'b':12,'f':13,'1':8,'2':8,'3':8,'4':8,'t':7,'u':7,'v':7,'w':7,'x':7,'y':7,'z':7,'q':7};
export const impassableChars=new Set(['#','~','b','f','T','N','V','C','A','D','H','t','u','v','w','x','y','z','q']);
export function getMap(id){return MAPS[id]||MAPS.fieldhouse;}
export function passableTile(ch){return !impassableChars.has(ch);}
export function findSpawn(mapId='fieldhouse',spawn='default'){const m=getMap(mapId);return {...(m.spawns?.[spawn]||m.spawns?.default||{x:2,y:2})};}
export function tileAt(map,x,y){if(y<0||y>=map.grid.length||x<0||x>=map.grid[0].length)return '#';return map.grid[y][x];}
export function findTrainer(map,ch){return (map.trainers||[]).find(t=>t.key===ch)||null;}
export function weightedPick(entries){const total=entries.reduce((s,e)=>s+e[1],0);let roll=Math.random()*total;for(const [id,w] of entries){roll-=w;if(roll<=0)return id;}return entries[0]?.[0];}
export function randomLevel(range=[2,5]){const [a,b]=range;return a+Math.floor(Math.random()*(b-a+1));}
export function pickEncounter(map){if(!map.encounters?.length)return null;return {id:weightedPick(map.encounters),lvl:randomLevel(map.lvlRange)};}
