export const ROSTER={
 buckshot:{id:'buckshot',name:'Bucky Shotmaker',weight:'125',style:'Neutral',rarity:'Common',asset:'badger',color:0xc81f2b,stats:{hp:62,atk:18,def:14,spd:19,gas:74},moves:['single','highc','sprawl','pace'],bio:'Fast first attack. Great starter.'},
 matreturner:{id:'matreturner',name:'Mat Returner',weight:'165',style:'Top',rarity:'Common',asset:'top',color:0x5f4cc8,stats:{hp:72,atk:17,def:18,spd:12,gas:70},moves:['ride','claw','tilt','sprawl'],bio:'Pressure and mat control.'},
 fieldflyer:{id:'fieldflyer',name:'Field House Flyer',weight:'141',style:'Scramble',rarity:'Common',asset:'scramble',color:0xe47c27,stats:{hp:64,atk:18,def:13,spd:21,gas:69},moves:['scramble','roll','single','snap'],bio:'Chaotic and slippery.'},
 pacesetter:{id:'pacesetter',name:'Pace Setter',weight:'149',style:'Pace',rarity:'Common',asset:'pace',color:0x2e9c57,stats:{hp:66,atk:16,def:15,spd:18,gas:86},moves:['pace','double','flurry','stall'],bio:'Wins on volume.'},
 drillpartner:{id:'drillpartner',name:'Drill Partner',weight:'133',style:'Neutral',rarity:'Uncommon',asset:'neutral',color:0xc81f2b,stats:{hp:68,atk:20,def:18,spd:20,gas:80},moves:['single','pace','roll','sprawl'],bio:'Clean technique.'},
 lakechain:{id:'lakechain',name:'Lake Chain',weight:'133',style:'Neutral',rarity:'Uncommon',asset:'neutral',color:0xb82027,stats:{hp:70,atk:21,def:16,spd:22,gas:80},moves:['single','highc','double','reattack'],bio:'One attack becomes three.'},
 tilttech:{id:'tilttech',name:'Tilt Technician',weight:'174',style:'Top',rarity:'Rare',asset:'top',color:0x594bc0,stats:{hp:76,atk:24,def:19,spd:15,gas:80},moves:['ride','tilt','pin','claw'],bio:'Nearfall machine.'},
 captainneutral:{id:'captainneutral',name:'Captain Neutral',weight:'174',style:'Neutral',rarity:'Elite',asset:'neutral',color:0xb71b25,stats:{hp:92,atk:28,def:23,spd:22,gas:92},moves:['single','highc','reattack','flurry'],bio:'First badge test.'}
};
export const STARTERS=['buckshot','matreturner','fieldflyer'];
export function scaledStats(id,lvl){const r=ROSTER[id];return {hp:r.stats.hp+lvl*5,atk:r.stats.atk+Math.floor(lvl*1.6),def:r.stats.def+Math.floor(lvl*1.3),spd:r.stats.spd+Math.floor(lvl*1.1),gas:r.stats.gas+lvl*2};}
export function makeMon(id,lvl){const s=scaledStats(id,lvl);return {id,lvl,xp:0,hp:s.hp,gas:s.gas,score:0,boost:false};}
export function xpNeed(m){return 18+m.lvl*9;}
export function addXp(m,amt){const out=[];m.xp+=amt;while(m.xp>=xpNeed(m)){m.xp-=xpNeed(m);m.lvl++;const s=scaledStats(m.id,m.lvl);m.hp=s.hp;m.gas=s.gas;out.push(`${ROSTER[m.id].name} grew to Lv ${m.lvl}!`);}return out;}
