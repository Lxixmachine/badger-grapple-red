import {loadState,resetState,caughtRecruitCount} from '../systems/save.js';import {uiBox,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
export class TitleScene extends Phaser.Scene{
  constructor(){super('TitleScene');}
  create(){this.state=loadState();this.sel=this.state.party?.length?1:0;this.opts=['NEW GAME','CONTINUE','RESET'];this.cameras.main.setBackgroundColor('#1d2634');this.add.image(0,0,'title_bg').setOrigin(0);this.add.text(120,11,'BADGER GRAPPLE RED',{fontFamily:'monospace',fontSize:13,color:'#f8f0d8',fontStyle:'bold',stroke:'#111',strokeThickness:3}).setOrigin(.5);this.add.text(120,29,'FIELD HOUSE v19.6',{fontFamily:'monospace',fontSize:7,color:'#ffe28a',fontStyle:'bold',stroke:'#111',strokeThickness:2}).setOrigin(.5);uiBox(this,34,102,172,48);this.menuText=this.add.text(48,112,'',{fontFamily:'monospace',fontSize:8,color:'#111',fontStyle:'bold',lineSpacing:2});this.stat=this.add.text(132,113,'',{fontFamily:'monospace',fontSize:7,color:'#444',lineSpacing:2});this.input.keyboard.on('keydown-UP',()=>this.move(-1));this.input.keyboard.on('keydown-DOWN',()=>this.move(1));this.input.keyboard.on('keydown-ENTER',()=>this.choose());this.input.keyboard.on('keydown-SPACE',()=>this.choose());setVirtualHandler(this);this.render();}
  handleVirtualButton(k){if(k==='up')this.move(-1);if(k==='down')this.move(1);if(k==='a')this.choose();if(k==='b'){resetState();this.state=loadState();this.render();}}
  move(d){this.sel=Phaser.Math.Wrap(this.sel+d,0,this.opts.length);this.render();}
  render(){this.menuText.setText(this.opts.map((o,i)=>`${i===this.sel?'▶':' '} ${o}`).join('\n'));const s=this.state.stats||{};this.stat.setText(`Roster ${caughtRecruitCount(this.state)}\nWins ${s.wins||0}\nScout ${s.scouts||0}`);}
  choose(){if(this.sel===0)this.scene.start('IntroScene');if(this.sel===1&&this.state.party?.length)this.scene.start('OverworldScene');if(this.sel===2){resetState();this.state=loadState();this.render();}}
}
