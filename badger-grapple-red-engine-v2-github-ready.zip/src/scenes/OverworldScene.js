import {MAPS,TILE,getMap,findSpawn,tileAt,passableTile,findTrainer,pickEncounter,tileFrames} from '../data/maps.js';
import {ROSTER,scaledStats} from '../data/roster.js';
import {loadState,saveState,lead,caughtRecruitCount,healTeam} from '../systems/save.js';
import {uiBox,hpBar,setVirtualHandler} from '../systems/ui.js';import {setAudioMode,playSfx} from '../systems/audio.js';
const Phaser = window.Phaser;
const VERSION_LABEL='v15.0 MAP GRAMMAR';
const DIRS={down:{dx:0,dy:1,frame:0},left:{dx:-1,dy:0,frame:3},right:{dx:1,dy:0,frame:6},up:{dx:0,dy:-1,frame:9}};
export class OverworldScene extends Phaser.Scene{
  constructor(){super('OverworldScene');}
  create(){
    this.state=loadState();
    this.mapId=this.state.currentMap||'fieldhouse';this.map=getMap(this.mapId);
    setAudioMode(['fieldhouse','pavilion','downtown_club','conference'].includes(this.mapId)?'gym':'overworld');
    const rawStart=this.state.pos||findSpawn(this.mapId,'default');
    const start=this.safeStart(rawStart);
    this.tilePos={x:start.x,y:start.y};this.facing='down';this.message=this.state.message||'';this.messageOpen=!!this.message;this.moving=false;this.lastInputAt=0;this.lastStepAt=0;
    this.cameras.main.setBackgroundColor('#000');
    this.drawMap();
    this.shadow=this.add.ellipse(this.worldX(this.tilePos.x),this.worldY(this.tilePos.y)-4,24,8,0x000000,.30).setDepth(29);
    this.player=this.add.sprite(this.worldX(this.tilePos.x),this.worldY(this.tilePos.y),'player',0).setDepth(30).setOrigin(.5,1);
    this.marker=this.add.text(0,0,'▼',{fontFamily:'monospace',fontSize:14,color:'#ffe290',fontStyle:'bold',stroke:'#111',strokeThickness:4}).setOrigin(.5).setDepth(45);
    this.tweens.add({targets:this.marker,scaleX:1.08,scaleY:.82,duration:420,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});
    this.cameras.main.startFollow(this.player,true,.15,.15);this.cameras.main.setBounds(0,0,this.map.grid[0].length*TILE,this.map.grid.length*TILE);
    this.cursors=this.input.keyboard.createCursorKeys();this.keys=this.input.keyboard.addKeys('W,A,S,D,ENTER,SPACE,M');
    this.input.keyboard.on('keydown-ENTER',()=>this.interact());this.input.keyboard.on('keydown-SPACE',()=>this.interact());this.input.keyboard.on('keydown-M',()=>this.openMenu());
    setVirtualHandler(this);this.hud=this.add.container(0,0).setScrollFactor(0).setDepth(100);this.drawHud();this.savePos();
  }
  safeStart(start){const s=start||findSpawn(this.mapId,'default');if(this.pass(s.x,s.y))return s;const fallback=findSpawn(this.mapId,'default');if(this.pass(fallback.x,fallback.y))return fallback;return {x:1,y:1};}
  okInput(){const now=this.time.now||performance.now();if(now-this.lastInputAt<108)return false;this.lastInputAt=now;return true;}
  handleVirtualButton(k){if(!this.okInput())return;if(k==='up')this.tryMove(0,-1,'up');if(k==='down')this.tryMove(0,1,'down');if(k==='left')this.tryMove(-1,0,'left');if(k==='right')this.tryMove(1,0,'right');if(k==='a')this.interact();if(k==='menu')this.openMenu();if(k==='save')this.savePos('Saved. Current campaign progress is stored on this phone.');}
  update(){if(this.moving)return;if(Phaser.Input.Keyboard.JustDown(this.cursors.left)||Phaser.Input.Keyboard.JustDown(this.keys.A))this.tryMove(-1,0,'left');if(Phaser.Input.Keyboard.JustDown(this.cursors.right)||Phaser.Input.Keyboard.JustDown(this.keys.D))this.tryMove(1,0,'right');if(Phaser.Input.Keyboard.JustDown(this.cursors.up)||Phaser.Input.Keyboard.JustDown(this.keys.W))this.tryMove(0,-1,'up');if(Phaser.Input.Keyboard.JustDown(this.cursors.down)||Phaser.Input.Keyboard.JustDown(this.keys.S))this.tryMove(0,1,'down');}
  openMenu(){playSfx('menu');if(this.messageOpen){this.clearMessage();return;}this.scene.launch('MenuScene',{parent:this});}
  drawMap(){const key='scene_'+this.mapId;if(this.textures.exists(key))this.add.image(0,0,key).setOrigin(0).setDepth(0);else this.drawTiles();}
  drawTiles(){for(let y=0;y<this.map.grid.length;y++)for(let x=0;x<this.map.grid[y].length;x++){const ch=this.tile(x,y);this.add.image(x*TILE+16,y*TILE+16,'tiles',tileFrames[ch]??0).setDepth(0);}}
  tile(x,y){return tileAt(this.map,x,y);}
  pass(x,y){return passableTile(this.tile(x,y));}
  worldX(x){return x*TILE+16;}
  worldY(y){return y*TILE+32;}
  face(dir){this.facing=dir;this.player.stop();this.player.setFrame(DIRS[dir]?.frame||0);}
  frontPos(){const d=DIRS[this.facing]||DIRS.down;return {x:this.tilePos.x+d.dx,y:this.tilePos.y+d.dy};}
  target(){const here={x:this.tilePos.x,y:this.tilePos.y,ch:this.tile(this.tilePos.x,this.tilePos.y),front:false};if(this.isActionTile(here.ch))return here;const f=this.frontPos();return {x:f.x,y:f.y,ch:this.tile(f.x,f.y),front:true};}
  isActionTile(ch){return ch==='w'||/[1-9]/.test(ch);}
  hasMarker(ch){return ch==='w'||ch==='R'||ch==='S'||/[1-9]/.test(ch)||['C','A','D','H','V'].includes(ch)||!!findTrainer(this.map,ch)||!!this.map.npcs?.[ch]||!!this.map.signs?.[ch];}
  tryMove(dx,dy,dir){
    if(this.messageOpen){this.clearMessage();return;}this.face(dir);const nx=this.tilePos.x+dx,ny=this.tilePos.y+dy,ch=this.tile(nx,ny);
    if(!this.pass(nx,ny)){this.drawHud();this.showMessage(this.promptFor(ch));return;}
    this.tilePos={x:nx,y:ny};this.moving=true;this.marker.setVisible(false);this.player.play('walk-'+dir,true);playSfx('step');
    this.tweens.add({targets:this.player,scaleX:1.035,scaleY:.965,duration:58,yoyo:true,ease:'Sine.easeInOut'});
    this.tweens.add({targets:this.shadow,x:this.worldX(nx),y:this.worldY(ny)-4,duration:118,ease:'Linear'});
    this.tweens.add({targets:this.player,x:this.worldX(nx),y:this.worldY(ny),duration:118,ease:'Linear',onComplete:()=>{this.player.setScale(1);this.moving=false;this.face(dir);this.afterStep();}});
  }
  afterStep(){this.savePos();const ch=this.tile(this.tilePos.x,this.tilePos.y);if(/[1-9]/.test(ch)){this.doWarp(ch);return;}if(ch==='w')this.grassRustle();if(ch==='w'&&this.map.encounters?.length&&Math.random()<(this.map.encounterRate||0)){const enc=pickEncounter(this.map);if(enc){this.state.dex.seen[enc.id]=true;this.savePos();this.startBattle({team:[[enc.id,enc.lvl]],type:'wild'});return;}}this.drawHud();}
  grassRustle(){const x=this.worldX(this.tilePos.x),y=this.worldY(this.tilePos.y)-15;const g=this.add.graphics().setDepth(28);g.lineStyle(2,0xd7ffb8,.9);g.beginPath();g.moveTo(x-11,y+8);g.lineTo(x-7,y);g.lineTo(x-3,y+8);g.moveTo(x+3,y+8);g.lineTo(x+7,y);g.lineTo(x+11,y+8);g.strokePath();this.tweens.add({targets:g,y:-8,alpha:0,duration:260,ease:'Sine.easeOut',onComplete:()=>g.destroy()});}
  interact(){
    playSfx('select');
    if(this.messageOpen){this.clearMessage();return;}
    const t=this.target(),ch=t.ch;
    if(/[1-9]/.test(ch))return this.doWarp(ch);
    if(ch==='R')return this.recover();
    if(ch==='S')return this.scene.launch('MenuScene',{parent:this,tab:'shop'});
    if(ch==='w')return this.startScout();
    if(ch==='C'||ch==='A'||ch==='D')return this.startBoss(ch);
    if(ch==='H')return this.startChampion();
    if(ch==='V')return this.startRival();
    const tr=findTrainer(this.map,ch);if(tr)return this.startTrainer(tr);
    if(this.map.npcs?.[ch])return this.showMessage(this.map.npcs[ch]);
    if(this.map.signs?.[ch])return this.showMessage(this.map.signs[ch]);
    this.showMessage(this.promptFor(ch));
  }
  recover(){healTeam(this.state);this.savePos('Recovery: team restored. HP, gas, and match scores reset.');}
  doWarp(ch){const w=this.map.warps?.[ch];if(!w)return this.showMessage('No route is connected here yet.');const have=this.state.badges.length;if(have<(w.gate||0))return this.showMessage(`Gate check: ${w.label||'that route'} needs ${w.gate} badge${w.gate===1?'':'s'}. You have ${have}.`);const next=getMap(w.map);const spawn=findSpawn(w.map,w.spawn);this.state.currentMap=w.map;this.state.pos=spawn;this.state.message=`Entered ${next.name}.`;saveState(this.state);playSfx('warp');this.cameras.main.fadeOut(140,0,0,0);this.time.delayedCall(150,()=>this.scene.start('OverworldScene'));}
  startScout(){const enc=pickEncounter(this.map);if(!enc)return this.showMessage('No wild recruits are active in this zone.');this.state.dex.seen[enc.id]=true;this.state.stats.scouts=(this.state.stats.scouts||0)+1;this.savePos();this.cameras.main.fadeOut(140,0,0,0);this.time.delayedCall(150,()=>this.scene.start('ScoutScene',{id:enc.id,lvl:enc.lvl,mapId:this.mapId}));}
  startBoss(ch){const b=this.map.boss;if(!b||b.key!==ch)return this.showMessage('No badge match here.');if(this.state.badges.includes(b.badge))return this.showMessage(b.beaten||'Badge already earned.');this.showMessage(b.intro);this.time.delayedCall(450,()=>this.startBattle({team:b.team,type:'boss',title:b.id,badge:b.badge,reward:{rep:14,grit:22},defeatKey:'badge_'+b.badge,message:b.beaten}));}
  startChampion(){const c=this.map.champion;if(!c)return this.showMessage('The championship table is not ready yet.');if(this.state.badges.includes(c.badge))return this.showMessage(c.beaten);this.showMessage(c.intro);this.time.delayedCall(450,()=>this.startBattle({team:c.team,type:'champion',badge:c.badge,reward:{rep:32,grit:30},defeatKey:'champion',message:c.beaten}));}
  startTrainer(tr){if(this.state.trainersDefeated?.[tr.id])return this.showMessage(tr.beaten||`${tr.name} has already been beaten.`);this.showMessage(tr.line||`${tr.name} challenges you.`);this.time.delayedCall(400,()=>this.startBattle({team:tr.team,type:'trainer',trainerName:tr.name,reward:tr.reward,defeatKey:tr.id,message:tr.beaten}));}
  rivalId(){const starter=this.state.rivalStarter||this.state.party?.[0]?.id;const style=ROSTER[starter]?.style;if(style==='Top')return 'rivalscramble';if(style==='Scramble')return 'rivalneutral';return 'rivaldefense';}
  startRival(){const r=this.map.rival;if(!r)return this.showMessage('Rex is not here.');if(this.state.trainersDefeated?.[r.id])return this.showMessage(r.beaten||'Rex already left this route.');const rid=this.rivalId();const team=r.id==='rival_route3'?[[rid,r.lvl],['overtimekid',r.lvl-1],['wallride',r.lvl-1]]:[[rid,r.lvl]];this.showMessage(r.line);this.time.delayedCall(420,()=>this.startBattle({team,type:'rival',trainerName:'Rex',reward:r.reward,defeatKey:r.id,message:r.beaten}));}
  startBattle(cfg){this.savePos();playSfx('warp');this.cameras.main.flash(120,255,255,255);this.time.delayedCall(120,()=>this.scene.start('BattleScene',cfg));}
  savePos(msg=null){this.state.currentMap=this.mapId;this.state.pos={...this.tilePos};if(msg)this.state.message=msg;saveState(this.state);if(msg)this.showMessage(msg);}
  showMessage(msg){this.message=msg||'Nothing to do here.';this.messageOpen=true;this.drawHud();}
  clearMessage(){this.message='';this.messageOpen=false;this.state.message='';saveState(this.state);this.drawHud();}
  objective(){const badges=this.state.badges||[],caught=caughtRecruitCount(this.state);if(!this.state.party.length)return 'Choose a starter.';if(!badges.includes('Neutral Badge'))return `Objective: scout recruits, beat Captain Neutral for Badge 1. Recruits ${caught}.`;if(!badges.includes('Top Badge'))return 'Objective: cross Campus Quad and Lakeshore Path. Beat the Pavilion Anchor.';if(!badges.includes('Scramble Badge'))return 'Objective: win downtown and earn Badge 3.';if(!badges.includes('Champion Plaque'))return 'Objective: clear the Conference Arena gauntlet.';return 'Campaign clear: fill the RosterDex and level the room.';}
  promptFor(ch){if(ch==='R')return 'A: Recovery — restore HP and gas';if(ch==='S')return 'A: Team Shop — buy energy, chalk, invites';if(['C','A','D'].includes(ch))return 'A: Badge dual — scheduled match';if(ch==='H')return 'A: Championship gauntlet';if(ch==='w')return 'A: Scout preview — wild match';if(ch==='V')return 'A: Rival Rex match';if(/[1-9]/.test(ch))return 'A/step: change area';const tr=findTrainer(this.map,ch);if(tr)return this.state.trainersDefeated?.[tr.id]?(tr.beaten||'Trainer beaten.'):`A: ${tr.name}`;if(this.map.npcs?.[ch])return 'A: Talk';if(this.map.signs?.[ch])return 'A: Read';return `${this.map.name}: D-pad move. A interacts. Menu opens team/shop/save.`;}
  drawHud(){
    this.hud.removeAll(true);const top=this.add.graphics().setScrollFactor(0);top.fillStyle(0x050609,.94);top.fillRoundedRect(8,8,464,58,8);top.lineStyle(2,0x7d1017,1);top.strokeRoundedRect(8,8,464,58,8);this.hud.add(top);
    const l=lead(this.state);const leadName=l?`${ROSTER[l.id].name.replace(' Shotmaker','').replace(' Partner','')} L${l.lvl}`:'No starter';
    this.hud.add(this.add.text(18,13,`${this.map.name} • ${VERSION_LABEL}`,{fontFamily:'monospace',fontSize:10,color:'#f4e6c7',fontStyle:'bold'}).setScrollFactor(0));
    this.hud.add(this.add.text(18,29,`${leadName} | Badges ${this.state.badges.length} | Grit ${this.state.grit} Rep ${this.state.rep} Inv ${this.state.items.invite}`,{fontFamily:'monospace',fontSize:9,color:'#f4e6c7'}).setScrollFactor(0));
    this.hud.add(this.add.text(18,45,this.objective(),{fontFamily:'monospace',fontSize:9,color:'#ffe290',wordWrap:{width:295}}).setScrollFactor(0));
    if(l){const s=scaledStats(l.id,l.lvl);this.hud.add(hpBar(this,334,22,100,7,l.hp/s.hp,0x55b867).setScrollFactor(0));this.hud.add(hpBar(this,334,36,100,6,l.gas/s.gas,0x5aa4e6).setScrollFactor(0));}
    const t=this.target();const prompt=this.promptFor(t.ch);const bottom=this.add.graphics().setScrollFactor(0);bottom.fillStyle(0x050609,.94);bottom.fillRoundedRect(10,386,460,34,8);bottom.lineStyle(2,0x7d1017,1);bottom.strokeRoundedRect(10,386,460,34,8);this.hud.add(bottom);this.hud.add(this.add.text(22,397,prompt,{fontFamily:'monospace',fontSize:10,color:'#f4e6c7',wordWrap:{width:436}}).setScrollFactor(0));
    const show=this.hasMarker(t.ch)&&!this.messageOpen;this.marker.setVisible(show);if(show)this.marker.setPosition(this.worldX(t.x),this.worldY(t.y)-42);
    if(this.messageOpen&&this.message){const box=uiBox(this,20,292,440,88).setScrollFactor(0);this.hud.add(box);this.hud.add(this.add.text(38,309,this.message,{fontFamily:'monospace',fontSize:13,color:'#111',wordWrap:{width:400}}).setScrollFactor(0));this.hud.add(this.add.text(394,354,'A: OK',{fontFamily:'monospace',fontSize:12,color:'#555',fontStyle:'bold'}).setScrollFactor(0));}
  }
}
