import {FIELD_MAP,TILE,findStart} from '../data/maps.js';import {ROSTER,scaledStats} from '../data/roster.js';import {loadState,saveState,lead,caughtRecruitCount} from '../systems/save.js';import {uiBox,hpBar,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
export class OverworldScene extends Phaser.Scene{
  constructor(){super('OverworldScene');}
  create(){
    this.state=loadState();
    const start=this.state.pos||findStart();
    this.tilePos={...start};this.mapOffsetY=0;this.bottomPad=0;this.message=this.state.message||'';this.messageOpen=!!this.message;this.moving=false;this.lastInputAt=0;
    this.cameras.main.setBackgroundColor('#060607');
    this.drawMap();
    this.shadow=this.add.ellipse(this.worldX(this.tilePos.x),this.worldY(this.tilePos.y)+1,26,8,0x000000,.62).setDepth(18);
    this.player=this.add.sprite(this.worldX(this.tilePos.x),this.worldY(this.tilePos.y),'player',0).setDepth(20).setScale(1.28);this.player.setOrigin(.5,1);
    this.marker=this.add.text(this.player.x,this.player.y-54,'A',{fontFamily:'monospace',fontSize:14,color:'#ffe290',fontStyle:'bold',stroke:'#111',strokeThickness:4}).setOrigin(.5).setDepth(21);
    this.cameras.main.setBounds(0,0,FIELD_MAP[0].length*TILE,FIELD_MAP.length*TILE);this.cameras.main.setRoundPixels(true);this.updateCamera(true);
    this.cursors=this.input.keyboard.createCursorKeys();this.keys=this.input.keyboard.addKeys('W,A,S,D,ENTER,SPACE,M');
    this.input.keyboard.on('keydown-ENTER',()=>this.interact());this.input.keyboard.on('keydown-SPACE',()=>this.interact());this.input.keyboard.on('keydown-M',()=>this.openMenu());
    setVirtualHandler(this);this.hud=this.add.container(0,0).setScrollFactor(0).setDepth(100);this.drawHud();
  }
  okInput(){const now=this.time.now||performance.now();if(now-this.lastInputAt<105)return false;this.lastInputAt=now;return true;}
  handleVirtualButton(k){if(!this.okInput())return;if(k==='up')this.tryMove(0,-1,'up');if(k==='down')this.tryMove(0,1,'down');if(k==='left')this.tryMove(-1,0,'left');if(k==='right')this.tryMove(1,0,'right');if(k==='a')this.interact();if(k==='menu')this.openMenu();if(k==='save')this.savePos('Saved. Current progress stored on this phone.');}
  update(){if(this.moving)return;if(Phaser.Input.Keyboard.JustDown(this.cursors.left)||Phaser.Input.Keyboard.JustDown(this.keys.A))this.tryMove(-1,0,'left');if(Phaser.Input.Keyboard.JustDown(this.cursors.right)||Phaser.Input.Keyboard.JustDown(this.keys.D))this.tryMove(1,0,'right');if(Phaser.Input.Keyboard.JustDown(this.cursors.up)||Phaser.Input.Keyboard.JustDown(this.keys.W))this.tryMove(0,-1,'up');if(Phaser.Input.Keyboard.JustDown(this.cursors.down)||Phaser.Input.Keyboard.JustDown(this.keys.S))this.tryMove(0,1,'down');}
  openMenu(){if(this.messageOpen){this.clearMessage();return;}this.scene.launch('MenuScene',{parent:this});}
  drawMap(){
    this.add.image(0,0,'fieldhouse_scene').setOrigin(0).setDepth(0);
    // Subtle scout-zone glow, not tile-grid noise.
    const g=this.add.graphics().setDepth(4);
    g.lineStyle(2,0xffe290,.45);g.fillStyle(0x5fbf6e,.08);
    for(let y=0;y<FIELD_MAP.length;y++)for(let x=0;x<FIELD_MAP[y].length;x++)if(this.tile(x,y)==='g')g.fillRect(x*TILE+3,y*TILE+3,26,26);
  }
  tile(x,y){if(y<0||y>=FIELD_MAP.length||x<0||x>=FIELD_MAP[0].length)return '#';return FIELD_MAP[y][x];}
  pass(x,y){return !['#','~'].includes(this.tile(x,y));}
  objective(){const caught=caughtRecruitCount(this.state);if(!this.state.party.length)return 'Choose a starter.';if((this.state.stats?.scouts||0)<1)return 'Step into the Scout Zone and press A.';if(caught<2)return `Recruit 2 wrestlers (${caught}/2). Win scout matches, then invite.`;if(!this.state.badges.includes('Neutral Badge'))return 'Beat the Captain Match for your first badge.';return 'Build the room and fill the RosterDex.';}
  promptFor(ch){if(ch==='R')return 'Recovery Center — restore HP and gas';if(ch==='S')return 'Badger Shop — buy energy, tape, invites';if(ch==='C')return 'Captain Match — badge test';if(ch==='g')return 'Scout Zone — preview a recruit';if(ch==='T')return 'Trainer tip';if(ch==='N')return 'Manager tip';if(ch==='P')return 'Main hub — use the Scout Zone to build your room';return 'Find the Scout Zone. Menu opens team, shop, save, and reset.';}
  worldX(x){return x*TILE+16;}
  worldY(y){return this.mapOffsetY+y*TILE+31;}
  markerY(){return this.player.y-54;}
  syncGround(){if(this.shadow)this.shadow.setPosition(this.player.x,this.player.y+2);if(this.marker)this.marker.setPosition(this.player.x,this.markerY());this.updateCamera(false);}
  updateCamera(snap=false){const cam=this.cameras.main;const maxX=Math.max(0,FIELD_MAP[0].length*TILE-cam.width);const tx=Phaser.Math.Clamp(this.player.x-240,0,maxX);const ty=0;if(snap){cam.scrollX=Math.round(tx);cam.scrollY=ty;}else{cam.scrollX=Phaser.Math.Linear(cam.scrollX,tx,.42);cam.scrollY=0;}}
  face(dir){this.player.stop();this.player.setFrame(dir==='down'?0:dir==='left'?3:dir==='right'?6:9);this.syncGround();}
  tryMove(dx,dy,dir){if(this.messageOpen){this.clearMessage();return;}this.face(dir);const nx=this.tilePos.x+dx,ny=this.tilePos.y+dy;if(!this.pass(nx,ny)){this.showMessage('Blocked. Try another direction.');return;}this.tilePos={x:nx,y:ny};this.moving=true;this.player.play('walk-'+dir,true);this.tweens.add({targets:this.player,x:this.worldX(nx),y:this.worldY(ny),duration:118,ease:'Linear',onUpdate:()=>this.syncGround(),onComplete:()=>{this.moving=false;this.face(dir);this.drawHud();}});}
  interact(){if(this.messageOpen){this.clearMessage();return;}const ch=this.tile(this.tilePos.x,this.tilePos.y);if(ch==='R'){this.state.party.forEach(m=>{const s=scaledStats(m.id,m.lvl);m.hp=s.hp;m.gas=s.gas;m.score=0;});this.savePos('Recovery Center: team restored. HP, gas, and match score reset.');}else if(ch==='S'){this.scene.launch('MenuScene',{parent:this,tab:'shop'});}else if(ch==='C'){this.startBattle('captainneutral',7,'captain');}else if(ch==='g'){this.startScout();}else if(ch==='T'){this.showMessage('Trainer: choose moves with a style edge. Neutral beats Scramble. Scramble beats Top. Top beats Pace.');}else if(ch==='N'){this.showMessage('Manager: after a scout-zone win, press A to spend a Roster Invite. Buy more in the shop with Rep.');}else{this.showMessage(this.promptFor(ch));}}
  startScout(){const ids=['buckshot','matreturner','fieldflyer','pacesetter','drillpartner','lakechain','tilttech'];const id=Phaser.Utils.Array.GetRandom(ids),lvl=Phaser.Math.Between(2,5);this.state.dex.seen[id]=true;this.state.stats.scouts=(this.state.stats.scouts||0)+1;this.savePos();this.cameras.main.fadeOut(160,0,0,0);this.time.delayedCall(170,()=>this.scene.start('ScoutScene',{id,lvl}));}
  startBattle(id,lvl,type){this.savePos();this.cameras.main.flash(160,255,255,255);this.time.delayedCall(160,()=>this.scene.start('BattleScene',{enemyId:id,enemyLevel:lvl,battleType:type}));}
  savePos(msg=null){this.state.pos={...this.tilePos};if(msg)this.state.message=msg;saveState(this.state);if(msg)this.showMessage(msg);}
  showMessage(msg){this.message=msg;this.messageOpen=true;this.drawHud();}
  clearMessage(){this.message='';this.messageOpen=false;this.state.message='';saveState(this.state);this.drawHud();}
  drawHud(){
    this.hud.removeAll(true);
    const top=this.add.graphics().setScrollFactor(0);top.fillStyle(0x050609,.98);top.fillRoundedRect(7,7,466,43,4);top.lineStyle(2,0x7d1017,1);top.strokeRoundedRect(7,7,466,43,4);this.hud.add(top);
    this.hud.add(this.add.text(20,14,'W',{fontFamily:'monospace',fontSize:23,color:'#b41820',fontStyle:'bold',stroke:'#f2e6c6',strokeThickness:1}).setScrollFactor(0));
    this.hud.add(this.add.text(52,17,'FIELD HOUSE',{fontFamily:'monospace',fontSize:17,color:'#f4e6c7',fontStyle:'bold'}).setScrollFactor(0));
    const l=lead(this.state);const leadName=l?`${ROSTER[l.id].name.replace(' Shotmaker','').replace(' Partner','')} L${l.lvl}`:'No starter';
    this.hud.add(this.add.text(244,17,`● ${this.state.grit}`,{fontFamily:'monospace',fontSize:13,color:'#ffe290',fontStyle:'bold'}).setScrollFactor(0));
    this.hud.add(this.add.text(316,17,`Inv ${this.state.items.invite}`,{fontFamily:'monospace',fontSize:13,color:'#f4e6c7',fontStyle:'bold'}).setScrollFactor(0));
    this.hud.add(this.add.text(392,17,`Rep ${this.state.rep}`,{fontFamily:'monospace',fontSize:13,color:'#f4e6c7',fontStyle:'bold'}).setScrollFactor(0));
    if(l){const s=scaledStats(l.id,l.lvl);this.hud.add(hpBar(this,318,36,70,5,l.hp/s.hp,0x55b867).setScrollFactor(0));this.hud.add(hpBar(this,394,36,70,5,l.gas/s.gas,0x5aa4e6).setScrollFactor(0));}
    const ch=this.tile(this.tilePos.x,this.tilePos.y);const prompt=this.promptFor(ch);
    const bottom=this.add.graphics().setScrollFactor(0);bottom.fillStyle(0x050609,.98);bottom.fillRoundedRect(18,352,444,70,6);bottom.lineStyle(2,0x7d1017,1);bottom.strokeRoundedRect(18,352,444,70,6);this.hud.add(bottom);
    this.hud.add(this.add.text(34,363,this.messageOpen?this.message:prompt,{fontFamily:'monospace',fontSize:14,color:'#f4e6c7',wordWrap:{width:350}}).setScrollFactor(0));
    this.hud.add(this.add.text(34,401,this.messageOpen?'A: OK':this.objective(),{fontFamily:'monospace',fontSize:10,color:'#ffe290',wordWrap:{width:350}}).setScrollFactor(0));
    this.hud.add(this.add.text(386,382,this.messageOpen?'OK':'A',{fontFamily:'monospace',fontSize:18,color:'#ffe290',fontStyle:'bold',stroke:'#111',strokeThickness:4}).setOrigin(.5).setScrollFactor(0));
    this.marker.setVisible(['R','S','C','g','T','N','P'].includes(ch)&&!this.messageOpen);
  }
}
