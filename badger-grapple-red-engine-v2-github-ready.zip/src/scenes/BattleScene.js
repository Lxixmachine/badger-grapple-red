import {ROSTER,makeMon,scaledStats,addXp} from '../data/roster.js';import {MOVES,ADV} from '../data/moves.js';import {loadState,saveState,lead} from '../systems/save.js';import {uiBox,hpBar,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
export class BattleScene extends Phaser.Scene{
  constructor(){super('BattleScene');}
  create(data={}){
    this.state=loadState();
    this.enemy=makeMon(data.enemyId||'calder',data.enemyLevel||4);
    this.type=data.battleType||'wild';
    this.turn=1;this.sel=0;this.over=false;this.recruit=false;this.lastInputAt=0;this.impact='';this.resultTitle='';
    this.bg=[];this.ui=null;
    this.log=[`${ROSTER[this.enemy.id]?.name||'Recruit'} steps onto the mat.`,'Pick a move. Press A to attack.'];
    const l=lead(this.state);
    if(l){
      const s=scaledStats(l.id,l.lvl);
      if(!Number.isFinite(l.hp)||l.hp<=0)l.hp=s.hp;
      if(!Number.isFinite(l.gas)||l.gas<=0)l.gas=s.gas;
      l.score=0;
    }
    this.enemy.score=0;
    this.state.stats={scouts:0,battles:0,wins:0,recruits:0,streak:0,...(this.state.stats||{})};
    this.state.stats.battles++;
    saveState(this.state);
    this.input.keyboard.on('keydown-LEFT',()=>this.move(-1));
    this.input.keyboard.on('keydown-RIGHT',()=>this.move(1));
    this.input.keyboard.on('keydown-UP',()=>this.move(2));
    this.input.keyboard.on('keydown-DOWN',()=>this.move(2));
    this.input.keyboard.on('keydown-ENTER',()=>this.choose());
    this.input.keyboard.on('keydown-SPACE',()=>this.choose());
    this.input.keyboard.on('keydown-ESC',()=>this.battleBack());
    setVirtualHandler(this);
    this.drawBattle();
  }
  okInput(){const now=this.time.now||performance.now();if(now-this.lastInputAt<160)return false;this.lastInputAt=now;return true;}
  handleVirtualButton(k){if(!this.okInput())return;if(k==='left')this.move(-1);if(k==='right')this.move(1);if(k==='up'||k==='down')this.move(2);if(k==='a')this.choose();if(k==='b')this.battleBack();}
  addLog(lines){this.log=[...lines,...this.log].slice(0,5);}
  addBg(obj){this.bg.push(obj);return obj;}
  clearBg(){this.bg.forEach(o=>{try{o.destroy();}catch{}});this.bg=[];}
  battleBack(){if(this.over){this.returnMap();return;}this.impact='B OFF';this.addLog(['B is disabled during live matches. Use A to wrestle.']);this.drawBattle();}
  selectedMove(){const l=lead(this.state);if(!l)return null;const key=ROSTER[l.id]?.moves?.[this.sel];return MOVES[key]||null;}
  styleNote(move){if(!move)return 'NO MOVE';const er=ROSTER[this.enemy.id];if(!er)return 'UNKNOWN';if(ADV[move.style]===er.style)return 'STYLE EDGE';if(ADV[er.style]===move.style)return 'BAD MATCHUP';return 'NEUTRAL';}
  drawBattle(){
    this.clearBg();
    if(this.ui)this.ui.destroy(true);
    this.cameras.main.setBackgroundColor('#16181e');

    this.addBg(this.add.image(240,216,'battle_arena').setDepth(0));

    this.addBg(uiBox(this,18,32,204,72).setDepth(3));
    this.addBg(uiBox(this,258,32,204,72).setDepth(3));
    this.addBg(uiBox(this,18,230,444,82).setDepth(3));
    this.addBg(uiBox(this,18,318,444,104).setDepth(3));

    this.ui=this.add.container(0,0).setDepth(20);

    const l=lead(this.state);
    if(!l){this.over=true;this.addLog(['No starter found. Press A/B to return.']);}
    const lr=l?ROSTER[l.id]:ROSTER.buckshot;
    const er=ROSTER[this.enemy.id]||ROSTER.calder;

    this.ui.add(this.add.text(240,13,'FIRE POLISH v13.0 • CLEAR DUAL',{fontFamily:'monospace',fontSize:12,color:'#f4e6c7',fontStyle:'bold'}).setOrigin(.5));

    this.drawWrestler(132,176,lr?.asset||'neutral',true,'YOU');
    this.drawWrestler(350,168,er?.asset||'neutral',false,'OPP');

    if(l)this.drawHud(18,32,l,lr,'YOU');
    this.drawHud(258,32,this.enemy,er,'OPP');

    if(this.impact){
      this.ui.add(this.add.text(240,213,this.impact,{fontFamily:'monospace',fontSize:20,color:'#ffe290',fontStyle:'bold',stroke:'#111',strokeThickness:5}).setOrigin(.5));
    }

    this.ui.add(this.add.text(34,238,'MATCH LOG',{fontFamily:'monospace',fontSize:10,color:'#555',fontStyle:'bold'}));
    this.log.slice(0,3).forEach((line,i)=>{
      this.ui.add(this.add.text(34,253+i*16,line,{fontFamily:'monospace',fontSize:11,color:i===0?'#b41820':'#111',wordWrap:{width:410}}));
    });

    if(this.over)this.drawResultCard();
    else this.drawCommandPanel();
  }
  drawWrestler(x,y,asset,isBack,label){
    const key='battle_'+asset+(isBack?'_back':'');
    const scale=isBack?1.28:1.30;
    this.ui.add(this.add.ellipse(x,y+54,isBack?86:92,isBack?18:20,0x000000,.44));
    if(this.textures.exists(key)){
      const img=this.add.image(x,y,key).setScale(scale).setFlipX(false);
      this.ui.add(img);
    }else{
      this.ui.add(this.add.ellipse(x,y,56,74,isBack?0xb41820:0x2c3442).setStrokeStyle(4,0xf2e6c6));
      this.ui.add(this.add.text(x,y,label,{fontFamily:'monospace',fontSize:12,color:'#fff',fontStyle:'bold'}).setOrigin(.5));
    }
    this.ui.add(this.add.text(x,y+64,label,{fontFamily:'monospace',fontSize:10,color:'#f4e6c7',fontStyle:'bold',stroke:'#111',strokeThickness:3}).setOrigin(.5));
  }
  drawHud(x,y,m,r,label){
    const s=scaledStats(m.id,m.lvl);
    const name=(r.name||'Wrestler').replace(' Shotmaker','').replace(' Partner','');
    this.ui.add(this.add.text(x+10,y+7,`${label}: ${name} Lv ${m.lvl}`,{fontFamily:'monospace',fontSize:10,color:'#111',fontStyle:'bold'}));
    this.ui.add(hpBar(this,x+12,y+28,170,8,m.hp/s.hp,0x55b867));
    this.ui.add(hpBar(this,x+12,y+42,170,6,m.gas/s.gas,0x5aa4e6));
    this.ui.add(this.add.text(x+12,y+55,`HP ${m.hp}/${s.hp} • Score ${m.score||0}`,{fontFamily:'monospace',fontSize:9,color:'#333'}));
  }
  drawCommandPanel(){
    const mv=this.selectedMove();
    this.ui.add(this.add.text(34,327,'MOVES',{fontFamily:'monospace',fontSize:10,color:'#555',fontStyle:'bold'}));
    this.drawMoves(34,344);
    if(mv){
      const note=this.styleNote(mv);
      const acc=Math.round(mv.acc*100);
      const noteColor=note==='STYLE EDGE'?'#b41820':note==='BAD MATCHUP'?'#7b3f00':'#555';
      this.ui.add(this.add.text(240,392,`${mv.name}: Pow ${mv.power} • Acc ${acc}% • Gas ${mv.gas} • ${note}`,{fontFamily:'monospace',fontSize:8,color:noteColor,fontStyle:'bold'}).setOrigin(.5));
    }
    this.ui.add(this.add.text(240,410,'A ATTACK  •  D-PAD PICK MOVE  •  B BACK AFTER MATCH',{fontFamily:'monospace',fontSize:9,color:'#333',fontStyle:'bold'}).setOrigin(.5));
  }
  drawMoves(x,y){
    const l=lead(this.state);
    if(!l)return;
    const moves=ROSTER[l.id]?.moves||[];
    moves.forEach((key,i)=>{
      const m=MOVES[key];
      if(!m)return;
      const tx=x+(i%2)*214,ty=y+Math.floor(i/2)*22;
      if(i===this.sel){this.ui.add(this.add.rectangle(tx+74,ty+8,154,18,0xffe290,.45).setStrokeStyle(1,0xb41820));}
      this.ui.add(this.add.text(tx,ty,`${i===this.sel?'▶ ':'  '}${m.name}`,{fontFamily:'monospace',fontSize:13,color:i===this.sel?'#b41820':'#111',fontStyle:'bold'}));
    });
  }
  drawResultCard(){
    const l=lead(this.state);
    const title=this.resultTitle|| (this.recruit?'WIN — RECRUIT WINDOW':'RESULT CARD');
    this.ui.add(this.add.text(240,337,title,{fontFamily:'monospace',fontSize:14,color:'#111',fontStyle:'bold'}).setOrigin(.5));
    this.ui.add(this.add.text(240,358,`Score ${l?.score||0}-${this.enemy.score||0} • Turns ${this.turn} • Streak ${this.state.stats.streak||0}`,{fontFamily:'monospace',fontSize:10,color:'#333'}).setOrigin(.5));
    this.ui.add(this.add.text(240,377,this.recruit?'A: Spend Invite   B: Return to Field House':'A/B: Return to Field House',{fontFamily:'monospace',fontSize:12,color:'#111',fontStyle:'bold'}).setOrigin(.5));
    this.ui.add(this.add.text(240,397,`Grit ${this.state.grit} • Rep ${this.state.rep} • Invites ${this.state.items.invite} • Wins ${this.state.stats.wins||0}`,{fontFamily:'monospace',fontSize:9,color:'#555'}).setOrigin(.5));
    this.ui.add(this.add.text(240,410,'Result stays here until you choose where to go.',{fontFamily:'monospace',fontSize:9,color:'#555'}).setOrigin(.5));
  }
  move(d){
    if(this.over)return;
    const l=lead(this.state);const count=ROSTER[l?.id]?.moves?.length||4;
    this.sel=Phaser.Math.Wrap(this.sel+d,0,count);
    this.impact='';
    this.drawBattle();
  }
  choose(){
    if(this.over){if(this.recruit)this.tryRecruit();else this.returnMap();return;}
    const l=lead(this.state);
    if(!l){this.returnMap();return;}
    const key=ROSTER[l.id]?.moves?.[this.sel];
    if(!key){this.addLog(['No move selected.']);this.drawBattle();return;}
    this.resolveTurn(key);
  }
  resolveTurn(key){
    const l=lead(this.state),e=this.enemy;
    if(!l){this.returnMap();return;}
    const beforeEnemy=e.hp,beforeYou=l.hp;
    const first=this.resolve(l,e,key,'You');
    const lines=[`Turn ${this.turn}: ${first.line}`];
    this.impact=first.hit?`-${first.dmg}`:'MISS';
    if(e.hp<=0){
      lines.push(`${ROSTER[e.id].name} is out of condition.`);
      lines.push(`Opponent HP ${beforeEnemy}→${e.hp}`);
      this.addLog(lines);
      this.win();
      return;
    }
    const enemyMoves=ROSTER[e.id]?.moves||['stall'];
    const ek=Phaser.Utils.Array.GetRandom(enemyMoves);
    const second=this.resolve(e,l,ek,ROSTER[e.id].name);
    lines.push(second.line);
    lines.push(`HP: You ${beforeYou}→${l.hp} | Opp ${beforeEnemy}→${e.hp}`);
    this.addLog(lines);
    this.turn++;
    if(l.hp<=0){this.impact='YOU ARE OUT';this.lose();return;}
    saveState(this.state);
    this.cameras.main.flash(70,255,255,255);
    this.drawBattle();
  }
  resolve(att,def,key,label){
    let mv=MOVES[key]||MOVES.stall,as=scaledStats(att.id,att.lvl),ds=scaledStats(def.id,def.lvl);
    if(mv.gas>0&&att.gas<mv.gas)mv=MOVES.stall;
    att.gas=Phaser.Math.Clamp(att.gas-Math.max(0,mv.gas),0,as.gas);
    if(mv.gas<0)att.gas=Phaser.Math.Clamp(att.gas+Math.abs(mv.gas),0,as.gas);
    let acc=mv.acc+(att.boost?0.1:0);
    if(att.gas<12)acc-=0.12;
    att.boost=false;
    if(Math.random()>acc)return {line:`${label}: ${mv.name} missed.`,hit:false,dmg:0};
    const defStyle=ROSTER[def.id]?.style;
    const mult=ADV[mv.style]===defStyle?1.22:ADV[defStyle]===mv.style?0.88:1;
    const dmg=Math.max(3,Math.round((mv.power+as.atk*.8-ds.def*.38)*mult*(.86+Math.random()*.28)));
    def.hp=Phaser.Math.Clamp(def.hp-dmg,0,ds.hp);
    att.score=(att.score||0)+mv.points;
    const bonus=mult>1?' Style edge.':mult<1?' Bad matchup.':'';
    return {line:`${label}: ${mv.name} hits for ${dmg}.${bonus}`,hit:true,dmg};
  }
  win(){
    const l=lead(this.state);
    this.over=true;this.resultTitle='VICTORY';
    this.state.stats.wins=(this.state.stats.wins||0)+1;
    this.state.stats.streak=(this.state.stats.streak||0)+1;
    const gritGain=this.type==='captain'?22:Phaser.Math.Between(6,10),repGain=this.type==='captain'?14:Phaser.Math.Between(2,5);
    this.state.grit+=gritGain;this.state.rep+=repGain;
    this.addLog([`Victory reward: +${gritGain} Grit, +${repGain} Rep.`]);
    if(l)addXp(l,10+this.enemy.lvl*5).forEach(x=>this.log.unshift(x));
    if(this.type==='captain'&&!this.state.badges.includes('Neutral Badge')){this.state.badges.push('Neutral Badge');this.log.unshift('Badge earned: Neutral Badge.');}
    if(this.type==='wild'){
      this.recruit=true;
      const odds={Common:'72%',Uncommon:'55%',Rare:'38%',Elite:'16%'}[ROSTER[this.enemy.id].rarity]||'40%';
      this.log.unshift(`Recruit window open. Invite odds: ${odds}.`);
    }
    this.state.message=`Victory over ${ROSTER[this.enemy.id].name}.`;
    saveState(this.state);
    this.drawBattle();
  }
  lose(){
    this.over=true;this.recruit=false;this.resultTitle='LOSS — TEAM RECOVERED';
    this.state.stats.streak=0;
    this.state.grit+=4;this.state.rep+=2;
    this.state.party.forEach(m=>{const s=scaledStats(m.id,m.lvl);m.hp=s.hp;m.gas=s.gas;m.score=0;});
    this.addLog(['Loss: +4 Grit, +2 Rep. Team recovered.']);
    this.state.message='Loss: +4 Grit, +2 Rep. Team recovered.';
    saveState(this.state);
    this.drawBattle();
  }
  tryRecruit(){
    if(this.state.items.invite<=0){
      this.recruit=false;
      this.resultTitle='NO INVITES';
      this.state.message='No Roster Invites. Buy more in the shop.';
      this.addLog(['No Roster Invites. Press A/B to return.']);
      saveState(this.state);this.drawBattle();return;
    }
    this.state.items.invite--;this.recruit=false;
    const r=ROSTER[this.enemy.id],odds={Common:.72,Uncommon:.55,Rare:.38,Elite:.16}[r.rarity]||.4;
    if(Math.random()<odds){
      const m=makeMon(this.enemy.id,this.enemy.lvl);
      this.state.dex.caught[m.id]=true;
      if(this.state.party.length<6)this.state.party.push(m);else this.state.box.push(m);
      this.state.stats.recruits=(this.state.stats.recruits||0)+1;
      this.resultTitle='RECRUIT JOINED';
      this.state.message=`${r.name} joined the room.`;
      this.addLog([`${r.name} joined the room. Press A/B to return.`]);
    }else{
      this.resultTitle='RECRUIT PASSED';
      this.state.message=`${r.name} passed for now.`;
      this.addLog([`${r.name} passed for now. Press A/B to return.`]);
    }
    saveState(this.state);this.drawBattle();
  }
  returnMap(){this.scene.start('OverworldScene');}
}
