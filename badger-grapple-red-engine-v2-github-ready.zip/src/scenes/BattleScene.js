import {ROSTER,makeMon,scaledStats,addXp} from '../data/roster.js';import {MOVES,ADV} from '../data/moves.js';import {loadState,saveState,lead} from '../systems/save.js';import {uiBox,hpBar,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
const COMMANDS=['FIGHT','BAG','WRESTLER','RUN'];
const BAG_ITEMS=[
  {key:'energy',name:'SPORTS DRINK',desc:'Restores 24 EP.',use(scene,l){const max=scaledStats(l.id,l.lvl).gas;if(l.gas>=max)return 'EP is already full.';l.gas=Phaser.Math.Clamp(l.gas+24,0,max);scene.state.items.energy--;return `${ROSTER[l.id].name} recovered EP.`;}},
  {key:'tape',name:'ATHLETIC TAPE',desc:'Restores 20 HP.',use(scene,l){const max=scaledStats(l.id,l.lvl).hp;if(l.hp>=max)return 'HP is already full.';l.hp=Phaser.Math.Clamp(l.hp+20,0,max);scene.state.items.tape--;return `${ROSTER[l.id].name} recovered HP.`;}},
  {key:'invite',name:'RECRUIT FLYER',desc:'Used after wins.',use(){return 'Save flyers for recruiting.';}},
  {key:'film',name:'FILM STUDY',desc:'No battle effect yet.',use(){return 'No battle effect yet.';}}
];
export class BattleScene extends Phaser.Scene{
  constructor(){super('BattleScene');}
  create(data={}){
    this.state=loadState();this.enemy=makeMon(data.enemyId||'pacesetter',data.enemyLevel||4);this.type=data.battleType||'wild';
    this.turn=1;this.sel=0;this.mode='command';this.over=false;this.recruit=false;this.impact='';this.resultTitle='';this.messageTimer=0;
    this.log=[`${ROSTER[this.enemy.id].name} wants to wrestle!`];
    const l=lead(this.state);if(l){const s=scaledStats(l.id,l.lvl);if(!Number.isFinite(l.hp)||l.hp<=0)l.hp=s.hp;if(!Number.isFinite(l.gas)||l.gas<=0)l.gas=s.gas;l.score=0;}this.enemy.score=0;
    this.state.stats={scouts:0,battles:0,wins:0,recruits:0,streak:0,...(this.state.stats||{})};this.state.stats.battles++;saveState(this.state);
    this.input.keyboard.on('keydown-LEFT',()=>this.move(-1,0));this.input.keyboard.on('keydown-RIGHT',()=>this.move(1,0));this.input.keyboard.on('keydown-UP',()=>this.move(0,-1));this.input.keyboard.on('keydown-DOWN',()=>this.move(0,1));
    this.input.keyboard.on('keydown-ENTER',()=>this.choose());this.input.keyboard.on('keydown-SPACE',()=>this.choose());this.input.keyboard.on('keydown-ESC',()=>this.back());
    setVirtualHandler(this);this.drawBattle();
  }
  handleVirtualButton(k){if(k==='left')this.move(-1,0);if(k==='right')this.move(1,0);if(k==='up')this.move(0,-1);if(k==='down')this.move(0,1);if(k==='a')this.choose();if(k==='b')this.back();}
  count(){if(this.mode==='fight')return ROSTER[lead(this.state)?.id]?.moves?.length||1;if(this.mode==='party')return Math.max(1,this.state.party.length);if(this.mode==='bag')return BAG_ITEMS.length;return 4;}
  move(dx,dy){if(this.over)return;const old=this.sel;let cols=this.mode==='party'?1:2;let rows=Math.ceil(this.count()/cols);let x=old%cols,y=Math.floor(old/cols);if(dx)x=Phaser.Math.Wrap(x+dx,0,cols);if(dy)y=Phaser.Math.Wrap(y+dy,0,rows);this.sel=Math.min(y*cols+x,this.count()-1);this.impact='';this.drawBattle();}
  choose(){if(this.over){if(this.recruit)this.tryRecruit();else this.returnMap();return;}if(this.mode==='command')return this.chooseCommand();if(this.mode==='fight')return this.chooseMove();if(this.mode==='party')return this.chooseParty();if(this.mode==='bag')return this.chooseBag();}
  back(){if(this.over)return this.returnMap();if(this.mode!=='command'){this.mode='command';this.sel=0;this.drawBattle();return;}this.returnMap();}
  addLog(lines){this.log=[...lines,...this.log].slice(0,5);}
  chooseCommand(){const cmd=COMMANDS[this.sel];if(cmd==='FIGHT'){this.mode='fight';this.sel=0;this.drawBattle();return;}if(cmd==='BAG'){this.mode='bag';this.sel=0;this.drawBattle();return;}if(cmd==='WRESTLER'){this.mode='party';this.sel=0;this.drawBattle();return;}if(cmd==='RUN'){if(this.type==='wild'){this.addLog(['Got away safely.']);this.over=true;this.resultTitle='LEFT';this.recruit=false;this.drawBattle();}else{this.addLog(['You cannot run from this match.']);this.drawBattle();}}}
  chooseMove(){const l=lead(this.state);if(!l)return this.returnMap();const key=ROSTER[l.id]?.moves?.[this.sel];if(key)this.resolveTurn(key);}

  chooseBag(){
    const l=lead(this.state);if(!l)return this.returnMap();
    const item=BAG_ITEMS[this.sel];if(!item)return;
    const count=this.state.items?.[item.key]||0;
    if(count<=0){this.addLog([`No ${item.name}.`]);this.drawBattle();return;}
    const msg=item.use(this,l);
    this.addLog([msg]);
    this.mode='command';this.sel=0;
    saveState(this.state);this.drawBattle();
  }
  chooseParty(){if(!this.state.party.length)return;const picked=this.state.party[this.sel];if(!picked)return;const idx=this.state.party.indexOf(picked);if(idx>0){this.state.party.splice(idx,1);this.state.party.unshift(picked);saveState(this.state);this.addLog([`${ROSTER[picked.id].name} is now up.`]);}else this.addLog([`${ROSTER[picked.id].name} is already wrestling.`]);this.mode='command';this.sel=0;this.drawBattle();}
  resolveTurn(key){const l=lead(this.state),e=this.enemy,beforeE=e.hp,beforeL=l.hp;const first=this.resolve(l,e,key,'You');this.impact=first.hit?`-${first.dmg}`:'MISS';const lines=[`T${this.turn}: ${first.line}`];if(e.hp<=0){lines.push(`${ROSTER[e.id].name} is out.`);this.addLog(lines);this.win();return;}const ek=Phaser.Utils.Array.GetRandom(ROSTER[e.id]?.moves||['stall']);const second=this.resolve(e,l,ek,ROSTER[e.id].name);lines.push(second.line);lines.push(`HP ${beforeL}→${l.hp} / ${beforeE}→${e.hp}`);this.addLog(lines);this.turn++;this.mode='command';this.sel=0;if(l.hp<=0){this.lose();return;}saveState(this.state);this.cameras.main.flash(50,255,255,255);this.drawBattle();}
  resolve(att,def,key,label){let mv=MOVES[key]||MOVES.stall,as=scaledStats(att.id,att.lvl),ds=scaledStats(def.id,def.lvl);if(mv.gas>0&&att.gas<mv.gas)mv=MOVES.stall;att.gas=Phaser.Math.Clamp(att.gas-Math.max(0,mv.gas),0,as.gas);if(mv.gas<0)att.gas=Phaser.Math.Clamp(att.gas+Math.abs(mv.gas),0,as.gas);let acc=mv.acc;if(att.gas<12)acc-=.12;if(Math.random()>acc)return {line:`${label} missed ${mv.name}.`,hit:false,dmg:0};const mult=ADV[mv.style]===ROSTER[def.id]?.style?1.22:ADV[ROSTER[def.id]?.style]===mv.style?.88:1;const dmg=Math.max(3,Math.round((mv.power+as.atk*.8-ds.def*.38)*mult));def.hp=Phaser.Math.Clamp(def.hp-dmg,0,ds.hp);att.score=(att.score||0)+mv.points;return {line:`${label}: ${mv.name} ${dmg}${mult>1?' EDGE':''}.`,hit:true,dmg};}
  win(){const l=lead(this.state);this.over=true;this.mode='result';this.resultTitle='VICTORY';this.state.stats.wins++;this.state.stats.streak++;const grit=this.type==='captain'?22:Phaser.Math.Between(6,10),rep=this.type==='captain'?14:Phaser.Math.Between(2,5);this.state.grit+=grit;this.state.rep+=rep;if(l)addXp(l,10+this.enemy.lvl*5).forEach(x=>this.log.unshift(x));if(this.type==='captain'&&!this.state.badges.includes('Neutral Badge')){this.state.badges.push('Neutral Badge');this.log.unshift('Badge: Neutral.');}if(this.type==='wild'){this.recruit=true;this.log.unshift('Invite window open.');}this.state.message=`Won vs ${ROSTER[this.enemy.id].name}.`;saveState(this.state);this.drawBattle();}
  lose(){this.over=true;this.recruit=false;this.mode='result';this.resultTitle='LOSS';this.state.stats.streak=0;this.state.grit+=4;this.state.rep+=2;this.state.party.forEach(m=>{const s=scaledStats(m.id,m.lvl);m.hp=s.hp;m.gas=s.gas;m.score=0;});this.addLog(['Team recovered. +4 Grit +2 Rep.']);this.state.message='Loss. Team recovered.';saveState(this.state);this.drawBattle();}
  tryRecruit(){if(this.state.items.invite<=0){this.recruit=false;this.resultTitle='NO INVITES';this.addLog(['Buy more invites.']);saveState(this.state);this.drawBattle();return;}this.state.items.invite--;this.recruit=false;const r=ROSTER[this.enemy.id],odds={Common:.72,Uncommon:.55,Rare:.38,Elite:.16}[r.rarity]||.4;if(Math.random()<odds){const m=makeMon(this.enemy.id,this.enemy.lvl);this.state.dex.caught[m.id]=true;if(this.state.party.length<6)this.state.party.push(m);else this.state.box.push(m);this.state.stats.recruits++;this.resultTitle='JOINED';this.addLog([`${r.name} joined.`]);}else{this.resultTitle='PASSED';this.addLog([`${r.name} passed.`]);}saveState(this.state);this.drawBattle();}
  drawBattle(){this.children.removeAll();this.add.image(0,0,'battle_arena').setOrigin(0);const l=lead(this.state),lr=l?ROSTER[l.id]:ROSTER.buckshot,er=ROSTER[this.enemy.id];
    this.drawStatusPanels(l,lr,er);this.drawWrestlers(lr,er);this.drawBottom(lr);}
  drawStatusPanels(l,lr,er){
    this.drawStatusBox(4,15,92,28,`${er.name.split(' ')[0]} ♂ Lv.${this.enemy.lvl}`,this.enemy,er,false);
    if(l)this.drawStatusBox(130,91,105,37,`${lr.name.split(' ')[0]} ♀ Lv.${l.lvl}`,l,lr,true);
  }
  drawStatusBox(x,y,w,h,name,mon,rec,isPlayer){const s=scaledStats(mon.id,mon.lvl);const g=this.add.graphics();g.fillStyle(isPlayer?0x20232b:0xf6f0dc,1);g.fillRoundedRect(x,y,w,h,2);g.lineStyle(2,0x111111,1);g.strokeRoundedRect(x,y,w,h,2);this.add.text(x+5,y+4,name,{fontFamily:'monospace',fontSize:7,color:isPlayer?'#f8f0d8':'#111',fontStyle:'bold'});this.add.text(x+8,y+15,'HP',{fontFamily:'monospace',fontSize:5,color:isPlayer?'#ffe28a':'#555',fontStyle:'bold'});hpBar(this,x+22,y+16,w-31,4,mon.hp/s.hp,0x55b867);if(isPlayer){this.add.text(x+8,y+24,'EP',{fontFamily:'monospace',fontSize:5,color:'#79b8ff',fontStyle:'bold'});hpBar(this,x+22,y+25,w-31,4,mon.gas/s.gas,0x5aa4e6);}}
  drawWrestlers(lr,er){const eimg=this.add.image(174,64,'battle_'+er.asset).setScale(.42);if(er.tint||er.color)eimg.setTint(er.tint||er.color);const pimg=this.add.image(63,97,'battle_'+lr.asset+'_back').setScale(.47);if(lr.tint||lr.color)pimg.setTint(lr.tint||lr.color);this.add.ellipse(174,89,64,16,0x000000,.18);this.add.ellipse(63,121,72,18,0x000000,.18);if(this.impact)this.add.text(121,60,this.impact,{fontFamily:'monospace',fontSize:11,color:'#ffe28a',fontStyle:'bold',stroke:'#111',strokeThickness:2}).setOrigin(.5);}
  drawBottom(lr){
    if(this.mode==='command')return this.drawCommand(lr);
    if(this.mode==='fight')return this.drawFight(lr);
    if(this.mode==='party')return this.drawParty();
    if(this.mode==='bag')return this.drawBag();
    return this.drawResult();
  }
  drawCommand(lr){uiBox(this,3,132,114,35);this.add.text(9,141,'What will',{fontFamily:'monospace',fontSize:8,color:'#111',fontStyle:'bold'});this.add.text(9,154,`${lr.name.split(' ')[0]} do?`,{fontFamily:'monospace',fontSize:8,color:'#111',fontStyle:'bold'});uiBox(this,119,132,118,35);COMMANDS.forEach((t,i)=>this.add.text(126+(i%2)*58,142+(i>1?13:0),`${i===this.sel?'▶':' '}${t}`,{fontFamily:'monospace',fontSize:8,color:'#111',fontStyle:'bold'}));this.drawBattleLog(6,115,2);}
  drawFight(r){uiBox(this,3,132,234,35);const moves=r.moves||[];moves.forEach((key,i)=>{const m=MOVES[key],x=11+(i%2)*112,y=139+(i>1?13:0);this.add.text(x,y,`${i===this.sel?'▶':' '}${m.name}`,{fontFamily:'monospace',fontSize:7,color:i===this.sel?'#b41820':'#111',fontStyle:'bold'});});const mv=MOVES[moves[this.sel]];if(mv)this.add.text(133,119,`${mv.style} P${mv.power} ACC${Math.round(mv.acc*100)} EP${mv.gas}`,{fontFamily:'monospace',fontSize:6,color:'#f8f0d8',backgroundColor:'#111015'});this.drawBattleLog(6,115,2);}

  drawBag(){uiBox(this,3,95,234,72);this.add.text(12,103,'BAG',{fontFamily:'monospace',fontSize:8,color:'#111',fontStyle:'bold'});BAG_ITEMS.forEach((it,i)=>{const n=this.state.items?.[it.key]||0;this.add.text(12,117+i*9,`${i===this.sel?'▶':' '} ${it.name} x${n}`,{fontFamily:'monospace',fontSize:6,color:i===this.sel?'#b41820':'#111',fontStyle:'bold'});});const it=BAG_ITEMS[this.sel];if(it)this.add.text(132,103,it.desc,{fontFamily:'monospace',fontSize:6,color:'#111',wordWrap:{width:92}});this.add.text(126,154,'A USE  B BACK',{fontFamily:'monospace',fontSize:6,color:'#555',fontStyle:'bold'});}
  drawParty(){uiBox(this,3,95,234,72);this.add.text(12,103,'Choose wrestler',{fontFamily:'monospace',fontSize:8,color:'#111',fontStyle:'bold'});this.state.party.forEach((m,i)=>{const r=ROSTER[m.id],s=scaledStats(m.id,m.lvl);this.add.text(12,117+i*9,`${i===this.sel?'▶':' '} ${r.name} L${m.lvl} HP ${m.hp}/${s.hp}`,{fontFamily:'monospace',fontSize:6,color:i===this.sel?'#b41820':'#111',fontStyle:'bold'});});}
  drawResult(){uiBox(this,3,132,234,35);this.add.text(120,138,this.resultTitle,{fontFamily:'monospace',fontSize:9,color:'#111',fontStyle:'bold'}).setOrigin(.5);this.add.text(120,151,this.recruit?'A INVITE  B LEAVE':'A/B RETURN',{fontFamily:'monospace',fontSize:8,color:'#111'}).setOrigin(.5);this.drawBattleLog(6,115,2);}
  drawBattleLog(x,y,n){this.log.slice(0,n).forEach((line,i)=>this.add.text(x,y+i*7,line,{fontFamily:'monospace',fontSize:6,color:'#f8f0d8',backgroundColor:'#111015'}));}
  returnMap(){this.scene.start('OverworldScene');}
}
