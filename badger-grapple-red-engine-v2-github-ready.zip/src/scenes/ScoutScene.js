import {ROSTER,scaledStats} from '../data/roster.js';import {MOVES,ADV} from '../data/moves.js';import {loadState} from '../systems/save.js';import {uiBox,hpBar,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
export class ScoutScene extends Phaser.Scene{
  constructor(){super('ScoutScene');}
  create(data={}){
    this.id=data.id;this.lvl=data.lvl||4;this.state=loadState();const r=ROSTER[this.id];
    const s=scaledStats(this.id,this.lvl),odds=this.baseOdds(r),moveNames=r.moves.slice(0,4).map(k=>MOVES[k].name).join(' / ');
    const tip=ADV.Neutral===r.style?'Use Defense looks.':ADV.Scramble===r.style?'Neutral attacks have edge.':ADV.Top===r.style?'Scramble attacks have edge.':ADV.Pace===r.style?'Top attacks have edge.':ADV.Upperbody===r.style?'Pace attacks have edge.':ADV.Defense===r.style?'Upperbody attacks have edge.':'Look for style edge.';
    this.cameras.main.setBackgroundColor('#15171d');
    uiBox(this,28,18,424,60);this.add.text(240,36,'SCOUT REPORT',{fontFamily:'monospace',fontSize:20,color:'#111',fontStyle:'bold'}).setOrigin(.5);this.add.text(240,58,'Preview first. Recruit during battle with ITEM → Roster Invite.',{fontFamily:'monospace',fontSize:10,color:'#444'}).setOrigin(.5);
    this.add.image(240,176,'tiles',3).setScale(7.5,2.5);const img=this.add.image(240,172,'battle_'+r.asset).setScale(1.78);if(r.tint)img.setTint(r.tint);
    uiBox(this,42,252,396,140);
    this.add.text(240,268,`${r.name}  Lv ${this.lvl}`,{fontFamily:'monospace',fontSize:17,color:'#111',fontStyle:'bold'}).setOrigin(.5);
    this.add.text(240,290,`${r.weight} lbs • ${r.style} style • ${r.rarity}`,{fontFamily:'monospace',fontSize:12,color:'#333'}).setOrigin(.5);
    hpBar(this,110,310,100,7,1,0x55b867);hpBar(this,270,310,100,7,1,0x5aa4e6);this.add.text(110,320,`HP ${s.hp}`,{fontFamily:'monospace',fontSize:9,color:'#333'});this.add.text(270,320,`Gas ${s.gas}`,{fontFamily:'monospace',fontSize:9,color:'#333'});
    this.add.text(240,337,`Moves: ${moveNames}`,{fontFamily:'monospace',fontSize:10,color:'#555',wordWrap:{width:360},align:'center'}).setOrigin(.5);
    this.add.text(240,356,`Coach tip: ${tip}`,{fontFamily:'monospace',fontSize:10,color:'#b41820',fontStyle:'bold'}).setOrigin(.5);
    this.add.text(240,373,`Invite baseline: ${Math.round(odds*100)}% now; improves as HP drops. Invites: ${this.state.items.invite}`,{fontFamily:'monospace',fontSize:9,color:'#555'}).setOrigin(.5);
    this.add.text(240,386,'A: Challenge Match     B: Walk Away',{fontFamily:'monospace',fontSize:12,color:'#111',fontStyle:'bold'}).setOrigin(.5);
    setVirtualHandler(this);
  }
  baseOdds(r){if(['Elite','Champion'].includes(r.rarity))return 0;const base={Common:.62,Uncommon:.46,Rare:.32,Starter:.40}[r.rarity]||.25;return clamp(base*(1.55-1),.03,.92);}
  handleVirtualButton(k){if(k==='a')this.scene.start('BattleScene',{team:[[this.id,this.lvl]],type:'wild'});if(k==='b')this.scene.start('OverworldScene');}
}
