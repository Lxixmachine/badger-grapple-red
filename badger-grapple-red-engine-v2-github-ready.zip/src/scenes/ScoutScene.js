import {ROSTER} from '../data/roster.js';import {MOVES,ADV} from '../data/moves.js';import {loadState} from '../systems/save.js';import {uiBox,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
export class ScoutScene extends Phaser.Scene{
  constructor(){super('ScoutScene');}
  create(data){
    this.id=data.id;this.lvl=data.lvl;this.state=loadState();
    const r=ROSTER[this.id],odds={Common:'High',Uncommon:'Medium',Rare:'Low',Elite:'Long shot'}[r.rarity]||'Medium';
    const moveNames=r.moves.slice(0,4).map(k=>MOVES[k].name).join(' / ');
    const tip=ADV.Neutral===r.style?'Use Defense looks.':ADV.Scramble===r.style?'Neutral attacks have edge.':ADV.Top===r.style?'Scramble attacks have edge.':ADV.Pace===r.style?'Top attacks have edge.':'Look for style edge.';
    this.cameras.main.setBackgroundColor('#15171d');
    uiBox(this,28,18,424,60);this.add.text(240,36,'SCOUT REPORT',{fontFamily:'monospace',fontSize:20,color:'#111',fontStyle:'bold'}).setOrigin(.5);this.add.text(240,58,'Preview first. Win, then spend an invite to recruit.',{fontFamily:'monospace',fontSize:10,color:'#444'}).setOrigin(.5);
    this.add.rectangle(240,178,260,92,0xbe1e2d).setStrokeStyle(4,0xf2e6c6);this.add.ellipse(240,218,120,20,0x000000,.35);this.add.image(240,176,'battle_'+r.asset).setScale(1.32).setFlipX(false);
    uiBox(this,42,262,396,128);
    this.add.text(240,278,`${r.name}  Lv ${this.lvl}`,{fontFamily:'monospace',fontSize:17,color:'#111',fontStyle:'bold'}).setOrigin(.5);
    this.add.text(240,300,`${r.weight} lbs • ${r.style} style • ${r.rarity}`,{fontFamily:'monospace',fontSize:12,color:'#333'}).setOrigin(.5);
    this.add.text(240,321,`Moves: ${moveNames}`,{fontFamily:'monospace',fontSize:10,color:'#555',wordWrap:{width:360},align:'center'}).setOrigin(.5);
    this.add.text(240,342,`Coach tip: ${tip}`,{fontFamily:'monospace',fontSize:10,color:'#b41820',fontStyle:'bold'}).setOrigin(.5);
    this.add.text(240,360,`Invite chance after win: ${odds}  |  Invites: ${this.state.items.invite}`,{fontFamily:'monospace',fontSize:10,color:'#555'}).setOrigin(.5);
    this.add.text(240,378,'A: Challenge Match     B: Walk Away',{fontFamily:'monospace',fontSize:13,color:'#111',fontStyle:'bold'}).setOrigin(.5);
    setVirtualHandler(this);
  }
  handleVirtualButton(k){if(k==='a')this.scene.start('BattleScene',{enemyId:this.id,enemyLevel:this.lvl,battleType:'wild'});if(k==='b')this.scene.start('OverworldScene');}
}
