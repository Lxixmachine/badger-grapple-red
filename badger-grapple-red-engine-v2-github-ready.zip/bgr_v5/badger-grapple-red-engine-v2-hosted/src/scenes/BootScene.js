import {setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
export class BootScene extends Phaser.Scene{
  constructor(){super('BootScene');}
  preload(){
    this.load.image('fieldhouse_scene','./assets/ui/fieldhouse_scene.png?v=80');
    this.load.spritesheet('tiles','./assets/tiles/fieldhouse_tiles.png?v=80',{frameWidth:32,frameHeight:32});
    this.load.spritesheet('player','./assets/sprites/player_walk.png?v=80',{frameWidth:32,frameHeight:48});
    this.load.spritesheet('npc','./assets/sprites/npc_walk.png?v=80',{frameWidth:32,frameHeight:48});
    ['badger','neutral','top','scramble','pace'].forEach(k=>{this.load.image('battle_'+k,'./assets/sprites/battle_'+k+'.png?v=80');this.load.image('battle_'+k+'_back','./assets/sprites/battle_'+k+'_back.png?v=80');this.load.image('portrait_'+k,'./assets/portraits/'+k+'.png?v=80');});
    this.load.image('logo','./assets/ui/logo.png?v=80');
    this.load.image('title_bg','./assets/ui/title_bg.png?v=80');
    this.load.image('battle_arena','./assets/ui/battle_arena.png?v=80');
  }
  create(){
    this.anims.create({key:'walk-down',frames:this.anims.generateFrameNumbers('player',{start:0,end:2}),frameRate:8,repeat:-1});
    this.anims.create({key:'walk-left',frames:this.anims.generateFrameNumbers('player',{start:3,end:5}),frameRate:8,repeat:-1});
    this.anims.create({key:'walk-right',frames:this.anims.generateFrameNumbers('player',{start:6,end:8}),frameRate:8,repeat:-1});
    this.anims.create({key:'walk-up',frames:this.anims.generateFrameNumbers('player',{start:9,end:11}),frameRate:8,repeat:-1});
    setVirtualHandler(this);this.scene.start('TitleScene');
  }
}
