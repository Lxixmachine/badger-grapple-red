import {loadState,resetState,caughtRecruitCount} from '../systems/save.js';import {uiBox,setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
export class TitleScene extends Phaser.Scene{
  constructor(){super('TitleScene');}
  create(){
    this.state=loadState();this.sel=0;this.opts=['NEW GAME','CONTINUE','RESET SAVE'];
    this.cameras.main.setBackgroundColor('#08090d');
    this.add.image(240,216,'title_bg').setDepth(0);
    this.add.rectangle(240,216,480,432,0x000000,.18).setDepth(1);
    this.add.image(240,86,'logo').setScale(1.18).setDepth(2);
    this.add.image(126,244,'battle_badger').setScale(1.85).setDepth(2);
    this.add.image(354,232,'battle_top').setScale(1.95).setFlipX(true).setDepth(2);
    uiBox(this,28,146,424,58).setDepth(3);this.add.text(240,165,'APPROVED ART PASS v8.0',{fontFamily:'monospace',fontSize:16,color:'#111',fontStyle:'bold'}).setOrigin(.5).setDepth(4);this.add.text(240,185,'Scout routes • varsity mat • badge duals • build the room',{fontFamily:'monospace',fontSize:10,color:'#444'}).setOrigin(.5).setDepth(4);
    uiBox(this,48,292,184,96).setDepth(3);this.texts=this.opts.map((o,i)=>this.add.text(76,314+i*21,o,{fontFamily:'monospace',fontSize:14,color:'#111',fontStyle:'bold'}).setDepth(4));
    uiBox(this,248,292,184,96).setDepth(3);this.statText=this.add.text(264,309,'',{fontFamily:'monospace',fontSize:10,color:'#111',wordWrap:{width:150}}).setDepth(4);
    this.add.text(240,405,'v8.0 approved art integrated • cache-busted',{fontFamily:'monospace',fontSize:11,color:'#ffe290',fontStyle:'bold',stroke:'#111',strokeThickness:3}).setOrigin(.5).setDepth(4);
    this.input.keyboard.on('keydown-UP',()=>this.move(-1));this.input.keyboard.on('keydown-DOWN',()=>this.move(1));this.input.keyboard.on('keydown-ENTER',()=>this.choose());this.input.keyboard.on('keydown-SPACE',()=>this.choose());setVirtualHandler(this);this.render();
  }
  handleVirtualButton(k){if(k==='up')this.move(-1);if(k==='down')this.move(1);if(k==='a')this.choose();if(k==='b'){resetState();this.state=loadState();this.render();}}
  move(d){this.sel=Phaser.Math.Wrap(this.sel+d,0,this.opts.length);this.render();}
  render(){const can=this.state.party?.length;this.texts.forEach((t,i)=>{t.setText(`${i===this.sel?'▶ ':'  '}${this.opts[i]}`);t.setColor(i===this.sel?'#b41820':(i===1&&!can?'#777':'#111'));});const s=this.state.stats||{};this.statText.setText(`Save stats\nRecruits: ${caughtRecruitCount(this.state)}\nBattles: ${s.battles||0}\nWins: ${s.wins||0}\nStreak: ${s.streak||0}`);}
  choose(){if(this.sel===0)this.scene.start('StarterScene');if(this.sel===1&&this.state.party?.length)this.scene.start('OverworldScene');if(this.sel===2){resetState();this.state=loadState();this.render();}}
}
