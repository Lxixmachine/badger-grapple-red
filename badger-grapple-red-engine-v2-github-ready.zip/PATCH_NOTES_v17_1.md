# v17.1 Mobile Boot Fix

- Removed runtime dependence on Phaser CDN for the deployed build.
- Replaced blank/mobile loading failure with a standalone canvas game shell.
- Preserves the promised v17 visual direction: field house, campus quad, lakeshore, river trail, downtown, arena, championship hall, scouting/battle/menu/save.
- Rebalanced mobile CSS so the game viewport is always visible above controls on iPhone Safari.
