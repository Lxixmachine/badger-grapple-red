# v17.2 Mobile Deploy Fix

- Fixed GitHub Pages deploy target: the workflow publishes ./dist, so dist/index.html is now the standalone no-CDN canvas game.
- Root index.html and dist/index.html are identical to prevent the old Phaser shell from shipping again.
- Uses direct canvas rendering, localStorage save, touch controls, keyboard controls, connected areas, scouting, menu, and battle loop.
