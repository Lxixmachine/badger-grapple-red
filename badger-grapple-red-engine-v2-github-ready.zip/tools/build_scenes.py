#!/usr/bin/env python3
"""Rebuild assets/ui/scene_<map>.png from src/data/maps.js grids + fieldhouse_tiles.png.
No text glyphs. Edge overlays for path/water/mat. People + props pasted with shadows.
Run from repo root: python3 tools/build_scenes.py   (then mirror assets/ui to dist/assets/ui)
"""
from PIL import Image, ImageDraw, ImageOps
import numpy as np, re, os

T = 32
TILESET = Image.open('assets/tiles/fieldhouse_tiles.png').convert('RGBA')
NPC = Image.open('assets/sprites/npc_walk.png').convert('RGBA')

def frame(i):
    r, c = divmod(i, 8)
    return TILESET.crop((c*32, r*32, c*32+32, r*32+32))

# ---- derived tiles ----
def borderless(img):
    """strip 2px baked border by replicating interior rows/cols"""
    a = np.array(img)
    a[0:2, :] = a[2:4, :]; a[-2:, :] = a[-4:-2, :]
    a[:, 0:2] = a[:, 2:4]; a[:, -2:] = a[:, -4:-2]
    return Image.fromarray(a)

MAT = borderless(frame(3))
def navy(img):
    a = np.array(img).astype(int)
    r, g, b = a[:,:,0].copy(), a[:,:,1].copy(), a[:,:,2].copy()
    a[:,:,0] = np.clip(r*0.22, 0, 255)
    a[:,:,1] = np.clip(r*0.30 + g*0.35, 0, 255)
    a[:,:,2] = np.clip(r*0.85 + 30, 0, 255)
    return Image.fromarray(a.astype(np.uint8))
DRILL = navy(MAT)                      # indoor scout zone = navy drill mat
d = ImageDraw.Draw(DRILL)
for k in range(-32, 32, 8):
    d.line((k, 31, k+31, 0), fill=(70, 110, 170, 255))
PAVE = Image.eval(frame(9), lambda px: int(px*0.88))  # darker pavement so paths read

BASE = {'floor': frame(0), 'grass': frame(16), 'pavement': PAVE}
GROUND = {'#':1,'b':12,'B':12,'K':19,'k':20,'h':22,'f':21,'w':17,'p':18,'~':23,'m':None,'2':None}
PROPS = {'R':4,'S':5,'C':6,'A':6,'D':6,'H':6}
PEOPLE_TINT = {'N':(180,200,255),'T':(255,220,160),'V':(160,185,255),'a':(255,235,150),'o':(255,160,150),
               'l':(160,230,190),'e':(230,180,255),'x':(255,235,150),'y':(255,160,150),'z':(200,200,210),'q':(255,200,120)}
BOSS_CH = set('CADH')
EDGE_DK = {'p':(178,140,78,255),'m':(90,10,16,255),'w2':(46,110,52,255)}
FOAM = (214,238,255,255)

def person(tint):
    fr = NPC.crop((0, 0, 32, 48))
    a = np.array(fr).astype(int)
    for i in range(3):
        a[:,:,i] = np.clip(a[:,:,i]*(tint[i]/255*0.6+0.55), 0, 255)
    return Image.fromarray(a.astype(np.uint8))

def shadow(scene, px, py, w=22, h=7):
    ov = Image.new('RGBA', scene.size, (0,0,0,0))
    ImageDraw.Draw(ov).ellipse((px+16-w//2, py+30-h//2, px+16+w//2, py+30+h//2), fill=(0,0,0,80))
    scene.alpha_composite(ov)

def load_grids():
    s = open('src/data/maps.js').read()
    out = {}
    for m in re.finditer(r"(\w+):\{\s*name:", s):
        mid = m.group(1)
        g = re.search(mid + r":\{.*?grid:\[(.*?)\]", s, re.S)
        base = re.search(mid + r":\{.*?baseTile:'(\w+)'", s, re.S)
        rows = re.findall(r"'([^']+)'", g.group(1))
        out[mid] = (rows, base.group(1) if base else 'grass')
    return out

def build(mid, rows, base_name):
    H, W = len(rows), len(rows[0])
    at = lambda x, y: rows[y][x] if 0 <= y < H and 0 <= x < W else '#'
    scene = Image.new('RGBA', (W*T, H*T))
    base = BASE.get(base_name, BASE['grass'])
    indoor = base_name != 'grass' and base_name != 'pavement' or base_name == 'floor'
    indoor = base_name == 'floor'
    for y in range(H):
        for x in range(W):
            scene.paste(base, (x*T, y*T))
            ch = at(x, y)
            if ch == 'm': scene.paste(MAT, (x*T, y*T))
            elif ch == 'w' and indoor: scene.paste(DRILL, (x*T, y*T))
            elif ch in GROUND and GROUND[ch] is not None:
                f = frame(GROUND[ch])
                if f.getbbox() and (np.array(f)[:,:,3] == 0).any(): scene.alpha_composite(f, (x*T, y*T))
                else: scene.paste(f, (x*T, y*T))
            elif ch.isdigit():
                pass  # door drawn as prop below
    # edge overlays
    d = ImageDraw.Draw(scene)
    def edge(x, y, cond_same, color, inset=0):
        rects = {'t':(x*T,y*T,(x+1)*T-1,y*T+1),'b':(x*T,(y+1)*T-2,(x+1)*T-1,(y+1)*T-1),
                 'l':(x*T,y*T,x*T+1,(y+1)*T-1),'r':((x+1)*T-2,y*T,(x+1)*T-1,(y+1)*T-1)}
        for side,(dx,dy) in {'t':(0,-1),'b':(0,1),'l':(-1,0),'r':(1,0)}.items():
            if not cond_same(at(x+dx, y+dy)): d.rectangle(rects[side], fill=color)
    for y in range(H):
        for x in range(W):
            ch = at(x, y)
            if ch == 'p': edge(x, y, lambda c: c == 'p' or c.isdigit(), EDGE_DK['p'])
            if ch == '~': edge(x, y, lambda c: c == '~', FOAM)
            if ch == 'm': edge(x, y, lambda c: c in 'mCADHzq', EDGE_DK['m'])
            if ch == 'w' and indoor: edge(x, y, lambda c: c == 'w', (40,60,110,255))
    # indoor wall band: 1-row top face shading on '#' rows adjacent to floor below
    if indoor:
        for y in range(H):
            for x in range(W):
                if at(x, y) == '#' and at(x, y+1) != '#':
                    d.rectangle((x*T, (y+1)*T-6, (x+1)*T-1, (y+1)*T-1), fill=(30,36,44,255))
    # props + people (with shadows), NO text glyphs
    for y in range(H):
        for x in range(W):
            ch = at(x, y)
            if ch == 'Y':
                shadow(scene, x*T, y*T); scene.alpha_composite(frame(11), (x*T, y*T))
            elif ch in PROPS:
                shadow(scene, x*T, y*T); scene.alpha_composite(frame(PROPS[ch]), (x*T, y*T))
                if ch in BOSS_CH:
                    p = person((255,120,120)); shadow(scene, x*T, y*T-8, 18, 6)
                    scene.alpha_composite(p, (x*T, y*T-24))
            elif ch.isdigit():
                scene.alpha_composite(frame(8), (x*T, y*T))
            elif ch in PEOPLE_TINT:
                shadow(scene, x*T, y*T, 18, 6)
                scene.alpha_composite(person(PEOPLE_TINT[ch]), (x*T, y*T-16))
    return scene

NAME_FIX = {'downtown_route':'downtown_route','downtown_club':'downtown_club'}
if __name__ == '__main__':
    grids = load_grids()
    for mid, (rows, base) in grids.items():
        img = build(mid, rows, base)
        out = f'assets/ui/scene_{mid}.png'
        img.save(out)
        print('built', out, img.size)
