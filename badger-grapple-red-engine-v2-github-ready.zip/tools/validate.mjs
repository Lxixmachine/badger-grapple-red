import {MAPS,tileAt,passableTile,findTrainer} from '../src/data/maps.js';
import {ROSTER} from '../src/data/roster.js';
const errors=[];
function err(msg){errors.push(msg);}
for(const [id,map] of Object.entries(MAPS)){
  const width=map.grid[0]?.length||0;
  map.grid.forEach((row,y)=>{if(row.length!==width)err(`${id}: row ${y} width ${row.length} != ${width}`);});
  const digits=new Set();
  map.grid.forEach(row=>row.split('').forEach(ch=>{if(/^[1-9]$/.test(ch))digits.add(ch);}));
  for(const d of digits){if(!map.warps?.[d])err(`${id}: digit ${d} has no warp def`);}
  for(const d of Object.keys(map.warps||{})){if(!digits.has(d))err(`${id}: warp ${d} has no digit in grid`);const w=map.warps[d];if(!MAPS[w.map])err(`${id}: warp ${d} targets missing map ${w.map}`);else if(!MAPS[w.map].spawns?.[w.spawn])err(`${id}: warp ${d} targets missing spawn ${w.map}.${w.spawn}`);}
  for(const [name,sp] of Object.entries(map.spawns||{})){const ch=tileAt(map,sp.x,sp.y);if(!passableTile(ch))err(`${id}: spawn ${name} blocked on ${ch}`);if(/^[1-9]$/.test(ch))err(`${id}: spawn ${name} lands on warp ${ch}`);}
  for(const [rid] of map.encounters||[]){if(!ROSTER[rid])err(`${id}: encounter ${rid} missing in ROSTER`);}
  for(const tr of map.trainers||[]){if(!map.grid.some(row=>row.includes(tr.key)))err(`${id}: trainer ${tr.id} key ${tr.key} missing in grid`);for(const [rid] of tr.team||[]){if(!ROSTER[rid])err(`${id}: trainer ${tr.id} uses missing roster ${rid}`);}}
  for(const cfg of [map.boss,map.champion].filter(Boolean)){if(!map.grid.some(row=>row.includes(cfg.key)))err(`${id}: boss/champion key ${cfg.key} missing in grid`);for(const [rid] of cfg.team||[]){if(!ROSTER[rid])err(`${id}: boss/champion uses missing roster ${rid}`);}}
}
if(errors.length){console.error(errors.join('\n'));process.exit(1);}console.log(`OK: ${Object.keys(MAPS).length} maps validated.`);
