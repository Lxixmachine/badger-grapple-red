# Badger Grapple Red v18.8 — Boot Cache Repair

Purpose: repair the blank mobile viewport seen after v18.7 without removing Phaser or rolling back gameplay.

## Fixed
- Bumped root and dist runtime cache-busters from v186 to v188 so iOS/GitHub Pages cannot reuse stale v18.6 JavaScript against the v18.7 HTML shell.
- Bumped Phaser asset version token to v188 so the updated player/NPC/area assets reload cleanly.
- Kept Phaser `noAudio:true` and audio error suppression so iOS audio-device startup noise does not block the game.
- Root and `dist/` copies are synchronized.

## Preserved
- Phaser engine.
- v18.7 intro sequence, objective log, practice/day systems, recruiting loop, Field House, Campus Quad, scouting, battles, roster/menu/save systems.
- v18.6 sprite-direction and NPC shirt-frame fixes.
- FireRed battle command menu.

## Verification checklist
- `vendor/phaser.min.js` exists in root and dist.
- `src/main.js` and `dist/src/main.js` are synchronized.
- `index.html` and `dist/index.html` both load `./src/main.js?v=188`.
- BootScene asset version is v188 in root and dist.
