import {setVirtualHandler} from '../systems/ui.js';
const Phaser = window.Phaser;
const V='188';
export class BootScene extends Phaser.Scene{
  constructor(){super('BootScene');}
  preload(){
    ['fieldhouse','campus','lakeshore','downtown','river','conference','championship'].forEach(a=>this.load.image('area_'+a,`./assets/ui/area_${a}.png?v=${V}`));
    this.load.spritesheet('tiles',`./assets/tiles/fieldhouse_tiles.png?v=${V}`,{frameWidth:16,frameHeight:16});
    this.load.spritesheet('player',`./assets/sprites/player_walk.png?v=${V}`,{frameWidth:16,frameHeight:24});
    this.load.spritesheet('npc',`./assets/sprites/npc_walk.png?v=${V}`,{frameWidth:16,frameHeight:24});
    ['badger','neutral','top','scramble','pace'].forEach(k=>{this.load.image('battle_'+k,`./assets/sprites/battle_${k}.png?v=${V}`);this.load.image('battle_'+k+'_back',`./assets/sprites/battle_${k}_back.png?v=${V}`);this.load.image('portrait_'+k,`./assets/portraits/${k}.png?v=${V}`);});
    this.load.image('logo',`./assets/ui/logo.png?v=${V}`);this.load.image('title_bg',`./assets/ui/title_bg.png?v=${V}`);this.load.image('battle_arena',`./assets/ui/battle_arena.png?v=${V}`);
  }
  create(){
    this.anims.create({key:'walk-down',frames:this.anims.generateFrameNumbers('player',{start:0,end:2}),frameRate:8,repeat:-1});
    this.anims.create({key:'walk-left',frames:this.anims.generateFrameNumbers('player',{start:3,end:5}),frameRate:8,repeat:-1});
    this.anims.create({key:'walk-right',frames:this.anims.generateFrameNumbers('player',{start:6,end:8}),frameRate:8,repeat:-1});
    this.anims.create({key:'walk-up',frames:this.anims.generateFrameNumbers('player',{start:9,end:11}),frameRate:8,repeat:-1});
    this.anims.create({key:'npc-idle-down',frames:[{key:'npc',frame:1}],frameRate:1,repeat:0});
    this.anims.create({key:'npc-idle-left',frames:[{key:'npc',frame:4}],frameRate:1,repeat:0});
    this.anims.create({key:'npc-idle-right',frames:[{key:'npc',frame:7}],frameRate:1,repeat:0});
    this.anims.create({key:'npc-idle-up',frames:[{key:'npc',frame:10}],frameRate:1,repeat:0});
    setVirtualHandler(this);this.scene.start('TitleScene');
  }
}
